# Değişiklik günlüğü

## 0.0.2.1 — gece parlaklığı
- **Geceler kısıldı (normal EIQ modunda da):** ay ışığı / gece gökyüzü çarpanı 0.70, otomatik pozlama üst sınırı 3.0 → 2.0 (BSL tarzı: 0.80 / 2.2; Karanlık Mod: 0.45 / 1.4). Test sahnesinde gece ortalama parlaklığı ~%29 azaldı; meşaleler ve yapay ışıklar öne çıkıyor. Hâlâ fazla/az gelirse `İnce Ayar > Gece Parlaklığı` ile değiştirilebilir. Önce/sonra: `docs/preview/v0021_gece_once_sonra.png`.

## 0.0.2 — "Zevkine Göre"
- **Stil seçici (`Stil`):** *EIQ (doğal)*, *BSL tarzı (canlı)* — doygun renkler, sıcak güneş + mavi gölge, parlak bulut, hafif sis, daha güçlü bloom — ve *Karanlık Mod* — düşük ortam ışığı, koyu gece ve mağara, yüksek kontrast, soğuk ton, daha yoğun sis. (Görünüm benzerliği hedeflenmiştir; hiçbir paketin kodu kullanılmadı.) Karşılaştırma: `docs/preview/v002_stiller.png`.
- **İnce Ayar ekranı:** Ortam Işığı, Güneş Işığı Şiddeti, Gölge Tonu (sıcak ↔ mavi), Gökyüzü Doygunluğu/Parlaklığı, Bulut Parlaklığı, Sis Yoğunluğu, Mağara/Minimum Işık (0 = tam karanlık), Su Bulanıklığı, Gece Parlaklığı, Pozlama, Kontrast, Doygunluk, Canlılık, Renk Sıcaklığı, Bloom, Vinyet, Ton Eşleme. Kaydırıcılar seçilen stilin **üstüne** biner (çarpan/toplama), yani önce stil, sonra kendi zevkin.
- **Optimizasyon (`Uyarlanabilir Kalite`, varsayılan açık):** uzaklığa göre kalite — PCF örnek sayısı, PCSS engel araması, GTAO adım/kesme, RT GI ve MegaIşık menzili, temas gölgesi menzili, otomatik normal sönümü. Rapor: `docs/optimizasyon_arastirmasi.md`. Seviye 4'te ~%5 (llvmpipe'ta kaba ölçüm), görüntü farkı ortalama 0.65%.
- Doğrulama: 195 program derleniyor; yeni seçenekler L5 × Overworld/End/Nether tarandı (NaN yok); seviye 1–5 × 4 sahne NaN'siz; özel durumlar temiz.
- Araçlar: `profile.py` (geçiş başına süre), `costs.py`, `abtest.py` (A/B süre + görüntü farkı).
- Sınırlar: yalnızca llvmpipe'ta doğrulandı; BSL tarzı/karanlık mod değerleri sentetik test dünyasında ayarlandı, gerçek biyomlarda zevke göre `İnce Ayar` ile oynanmalı.

## 0.0.1 — "Kusursuz Temel" (hata düzeltme sürümü)
Bu sürüm yeni özellik değil, **hata avı** sürümüdür: tüm ayarlar, gün döngüsü, boyutlar ve özel durumlar sistematik olarak tarandı.
- **DÜZELTME (kör olma / Blindness):** gökyüzü ve su/lav altı yollarında körlük efekti uygulanmıyordu; kör olunca gökyüzü parlak kalıyordu. Artık her yolda görüş körlükle sönüyor.
- **Sağlamlaştırma (NaN/Inf riskleri):** `pow()` tabanları (Fresnel `1-VoH`, mağara `I²`, kostik sırt) negatif olamaz hale getirildi; AO yarım küre ekseninde `normalize(0)` koruması; teğet vektörü sıfır olduğunda (varlıklar/el) `normalize(0)` önlendi; yarım vektör `normalize(L+V)` koruması; `sqrt(1-x)` aşağı sınırlandı.
- **Doğrulama kapsamı:** 181 ayar değeri/anahtar (Seviye 5, Overworld) + End/Nether alt kümesi + varsayılan-kapalı seçenekler (hareket bulanıklığı, yağmur damlası, lens parlaması, alan derinliği) derlendi, render edildi ve NaN/Inf ile parlaklık sapması için denetlendi: hata yok. Seviye 1–5 × gündüz/gece/alacakaranlık/yağmur NaN'siz. Özel durumlar (su altı, lav, kör, gece görüşü, fırtına, zirve/nadir, doğuş) temiz. 195 program hatasız derleniyor.
- **Gün döngüsü taraması:** sunAngle 0→1 boyunca süreksizlik/artefakt aranıp temizlendi (gün batımı geçişindeki "sıçrama" otomatik pozlamanın uyumuydu; sabit pozlamada geçiş düzgün).
- **Test motoru düzeltmeleri (pakete değil doğrulama aracına ait):** `colortex7/8` örnekleyicileri bağlanmamıştı (gökyüzü önbelleği yanlışlıkla `colortex0`/sis rengini okuyordu; Seviye 3+ testlerinde gökyüzü kısmen sis renginden geliyordu); `centerDepthSmooth` (DOF odağı) tanımsızdı; oturum kaynakları (FBO/VAO) sızıyordu; doku sıfırlama; program önbelleği kaynak özetine göre. Düzeltmeden sonra gökyüzü/bulut/güneş görünümleri yeniden gözden geçirildi, ek ayar gerekmedi.
- Araçlar: `tools/render_engine_patched/optsweep.py` (tüm seçenek taraması), `optsweep2.py`, `states.py`, `day2.py`.
- Sınırlar: yalnızca Mesa llvmpipe'ta doğrulandı (gerçek GPU/Iris'te değil); katı glslang doğrulaması yok.

## 0.0.0.9 — "Araştırma"
Internet araştırmasına dayanır (rapor: `docs/arastirma_raporu_2026.md`).
- **Ton eşleme:** yeni **AgX** ve **AgX Canlı** (Troy Sobotka; log-uzay + S-eğrisi). Menü: Görüntü > Ton Eşleme. Bliss 2.1 de AgX'i varsayılan yaptı.
- **TAA yenilendi:** Catmull-Rom (5 örnek) geçmiş filtresi, varyans kutusu (ort. ± 1.4σ) ile min/max kesişimi, NaN/Inf koruması. Hareketli kamerada referansa hata %12 azaldı, keskinlik arttı (motor testi).
- **GI voksel sınırı:** ışın izlemeli GI ve gökyüzü perdelemesi izgara sınırının son %25'inde yumuşakça söner (toroidal sarma / eksik veri kaynaklı hatalı perdeleme önlenir).
- Araştırma çıktıları: ekosistem (Iris 26.x, Vulkan geçişi, DH/Voxy), teknik karşılaştırma ve 0.0.0.10 için aday liste.
- Doğrulama: 195 program hatasız derleniyor; L5 render regresyonu temiz.

## 0.0.0.6 — "Kor"
- **Nether baştan yazıldı:** gökyüzü ışığı 0 olduğu için kapalı olan ortam ışığı ve RT dolaylı ışık düzeltildi (açık alan); biyom farkındalığı (`fogColor`); LPV'den ışık toplayan hacimsel sis; lav denizi parıltısı; ısı titreşimi; renk tonu; Nether malzemeleri ve kimlikleri (80-85, parlaktaş 58); lav kabuk/damar emisyonu; bitkiler; biyoma göre parçacıklar.
- **Kor Göz:** Nether gökyüzünde biyom renkli kara delik; anahtar ışık (`sunPathRotation` -62°).
- **End gözü** ortak `lib/blackhole.glsl` ile yeniden yazıldı (eğimli disk, mercekli kemer, foton halkası).
- Işın izleme Seviye 4'te de açık. Distant Horizons (deneysel), biyom sisi, sabah sisi, lens parlaması eklendi.
- Menü: Nether ekranı; TR/EN.

## 0.0.0.5 — "Işın"
- **YENİ (Seviye 5):** voksel ışın izleme: tuğla atlamalı DDA (`lib/rt.glsl`), `rtGeo`/`rtBrick` görüntüleri, opak voksellerde ortalama albedo.
- **YENİ:** MegaIşık: LPV tepe tırmanışıyla piksel başına stokastik ışık seçimi + renkli gölge ışını (boyalı cam gölgeyi boyar). Yön bilgisi artık gerçek N·L.
- **YENİ:** ışın izlemeli dolaylı ışık (gökyüzü perdelemesi + bir sekme) ve ışın izlemeli yansımalar (SSR ıskaladığında).
- **YENİ:** ekran uzayı god ray (bulut geçirgenliği + arazi maskesi), doğuş/batışta güçlendirilmiş hacimsel ışık, `Hacimsel Işık Şiddeti`.
- **End:** Boşluğun Gözü (kara delik + yığılma diski + merceklenme), Gözün ışığı anahtar ışık ve gölge ışığı, bulutsu, aurora, boşluk girdabı, hacimsel sis + ışık huzmeleri, boşluk sporları, End taşı parıltısı, obsidiyen/purpur/chorus malzemeleri, End renk derecelendirmesi.
- **DÜZELTME:** End'de gökyüzü ışık seviyesi 0 olduğu için ortam ışığı ve gölgeler kapalıydı; `lightmapUV` End'de açık alan kabul eder.
- **YENİ:** Nether kor parçacıkları.
- **Menü:** Işın İzleme, Işık Huzmeleri, End ve Nether ekranları; TR/EN.
- **Araçlar:** `tools/` (derleme doğrulama + llvmpipe çalışma testleri).

## 0.0.0.4 — "Gökyüzü"
- **DÜZELTME:** `at_midBlock` işareti (Iris: merkez − köşe). Rüzgârda bitkiler tabandan değil uçtan sabitleniyordu; LPV vokselleştirme blok merkezini yanlış hesaplıyordu.
- **DÜZELTME:** Cift boy bitkiler için `ID_TALL_LO/HI` (alt/üst yarı sürekli sallanma), ust uste bitkiler için `ID_STACKED` (dünya konumuna bağlı faz).
- **DÜZELTME:** Soul fire ayrı kimlik (43, mavi, seviye 10). Mesale 14, ruh 10, redstone mesalesi 7, ametist tomurcukları 4; yanan firın, mum, bakır mesale, parlak meyve, yanan redstone cevheri eklendi.
- **DÜZELTME:** LPV sönümü doğrusal 1/15 (vanilla menzili), şeffaf voksel kaybı doğrusal, eğri I^3.0.
- **YENİ:** Zamansal gökyüzü önbelleği (`colortex7/8`, 2x2 desen, yeniden projeksiyon, geçersizlik bayrağı); yönlü LPV (8 köşeden bedava gradyan); kar parıltısı; lens yağmur damlaları; alan derinliği (12 örnek); kromatik sapma artık hareket bulanıklığını bozmuyor.
- **Aurora:** 10/14/20 adımlı perde ışıkları (seviye 3/4/5), gün bazlı olasılık (`worldDay`), ayarlanabilir parlaklık ve sıklık.
- **Kayan yıldız:** 9 sn'lik dilimlerde olasılıklı, ~0.9 sn'lik parlak iz.
- **Sirrus:** 9000 m'de tek düzlemli ince bulut; yağmurda ve ufukta söner.
- **Bulut gölgesi:** ışının bulut katmanını kestiği iki noktadan yoğunluk; gökyüzü bulutlarıyla aynı rüzgâr/gürültü. Seviye 3+.
- **Ton eşleme:** ACES (Narkowicz), Filmik (Hable), Nötr (Khronos PBR Neutral) eklendi; eski eğri `EIQ` olarak korundu.
- **Renk sıcaklığı**, **hareket bulanıklığı** (yeniden projeksiyon, 8 örnek), **film greni**, **kromatik sapma**.
- Menü: Atmosfer ve Görüntü ekranları genişledi, yeni "Kamera Efektleri" ekranı, TR/EN dil dosyaları.
- Doğrulama: world0/-1/1 tüm fragment/vertex geçişleri, 5 seviye, hareket bulanıklığı açık/kapalı ve 4 ton eşleme modu glslang ile derlendi.

## 0.0.0.3 — "Işık"
- **Renkli voksel ışık (LPV):** 4 geçişli compute yayılımı (`shadowcomp..3`), toroidal voksel ızgarası (L3 64×48×64,
  L4 96×48×96, L5 128×64×128), shadow vertex aşamasında voksellestirme (ışığa paralel yüzler dahil), opak-dolgu
  bayrağıyla yumuşak trilineer örnekleme, GPU/seviye yedeği (vanilla blok ışığı).
- **Boyalı cam:** 16 renk + tinted_glass; ışığı filtrelemek yerine camın tonuna boyar.
- **Dinamik ışıklar:** elde tutulan ışık (renkli), ışık yayan varlıklar, titreşim.
- **Mavi gürültü:** void-and-cluster ile kendi ürettiğimiz 128×128 RGBA doku (spektrum doğrulandı).
- **Yıldırım / fırtına**, 5 profil, yeni ayarlar (gölge yumuşaklığı, AO şiddeti, LPV).
- **Pozlama:** NPOT ekranlarda güvenilir ölçüm (mid-mip 4×4 ızgara), log + doğrusal ortalama karışımı. Nether'de lavın
  düz sarıya patlaması giderildi.
- **Test ortamı:** `testbench/` (senin render motorun) güncel pack'e uyarlandı: compute, 3B image, koşullu
  `shaders.properties`, mavi gürültü, her karede voksellestirme, ışık laboratuvarı sahnesi.

## 0.0.0.2
- **Su yeniden yazıldı:** ayrı su katmanı (colortex6) + yeni kırılma pass'i: normale göre bükülme, kanal başına
  Beer-Lambert soğurma (turkuaz-mavi derinlik), kaustik, kıyı köpüğü. Su altında da kaustik.
- **Gökyüzü:** kübik örnekleme (eşit adımlı örnekleme gündüz ufku turuncuya kaydırıyordu; hata %65 → %5).
- **TAA:** geçmiş piksel merkezinden okunuyor; varyans kırpması komşuluk min/max kutusuna çevrildi (keskin ayrıntı artık
  bulanmıyor); seviye 3'e ayarlanabilir keskinleştirme eklendi.
- **Nether portalı:** süreğen derinlikli plazma, opak ve parlak; arka yüz atılıyor.
- **Gece:** ay ışığı ve gece tabanı kısıldı, azami pozlama 7 → 3.
- **End:** gökyüzü çok daha koyu, yıldızlar öne çıktı.
- **Pass sırası:** composite=kırılma, 1=yansıma, 2=sis, 3=TAA, 4=bloom, 5=pozlama.
- **0.0.0.3 hazırlığı:** `blockLightAt()` soyutlaması, `blockLightEmitter()` tablosu, `docs/LPV_DESIGN.md`.

## 0.0.0.1
- a · Doğuş: iskelet, ayar sistemi, 5 seviye, TR/EN dil, derleme-doğrulama aracı
- b · Gök: Rayleigh+Mie+ozon atmosferi, çoklu saçılım yaklaşımı, güneş/ay evreleri, yıldızlar, Samanyolu, hacimsel bulut
- c · Işık: labPBR + blok tablosu malzemeleri, PCF/PCSS/renkli/temas gölgesi, SSAO/GTAO, PBR aydınlatma, otomatik normal
- d · Su ve Hava: dalga/emilim/köpük, ıslak yüzey/su birikintisi/halka, rüzgâr, parçacık, Nether ve End portalı
- e · Perde: SSR, sis + hacimsel ışık, TAA/FXAA, bloom, otomatik pozlama, SDR+HDR ton eşleme
- f · Mühür: kalibrasyon, belgeler, paketleme
