# EIQFEP — Every Image Quality For Every PC
**Sürüm 0.0.2.1** · Iris · Minecraft Java 26.x (26.3 hedeflendi)

Sıfırdan yazılmış, 5 kalite seviyeli shader paketi. Hiçbir başka paketin kodu kullanılmadı.

## Kurulum
1. Iris'i kur. Paket zip'ini `shaderpacks` klasörüne at (açma).
2. **Önemli:** Minecraft 26.2 ile gelen *Graphics API* ayarını **OpenGL** yap
   (Seçenekler → Video Ayarları). Iris yerel Vulkan renderer'ı ile çalışmaz.
3. Shader menüsünden EIQFEP'i seç. Kalite Seviyesi en üstte.

## Seviyeler
| | Ad | Öne çıkanlar |
|---|---|---|
| 1 | Performans | 1024 gölge, FXAA, ucuz gökyüzü/bulut, AO yok |
| 2 | Düşük | renkli gölge, 4-örnek SSAO, otomatik normal (piksel), bulut |
| 3 | Orta | PCSS yumuşak gölge, temas gölgesi, GTAO, TAA, hacimsel ışık, SSR, bloom, **renkli ışık (LPV 64³)** |
| 4 | Yüksek | daha çok örnek, keskinleştirme, daha uzun SSR/hacimsel ışık, LPV 96×48×96 |
| 5 | Ultra | 4096 gölge, 24 örnek PCSS, GTAO 4×10, 40 adım SSR, 24 adım ışık huzmesi, LPV 128×64×128 |

## HDR
"Shaders + HDR" modu (rrtt217) yüklüyse ve HDR açıksa paket otomatik scRGB-nl çıkış verir.
Mod yoksa normal sRGB. Iris'te *Colorspace* ayarı **sRGB** kalmalı.

## Yenilikler (0.0.2) — "Zevkine Göre"
- **Stil:** Menü > `Stil`: EIQ (doğal) / BSL tarzı (canlı) / Karanlık Mod.
- **İnce Ayar:** Menü > `İnce Ayar`: ortam ışığı, güneş, gölge tonu, gökyüzü, bulut, sis, mağara karanlığı, su bulanıklığı, pozlama, kontrast, doygunluk... Stilin üstüne biner.
- **Uyarlanabilir Kalite** (Performans ekranı): uzaklığa göre kaliteyi düşürerek GPU yükünü azaltır.

## Renkli ışık (LPV) — 0.0.0.3
Işıyan bloklar (redstone, ametist, lapis, zümrüt, portal, lav, ruh mesalesi...) çevreyi **kendi renginde** aydınlatır.
- Boyalı cam ışığı kendi rengine boyar (16 renk + tinted_glass).
- Elde tutulan ışık (item.properties): mesale sıcak, ruh mesalesi mavi, redstone bloğu kırmızı, ametist mor...
- Işık yayan varlıklar: blaze, magma küpü, parlak mürekkep balığı, allay, ateş topu, end kristali, yıldırım, XP küresi.
- Ateş, mesale ve lav ince titrer.
- Seviye 3-5 ve OpenGL 4.3+ gerekir. macOS ve eski GPU'larda otomatik olarak vanilla blok ışığına düşer.
Not: bu yalnızca **görsel**tir; oyunun gerçek ışık seviyesini (canavar doğması vb.) değiştirmez.

## Yenilikler (0.0.0.6) — "Kor" (Nether sürümü)

### Nether baştan yazıldı
- **Ortam ışığı artık var:** Nether'de gökyüzü ışığı 0 olduğundan eski sürümde ortam ışığı fiilen sıfırdı ve RT dolaylı ışık çalışmıyordu. Nether artık End gibi "açık alan" sayılır (perdeleme GTAO + ışın izlemeden gelir). Ortam = biyom renginde yumuşak ışık (`Nether Ortam Isigi`).
- **Biyom farkındalığı:** Nether'de `fogColor` biyoma özgüdür; kırmızı (wastes/crimson), warped (mavi-mor), ruh kumu vadisi (camgöbeği), bazalt deltası (gri kül) ayrı renk, sis yoğunluğu ve parçacık davranışı alır (yükselen kor / süzülen spor / ruhlar / düşen kül).
- **Işıklı hacimsel sis:** sis, LPV'den (lav, parlaktaş, ateş...) ışık toplar; ışık kaynaklarının çevresinde havada parıltı oluşur. Lav denizine yakın yerlerde sis yoğunlaşır ve turuncu parlar. Seviye 3+ 8/12/16 adım (12+ gürültülü duman).
- **Lav denizi parıltısı:** y≈31 lav okyanusundan yukarı vuran turuncu ışık alçak yüzeyleri aydınlatır.
- **Isı titreşimi:** lav seviyesine yakın uzak yüzeylerde sıcak hava dalgalanması.
- **Renk tonu:** golgelerde biyom rengi, parlak yerlerde altın sapma.
- **Malzemeler:** netherrack/nylium/tuğla, wart blokları, bazalt+blackstone (parlak), kuvars, ruh kumu, altın cevheri (parıltı), ancient debris (metal); parlaktaş artık sarı-altın ışık (kimlik 58); lav doku parlaklığına göre (kabuk/damar) emisyon; kök/mantar/sarmaşık/nether sprout bitki gibi rüzgârla sallanır.
- **Kor Göz (Nether'in kara deliği):** gökyüzünde yığılma diskli kara delik, disk rengi biyomu taşır (kırmızıda lav turuncusu, ruh vadisinde camgöbeği). Gözün ışığı Nether'in anahtar ışığıdır (`sunPathRotation` -62°): **tavan bedrock'unun üstünde** yönlü ışık ve gölge verir. Not: tavanın altında göz görünmez; tavan üstünde ve render mesafesi ötesi boşluklarda görünür.
- Nether parçacıkları biyoma göre.

### End gözü iyileştirildi
- Kara delik çizimi ortak kütüphaneye (`lib/blackhole.glsl`) taşındı ve yeniden yazıldı: eğimli ince disk (gölgenin önünden geçen yarı + arkada kalan yarı), merceklenmiş kemer (gölgenin üstünde parlak, altında sönük), ince foton halkası + ikinci halka, Doppler ışıması, diferansiyel dönen türbülans, kenar yumuşatma. Önceki sürümdeki küçük, bulanık eğik bant yerine net bir Gargantua benzeri görünüm.

### Birleştirilen eklentiler
- Işın izleme artık **Seviye 4**'te de açık (96×48×96 izgara, 24×12×24 tuğla).
- Deneysel **Distant Horizons** (dh_terrain/dh_water, derinlik/ sis korumaları), **biyom sisi** (çöl tozu, nemli hava), **sabah sisi**, **lens parlaması** (varsayılan kapalı).

## Yenilikler (0.0.0.5) — "Işın"

### Işın izleme (Seviye 4-5)
Donanım RT değildir: renkli ışık (LPV) için zaten tutulan **voksel izgarasi** (128×64×128 blok, oyuncu çevresi) üzerinde yazılım DDA. Ana anahtar `Işın İzleme`; seviye 1-3'te veya LPV kapalıyken hiçbir kod/bellek çalışmaz.
- **Voksel geometrisi:** shadow vertex aşaması artık opak bloklarda dokunun ortalama rengini (mip 3 @ `mc_midTexCoord` × biyom tonu) de yazar. Compute pass 0 bunu kalıcı `rtGeo` görüntüsüne kopyalar ve her 4×4×4 blok için dolu/boş bayrağı (`rtBrick`) üretir.
- **Tuğla atlamalı DDA:** boş 4×4×4 tuğladan tek adımda çıkılır. Doğrulama: rastgele 3014 ışında kaba kuvvet CPU referansıyla **0 fark**; test sahnesinde tuğla atlama sonucu birebir aynı tutarken adım sayısını **%50** azalttı. Büyük dünya koordinatlarında (x=1000, z=-2000) toroidal sarma dahil sınandı.
- **MegaIşık (MegaLights benzeri):** her piksel LPV alanında "tepe tırmanışı" ile, aydınlatan ışığı **stokastik** seçer (yayıcıya ulaşana dek parlak komşulardan birini seçer) ve tek bir renkli gölge ışını atar. Sahnede 5 de 500 de ışık olsa piksel başına 1 seçim + 1 ışın. Meşale, fener, glowstone, redstone... gölge düşürür; boyalı cam gölgeyi **boyar**. Işık hacmi akıtmayla gelen yumuşak dolaylı ışığı bırakır (gölge gücü `MegaIşık Gölge Şiddeti`, varsayılan %80). Küçük alan ışığı jitter'ı ile yarı gölge TAA'da birikir.
- **Işın izlemeli dolaylı ışık:** piksel başına 1 kosinüs ağırlıklı ışın: 1.2-22 blok aralığında gökyüzü perdelemesi + bir sekmeli renk taşınması (isabet noktasında güneş/ay golge haritası + ortam + LPV). Yakın alan (<1.2 blok) GTAO'ya bırakıldı (çift sayım yok).
- **Işın izlemeli yansımalar:** ekran uzayı yansıması ıskalarsa (ekran dışı / perdelenmiş) voksel ışını ~96 blok devreye girer; menzil sonunda gökyüzüne karışır.
- **Bilinen sınır:** izgara blok çözünürlüklü ve opaklık "tam blok" kabul eder (yarım blok, çit, mesale de dolu sayılır). Bu yüzden ışının başlangıç hücresi yok sayılır; ince nesnelerin gölgesi blok kalınlığında olur.

### God ray (ışık huzmeleri) — tüm boyutlar
- **Ekran uzayı huzmeler** (seviye 2+: 8/14/20/28 örnek): güneş/ay (End'de Göz) yönünde ışınsal huzme. Maske = açık gök; gündüz bulut önbelleğindeki geçirgenlik de kullanıldığından **bulut aralarından** ve **arazi/ağaç arkasından** huzme çıkar. Alçak güneşte güçlenir, yağmurda söner.
- **Hacimsel ışık** (gölge haritası) doğuş/batışta ayrıca güçlendirilir; yeni `Hacimsel Işık Şiddeti` ayarı.

### End — baştan yazıldı
- **Boşluğun Gözü:** gökte devasa (gölge yarıçapı ~2.9°, güneşin ~5 katı) bir kara delik: olay ufku, foton halkası, Doppler aydınlatmalı yığılma diski (türbülanslı, diferansiyel dönen), gölgenin üstünden/altından bükülen arka disk ve **kütleçekimsel mercek** (arkadaki yıldız/bulutsu bükülür). Seviye 3+ tam detay.
- **Gözün ışığı = End'in anahtar ışığı:** gölge haritasının ışığı bu yöndedir (`sunPathRotation` End'de -48°, ~42° yükseklik). Böylece End ilk kez **yönlü ışık ve gölge** alır; adaların, sütunların uzun gölgeleri Gözden gelir. Anahtar ışık sıcak-eflatun, ortam ışığı mor-turkuaz.
- **Gökyüzü:** alan bükmeli renkli bulutsu (mor/eflatun çekirdek/turkuaz iplik/toz şeritleri), Samanyolu bandı, yoğun yıldızlar, **End aurorası** (turkuaz→eflatun perdeler, her zaman), sık kayan yıldız, ufkun altında yavaş dönen **boşluk girdabı**.
- **Hacimsel End sisi:** altta yoğunlaşan boşluk sisi + gürültü; Gözün ışığından **gölge haritalı huzmeler** (sütun ve şehir aralarında), Göze bakınca parlayan ileri saçılım. Seviye 3+ 8-16 adım.
- **Boşluk sporları:** havada süzülen turkuaz/eflatun parlak noktalar (3B hücre tabanlı, piksel boyutundan küçük olmaz).
- **Malzemeler:** end taşı kozmik toz parıltısı; obsidiyen ve purpur parlak (yansımalar artık gerçek End gökyüzünü gösterir); chorus hafif parlar. Işınlı yansıma ve dolaylı ışık End'de de çalışır.
- **Düzeltme:** End'de gökyüzü ışık seviyesi yoktur (`has_skylight=false`), eski sürümde ortam ışığı ve gölgeler fiilen kapalıydı; artık End açık alan kabul edilir, perdeleme GTAO/gölge haritası/ışın izlemeden gelir.
- End renk derecelendirmesi (gölgeler turkuaz-mor, parlak yerler sıcak) ve daha güçlü bloom.

### Diğer
- **Nether kor parçacıkları** (yükselen turuncu noktalar).
- Yeni menüler: *Işın İzleme*, *Işık Huzmeleri*, *End ve Nether*; TR/EN dil dosyaları.
- Derleme doğrulama aracı pakette: `tools/` (aşağıya bakın).

## Doğrulama durumu (dürüst özet)
Yapıldı:
- Tüm world0/-1/1 geçişleri, 5 seviye, tüm yeni anahtarların tek tek kapalı hali: **glslang ile 684 + 480 derleme, 0 hata**.
- Yazılım OpenGL (Mesa llvmpipe, GL 4.5) üzerinde **gerçek GLSL kodu çalıştırıldı**: DDA (CPU referansına karşı 0 fark), MegaIşık ışık seçici (aydınlık piksellerde 0 başarısızlık), MegaIşık gölgeleri ve ışın izlemeli dolaylı ışık (sentetik oda, açık/kapalı karşılaştırması), renkli cam gölgesi, End gökyüzü (3 bakış), End adası (anahtar ışık, uzun gölgeler, sis, sporlar), ekran uzayı god ray (bulut/ağaç maskeli).
Yapılamadı (gerçek Iris + GPU gerekir):
- **0.0.0.6:** Nether'de `shadowLightPosition`/`sunPathRotation=-62` ile Kor Göz ışığı ve gölge yönü varsayımı; `fogColor` ile biyom ayrımı; Seviye 4 RT izgara boyutları (`image.rtGeo` 96×48×96); Distant Horizons program adları/uniform'ları; `smooth()` özel uniform'ları (biyom sisi); Nether sahnesi yalnızca sentetik test odasında görüldü (parlaklık/yoğunluk oyunda ayarlanmalı).
- Iris'te `image.rtGeo/rtBrick` görüntülerinin shadow-vertex yazımı sonrası compute'ta okunması ve ardından örnekleyici ile okunması (bellek bariyeri); `mc_midTexCoord`'un shadow programında varlığı.
- End'de `sunAngle`/`shadowLightPosition`'ın sabit gün ortası olması varsayımı ve `sunPathRotation=-48`'in boyuta özgü okunması (okunmazsa -25° ile ~65° yükseklikte çalışır, bozulmaz).
- **Performans ölçülmedi** (GPU yok). Seviye 5'te ışın izleme ek yük getirir; `Işın İzleme` alt anahtarlarıyla tek tek kapatılabilir.
- Parlaklıklar/renkler llvmpipe görüntüleriyle ayarlandı, otomatik pozlama ile gerçek oyunda ince ayar gerekebilir.

## Araçlar (`tools/`)
- `verify.py <shaders> [seviyeler]` : tüm geçişleri glslang ile derler (Iris `#include` açılımı, Iris makroları dahil).
- `toggles.py`, `rt_accuracy.py`, `room_render.py`, `end_scene.py`, `sky_render.py`, `godray_test.py`: llvmpipe üzerinde çalışan testler. Gereksinim: `glslang-tools`, `python3-moderngl`, `numpy`, `pillow`.

## Yenilikler (0.0.0.4)
- **Hata düzeltmeleri (önemli):**
  - Rüzgâr ters çalışıyordu: Iris'te `at_midBlock` "merkez − köşe" döndürür, kod tersini varsayıyordu. Çiçek ve otlar artık tabandan sabit, uçtan sallanıyor.
  - Aynı hata renkli ışık (LPV) vokselleştirmesinde de vardı; ışıklar bloğun yanlış voksellerine yazılıyordu.
  - Cift boy bitkiler (uzun çim, ayçiçeği, gül çalısı...) alt/üst yarıda dikişsiz sallanıyor; kamış, kelp ve deniz otu dünya konumuna bağlı sallanıyor (uzun gövdede kopukluk yok).
  - Soul fire turuncu ışık veriyordu; artık mavi ve seviye 10.
  - Işık menzili vanilla ile aynı: doğrusal 1/15 sönüm (eskiden çarpansal 0.87 ile 30+ blok gidiyordu). Seviyeler vanilla'ya çekildi: mesale 14, ruh 10, redstone mesalesi 7, ametist tomurcukları 4, yanan firın 13, mum, bakır mesale, yanan redstone cevheri, parlak meyveli sarmaşık eklendi. Su ve yaprak ışığı yaklaşık 1 seviye, tinted_glass ~7 seviye keser.
  - Not: ışık eskisinden biraz daha kısa menzilli ve karanlık görünebilir; `Renkli Işık Şiddeti` ile ayarlanır.
- **Zamansal gökyüzü önbelleği (performans):** atmosfer ve bulutlar 2x2 desenle 4 karede bir yenilenir, aradaki karelerde yeniden projekte edilir (seviye 3-5). Gökyüzü ağır pass'in en pahalı kısmıydı.
- **Yönlü renkli ışık:** ışık hacminin gradyanından N·L benzeri gölgeleme; ışığa bakan yüzler parlak, ters yüzler sönük. Ek doku okuması yok.
- **Kar parıltısı**, **lensde yağmur damlaları** (varsayılan kapalı), **alan derinliği** (varsayılan kapalı).
- **Kutup ışıkları (aurora):** seviye 3-5, açık gecelerde renkli perdeler. Her gece görünmez (`Aurora Sıklığı`, varsayılan %35).
- **Kayan yıldızlar** ve **yüksek ince bulutlar (sirrus)**.
- **Bulut gölgeleri:** bulutlar yere hareketli gölge düşürür (seviye 3-5).
- **Ton eşleme seçimi:** EIQ (varsayılan), ACES, Filmik, Nötr. Yalnızca SDR çıkışta; HDR yolu kendi eğrisini korur.
- **Renk sıcaklığı** kaydırıcısı.
- **Kamera efektleri** (yeni menü): hareket bulanıklığı, film greni, kromatik sapma. Üçü de varsayılan olarak kapalı.

## Diğer yenilikler (0.0.0.3)
- Mavi gürültü dokusu (kendi üretecimiz): gölge, AO, bulut, yansıma ve hacimsel ışık örneklemesinde.
- Yıldırım flaşı ve fırtına karartması.
- 5 profil (tek tık seviye), yeni ayarlar: gölge yumuşaklığı, AO şiddeti, LPV ayarları.
- Otomatik pozlama ölçümü sağlamlaştırıldı (NPOT ekran boyutlarında tepe mip'e güvenmiyor).

## Bu sürümde YOK (menüde de yok)
Unreal MegaLights'ın kendisi (donanım ışın izleme ve ışık BVH'si gerektirir; yerine **MegaIşık**: LPV'den stokastik ışık seçimi + voksel gölge ışını), tam yol izleme, probe GI, radiance cache, FFT su, Distant Horizons / Voxy desteği (her pass'in derinlik tamponunu ikiye bölmeyi gerektirir), biyoma göre sis.

## Bilinen doğrulanmamış noktalar (GPU'da test edilmedi)
- `particles.ordering`, `blend.*` özelliklerinin Iris 26.3'teki tam davranışı
- End portalının hangi programdan geçtiği
- HDR çıkışta "1.0 = kâğıt beyazı" varsayımı
- Otomatik normal yönü (yeşil kanal işareti)
- `blend.*` ve `colortex6` su katmanının Iris 26.3'te tam davranışı
- **LPV:** shadow vertex aşamasındaki `imageStore`, `image.*` bildirimleri, compute dağıtımı ve `iris.features.optional` davranışı (test ortamında doğrulandı, gerçek Iris'te henüz değil)
- **0.0.0.4 (yeni):** gökyüzü önbelleği colortex7/8'i aynı pass'te hem okuyup hem yazıyor (Iris'in ping-pong'una güveniyor); `block.properties` içindeki `half=lower/upper` durum sözdizimi; kar parıltısı ve yağmur damlası görünümü; doğrusal ışık sönümünün vanilla'ya yakınlığı GPU'da kontrol edilmeli
- **0.0.0.4:** yeni geçişler glslang ile derlenip doğrulandı, ama görsel olarak hiçbir ortamda denenmedi: aurora/sirrus/bulut gölgesi parlaklıkları, hareket bulanıklığı yönü ve ton eşleme eğrilerinin pozlamayla uyumu GPU'da ayarlanmalı
- `IS_IRIS` / `MC_GL_VERSION` makrolarının varlığı (yoksa LPV sessizce kapalı kalır)

0.0.0.3 yazılım OpenGL (Mesa llvmpipe) üzerinde Iris pass zincirini taklit eden bir test ortamında görsel olarak doğrulanmıştı.
0.0.0.4'te yalnızca derleme denetimi yapıldı (test ortamı pakette yoktu); gerçek Iris/GPU testi gereklidir.

## Önizleme (`docs/preview/`)
Bunlar **Mesa llvmpipe üzerinde sentetik sahnelerle** üretilmiş doğrulama görüntüleridir (Iris/Minecraft'tan alınmadı): `end_eye.png` (Boşluğun Gözü), `end_island_eye.png`, `end_island_shadows.png` (Gözün ışığıyla uzun gölgeler), `rt_room_day.png` (ışın izlemeli dolaylı ışık + renkli cam gölgesi), `godrays_test.png` (ekran uzayı huzme maskesi; görüntü dikey ters).
