# LPV tasarımı (0.0.0.3'te uygulandı)

Amaç: ışıyan blokların (redstone, ametist, lapis, portal, lav, glowstone...) **çevreyi kendi renginde**
aydınlatması. Şu an yalnızca blokların kendisi parlıyor (0.0.0.2).

## Uygulanan mimari (özet)
- Voksellestirme: shadow **vertex** aşaması (`lpvVoxelize`), `voxEmit` + `voxOpac` (her kare temizlenir).
- Yayılım: `shadowcomp..3` (4 adım/kare), `lpvImgA/B` ping-pong; opak vokseller yalnızca yumuşak örnekleme için dolgu tutar (bayrak 1), yayıcılar bayrak 2.
- Örnekleme: `blockLightAt()` → `lpvSample()` (8 komşu, trilineer, yüz önünden 0.55 kaydırma), vanilla ile `conf` karışımı.
- Saydam vokseller (cam/su/yaprak) ışığı tonlayarak geçirir.

## Hazırlık (0.0.0.2'de yapıldı)
- `lighting.glsl::blockLightAt(posRel, Nw, lmBlock)`: blok ışığı tek noktadan alınıyor. LPV örneklemesi buraya takılacak.
- `materials.glsl::blockLightEmitter(id)`: her ışıyan blok için renk + başlangıç seviyesi tablosu.
- Test ortamı (`sim/`): compute shader + 3B image çalışıyor (`sim/lpv_probe.py` ile doğrulandı).

## Mimari
1. **Voksel ızgarası**: oyuncu çevresinde 3B image (`rgba16f`). Boyut seviyeye göre:
   L3 64³, L4 96³, L5 128³ (blok başına 1 voksel). Oyuncu ile kayar; ızgara kayarken içerik yeniden indekslenir.
2. **Enjeksiyon**: `block.properties` kimliğinden `blockLightEmitter()` rengi. Voksel yazımı shadow pass'inde
   (gölge geometrisi zaten tüm blokları çiziyor): fragment aşamasında `imageStore`.
3. **Yayılım**: compute flood-fill, ping-pong iki image. Adım başına 6 komşu, seviye başına 1/15 sönüm.
   Saydam bloklar (cam) ışığı **tonlayarak** geçirir, opak bloklar durdurur (opaklık maskesi ayrı kanal).
   Kareye yayılan adım sayısı: L3 2, L4 3, L5 4 (zamansal yayılım, yavaş/akıcı güncelleme).
4. **Örnekleme**: `blockLightAt` içinde, normal yönünde yarım voksel kaydırılmış konumdan trilineer okuma.
   Eski vanilla `lmBlock` ile `max()` birleştirilir (LPV dışı alanda geri düşüş).
5. **Geri düşüş (fallback)**: OpenGL < 4.3 veya macOS → compute yok → mevcut vanilla blok ışığı. `iris.features.optional`
   ile `COMPUTE_SHADERS CUSTOM_IMAGES` istenir; paket yeteneği olmayan GPU'da da yüklenir.

## Seviye eşlemesi
| Seviye | LPV |
|---|---|
| 1-2 | yok (vanilla blok ışığı) |
| 3 | 64³, 2 adım/kare |
| 4 | 96³, 3 adım/kare |
| 5 | 128³, 4 adım/kare, yumuşak renk karışımı |

## Riskler
- Shadow pass'te `imageStore` ve gölge çözünürlüğü ilişkisi (Iris davranışı doğrulanmalı).
- Izgara kayması sırasında titreme → ızgarayı tam blok adımlarında kaydır.
- Compute dağıtım boyutu / `image.*` bildirimleri Iris 26.3'te doğrulanmalı (gerçek test gerekli).

## Sonraki adımlar
LPV alfa kanalına gökyüzü ışığı eklenebilir (yumuşak iç mekan ortam ışığı); voksel opaklığı DDA temas gölgesi ve MegaLights ışık listeleri için hazır.


## 0.0.0.4 notu
- `at_midBlock` = (blok merkezi - köşe) * 64 (Iris `ExtendedDataHelper.computeMidBlock`). Merkez = konum + midBlock/64.
- Yayılım artık doğrusal: her adımda en parlak kanal 1/15 azalır (renk korunur). Seviye L ışık L-1 blok gider.
- `lpvSample` ayrıca 8 köşeden parlaklık gradyanı döndürür (opak dolgu vokselleri hariç); `blockLightAt` bunu N·L benzeri çarpan için kullanır.
