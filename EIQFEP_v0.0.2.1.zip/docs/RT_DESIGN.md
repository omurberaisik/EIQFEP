# Işın izleme ve MegaIşık tasarımı (0.0.0.5)

## Veri
| Görüntü | Biçim | İçerik | Yazan |
|---|---|---|---|
| `voxOpac` | RGBA8, her kare temizlenir | opak: ortalama albedo, saydam: ışık tonu; a = opaklık | shadow vertex (`lpvVoxelize`) |
| `rtGeo` / `rtGeoTex` | RGBA8, kalıcı | `voxOpac` kopyası (örnekleyiciyle okunur) | shadowcomp (pass 0) |
| `rtBrick` / `rtBrickTex` | RGBA8 32×16×32 | 4×4×4 blokta opaklık ≥ 0.045 var mı | shadowcomp (pass 0) |
| `lpvTexA` | RGBA16F | LPV; a: 0 hava, 1 opak dolgu, 2 yayıcı | shadowcomp 0-3 |

Neden kopya: voksel yazımı shadow vertex aşamasında yapılır; sonraki compute dispatch'inin sonunda bellek bariyeri olduğundan, deferred'in okuduğu kalıcı kopya compute'ta üretilir (LPV'nin kullandığı yolla aynı).

## DDA
Koordinatlar oyuncu-göreceli; hücre = floor(cameraPosition) tabanına göre. t ilerlemesi her adımda `p = o + d t`'den yeniden hesaplanır; hücre boş tuğlada ise tuğla çıkış düzlemine, değilse hücre çıkış düzlemine atlanır. İzgara dışına çıkan ışın `outside` döner (çağıran gökyüzüne/gölge haritasına düşer). Başlangıç hücresi (ve `tMin` öncesi) isabet saymaz.

## MegaIşık
1. Pikselin ön tarafındaki hava hücresinden başla (yüz + 0.55 blok).
2. En çok 14 adım: yukarı (daha parlak) komşular arasından yayıcı önceliğiyle akan seçimle (reservoir) birini seç. Yayıcıya (a = 2) ulaşınca dur.
3. Hedef = yayıcı merkezi + ±0.35 jitter (yarı gölge). Piksel başına tek gölge ışını, renkli geçirgenlik.
4. `lpv *= mix(1, vis, RT_LIGHT_SHADOW)`; `lpv *= 0.4 + 1.0 N·L` (yakında etkisiz).
Işın bulunamazsa eski gradyan yöntemi (aynı aralık) kullanılır. Maliyet ışık sayısından bağımsızdır.

## Sınırlar
- Blok çözünürlüğü, "tam blok" opaklık; ince nesneler dolu sayılır.
- Izgara ±64 x/z, ±32 y; ötesi bilinmiyor.
- 1 örnek/piksel: kararlılık TAA'ya bağlıdır (seviye 5'te TAA açık).
