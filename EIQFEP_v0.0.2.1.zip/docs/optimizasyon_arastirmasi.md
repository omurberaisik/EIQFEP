# Optimizasyon araştırması (0.0.2)

Kaynaklar: ShaderLabs "Performance Tips"; Hillaire/Guerrilla/Playdead çizgisindeki bulut optimizasyonları (arXiv:1609.05344 "Optimisations for Real-Time Volumetric Cloudscapes"); temas sertleşen yumuşak gölgeler (GPU Gems / gamedev.net "Contact-hardening Soft Shadows Made Fast").

## Bulgular ve durum
| Teknik | Kaynak | EIQFEP'te durum |
|---|---|---|
| Az bulut adımı + piksel başı jitter + TAA ile gürültü temizleme (128→8 adım, ~40× hız) | arXiv:1609.05344 | Zaten var (adım sayısı seviyeye bağlı, jitter + TAA) |
| Düşük çözünürlük / karelerin yalnızca bir kısmını yenileme (4×4 / 2×2 deseni) | Horizon: Zero Dawn, arXiv | Zaten var: gökyüzü + bulut önbelleği 2×2 desenle 4 karede bir yenilenir (`SKY_TEMPORAL`) |
| Süzme (PCF) alınan örnek sayısını uzaklıkla azaltma, yumuşaklık için engel arama yalnızca yakında | GPU Gems 17, gamedev.net | **0.0.2:** 40 m ötesinde örnek yarıya iner; 64 m ötesinde PCSS engel araması atlanır |
| Uzakta ekran uzayı efektlerini kes / sisle birlikte sönümle | genel pratik | **0.0.2:** GTAO 70–130 m arası söner, >130 m atlanır; küçük yarıçapta GTAO adım sayısı yarıya iner; ışın izlemeli GI 40–64 m arasında söner; MegaIşık 72 m ötesinde atlanır; temas gölgesi 110 m ötesinde atlanır |
| Uzaktaki dokularda üretilmiş normal haritası gereksiz (minification) | genel pratik | **0.0.2:** otomatik normal 40–72 m arasında söner, ötesinde hesaplanmaz |
| Anizotropik filtre / TAA'lı paketlerde oyun içi AA kapatma vb. oyun ayarları | ShaderLabs | Belgelendi (kullanıcı tarafı) |

## Ölçüm (sınırlı!)
Ölçüm Mesa llvmpipe (CPU) üzerinde 640×360'ta yapıldı; bu, GPU'daki gerçek maliyeti **yalnızca kabaca** yansıtır. Seviye 4'te gölge haritası dışı toplam ~%5 azalma (651→613 ms/kare, ölçüm gürültüsü ±%5); görüntü farkı ortalama 1.65/255. Seviye 5'te fark gürültü içinde. Gerçek kazanç GPU'ya bağlıdır; `ADAPTIVE_QUALITY` kapatılarak (Performans ekranı) 0.0.1 davranışına dönülebilir.

Denenip geri alınan: temas gölgesini 32 m'de kesmek uzak yapraklarda görünür bir doku/gürültü değişimi yaptığı için 110 m'ye çıkarıldı.

## Sonraki adaylar (uygulanmadı)
- Kare başına bir kez hesaplanan ışık sabitlerini (şu an ileri-boyama köşe aşamasında her köşede hesaplanıyor: su/varlık) `colortex5` içindeki küçük bir bölgeye yazıp okumak.
- Yarım çözünürlük GTAO + çift taraflı yükseltme; RT GI için zamansal birikim + à-trous gürültü giderme.
