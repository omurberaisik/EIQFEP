#ifndef EIQ_AO
#define EIQ_AO
#include "/lib/common.glsl"

// =============================================================================
//  Ortam ortulmesi: seviye 2 yarikure SSAO, seviye 3+ GTAO (ufuk tabanli, kosinus agirlikli)
// =============================================================================

vec3 aoViewPos(vec2 uv) {
    return viewPosFromDepth(uv, texture(depthtex1, uv).r);
}

#if AO_MODE == 1
float computeAO(vec2 uv, vec3 vp, vec3 N, float n1, float n2) {
    float R = 0.85;
    float occ = 0.0;
    const int NS = 8;
    for (int i = 0; i < NS; i++) {
        vec2 v = vogel(i, NS, n1);
        float h = (float(i) + 0.5 + n2) / float(NS);
        vec3 tangent = normalize(abs(N.y) < 0.99 ? cross(N, vec3(0.0, 1.0, 0.0)) : cross(N, vec3(1.0, 0.0, 0.0)));
        vec3 bitan = cross(N, tangent);
        vec3 dir = normalize(tangent * v.x + bitan * v.y + N * (0.25 + h));
        vec3 sp = vp + dir * (R * (0.2 + h * 0.8));
        vec3 s = projectView(sp);
        if (s.x < 0.0 || s.x > 1.0 || s.y < 0.0 || s.y > 1.0) continue;
        float sz = aoViewPos(s.xy).z;
        float d = sz - sp.z;
        float rangeCheck = smoothstep(0.0, 1.0, R / max(abs(vp.z - sz), 1e-3));
        occ += (d > 0.03 ? 1.0 : 0.0) * rangeCheck;
    }
    return saturate(1.0 - occ / float(NS) * 1.15);
}
#elif AO_MODE == 2
float computeAO(vec2 uv, vec3 vp, vec3 N, float n1, float n2) {
    vec3 V = normalize(-vp);
#ifdef ADAPTIVE_QUALITY
    // Uzakta AO etkisi sisle birlikte ihmal edilebilir: tamamen atla / sonumle
    float farK = smoothstep(70.0, 130.0, -vp.z);
    if (farK >= 1.0) return 1.0;
#else
    const float farK = 0.0;
#endif
    float radiusW = 1.25;
    float radiusPx = radiusW * gbufferProjection[1][1] * 0.5 * viewHeight / max(-vp.z, 0.1);
    radiusPx = clamp(radiusPx, 4.0, 90.0);
#ifdef ADAPTIVE_QUALITY
    // Yaricap kucukse (uzak / kucuk etki alani) daha az adim yeterli
    int nSteps = radiusPx < 14.0 ? max(GTAO_STEPS / 2, 3) : GTAO_STEPS;
#else
    int nSteps = GTAO_STEPS;
#endif
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    float vis = 0.0;
    for (int s = 0; s < GTAO_SLICES; s++) {
        float phi = (float(s) + n1) / float(GTAO_SLICES) * PI;
        vec2 dir2 = vec2(cos(phi), sin(phi));
        vec3 dirV = vec3(dir2, 0.0);
        vec3 orth = dirV - dot(dirV, V) * V;
        vec3 crs = cross(dirV, V);
        if (dot(crs, crs) < 1e-10) { vis += 1.0; continue; }
        vec3 axis = normalize(crs);
        vec3 projN = N - axis * dot(N, axis);
        float projLen = length(projN);
        if (projLen < 1e-4) { vis += 1.0; continue; }
        float cosN = clamp(dot(projN / projLen, V), -1.0, 1.0);
        float nAng = sign(dot(orth, projN)) * acos(cosN);

        float hc0 = -1.0;
        float hc1 = -1.0;
        for (int j = 0; j < GTAO_STEPS; j++) {
            if (j >= nSteps) break;
            float t = (float(j) + n2) / float(nSteps);
            t = t * t;
            float rp = max(t * radiusPx, 1.5 + float(j));
            vec2 o = dir2 * rp * px;
            for (int side = 0; side < 2; side++) {
                vec2 suv = uv + (side == 0 ? -o : o);
                if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;
                vec3 sp = aoViewPos(suv);
                vec3 dl = sp - vp;
                float dist = length(dl);
                float hc = dot(dl / max(dist, 1e-4), V);
                float fall = saturate((dist - radiusW * 0.55) / (radiusW * 0.45));
                hc = mix(hc, -1.0, fall);
                if (side == 0) hc0 = max(hc0, hc); else hc1 = max(hc1, hc);
            }
        }
        float h0 = -acos(clamp(hc0, -1.0, 1.0));
        float h1 =  acos(clamp(hc1, -1.0, 1.0));
        h0 = nAng + max(h0 - nAng, -PI * 0.5);
        h1 = nAng + min(h1 - nAng,  PI * 0.5);
        float sn = sin(nAng);
        float a0 = cosN + 2.0 * h0 * sn - cos(2.0 * h0 - nAng);
        float a1 = cosN + 2.0 * h1 * sn - cos(2.0 * h1 - nAng);
        vis += projLen * 0.25 * (a0 + a1);
    }
    vis /= float(GTAO_SLICES);
    return mix(saturate(vis), 1.0, farK);
}
#else
float computeAO(vec2 uv, vec3 vp, vec3 N, float n1, float n2) { return 1.0; }
#endif

#endif
