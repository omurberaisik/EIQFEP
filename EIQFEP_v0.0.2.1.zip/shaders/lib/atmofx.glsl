#ifndef EIQ_ATMOFX
#define EIQ_ATMOFX
#include "/lib/common.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/shadows.glsl"

// =============================================================================
//  Atmosfer efektleri (composite2): ekran uzayi isik huzmeleri, End hacimsel sisi,
//  bosluk sporlari / Nether korleri.
// =============================================================================

#if EIQ_DIM == 0 && SKY_CACHE_ON
uniform sampler2D colortex8;       // gokyuzu onbellegi: bulut (rgb + gecirgenlik)
#endif

// ---------------------------------------------------------------------------
//  Ekran uzayi isik huzmeleri (crepuscular rays)
//  Maske: acik gok = isik gecirir. Gunduz bulut onbellegindeki gecirgenlik de kullanilir,
//  boylece bulut aralarindan huzme cikar. Arazi (depth < 1) isigi keser.
// ---------------------------------------------------------------------------
#if GODRAY_STEPS > 0
float godRayMask(vec2 s) {
    if (texture(depthtex0, s).r < 1.0) return 0.0;
#if EIQ_DIM == 0 && SKY_CACHE_ON
    return texture(colortex8, s).a;
#else
    return 1.0;
#endif
}

// uv: piksel, Ldir: dunya uzayinda isik yonu, cosA: bakis yonu ile isik yonu arasindaki kosinus
vec3 godRays(vec2 uv, vec3 Ldir, vec3 Lcol, float cosA, float jit) {
    vec3 Lv = mat3(gbufferModelView) * Ldir;
    if (Lv.z > -0.02) return vec3(0.0);                      // isik kamera arkasinda
    vec4 pc = gbufferProjection * vec4(Lv * 100.0, 1.0);
    vec2 suv = pc.xy / pc.w * 0.5 + 0.5;
    vec2 delta = suv - uv;
    float len = length(delta);
    float reach = min(len, 0.55);
    vec2 stp = delta / max(len, 1e-4) * (reach / float(GODRAY_STEPS));
    vec2 s = uv + stp * jit;
    float acc = 0.0, wsum = 0.0, w = 1.0;
    for (int i = 0; i < GODRAY_STEPS; i++) {
        acc += godRayMask(clamp(s, vec2(0.001), vec2(0.999))) * w;
        wsum += w;
        w *= 0.965;
        s += stp;
    }
    acc /= wsum;
    float ang = pow(saturate(cosA), 3.0);
    float fall = 1.0 / (1.0 + len * len * 6.0);
    vec2 o = abs(suv - 0.5) * 2.0;
    float edge = 1.0 - smoothstep(1.0, 1.7, max(o.x, o.y));
    return Lcol * (acc * ang * fall * edge);
}
#endif

// ---------------------------------------------------------------------------
//  Bosluk sporlari (End) / korler (Nether): dunyaya sabit 3B hucrelerde kucuk parlak noktalar,
//  gorus isini boyunca MOTE_STEPS dilimde taranir. Piksel boyutundan kucuk olmaz (TAA ile yumusar).
//  nether = true: turuncu, yukari yukselen kor; false: turkuaz/eflatun, yavas suzulen spor.
// ---------------------------------------------------------------------------
#if MOTE_STEPS > 0
vec3 motes(vec3 rd, float maxDist, float jit, bool nether, float density, vec4 bio) {
    float t = frameTimeCounter;
    // Nether: kirmizi biyomda yukselen kor, warped'ta suzulen spor, ruh vadisinde yavas yukselen ruhlar, bazaltta dusen kul
    float rise = bio.x * 1.1 + bio.y * (-0.18) + bio.z * 0.35 + bio.w * (-0.55);
    if (nether) density *= 1.0 + 1.2 * bio.w + 0.3 * bio.y;
    vec3 drift = nether ? vec3(0.4 * sin(t * 0.3), t * rise, 0.4 * cos(t * 0.25))
                        : vec3(t * 0.12, t * 0.05, t * 0.08);
    vec3 ro = cameraPosition + drift;
    float pxAng = 2.0 / (gbufferProjection[1][1] * viewHeight);
    const float cs = 3.5;
    vec3 acc = vec3(0.0);
    for (int i = 0; i < MOTE_STEPS; i++) {
        float f = (float(i) + jit) / float(MOTE_STEPS);
        float s = 2.5 + pow(f, 1.6) * (maxDist - 2.5);
        vec3 g = (ro + rd * s) / cs;
        vec3 id = floor(g);
        float h = hash13(id);
        if (h > density) continue;
        vec3 j = vec3(hash13(id + 7.1), hash13(id + 13.3), hash13(id + 29.9)) * 0.6 + 0.2;
        vec3 c = (id + j) * cs + 0.22 * vec3(sin(t * 0.7 + h * 40.0), sin(t * 0.9 + h * 71.0), cos(t * 0.8 + h * 23.0));
        vec3 oc = c - ro;
        float tc = dot(oc, rd);
        if (tc < 1.5 || tc > maxDist || abs(tc - s) > cs) continue;
        float d = length(oc - rd * tc);
        float baseR = 0.030 + 0.030 * fract(h * 91.7);
        float rad = max(baseR, tc * pxAng * 1.3);
        float I = smoothstep(rad, 0.0, d);
        I *= I * saturate(sq(baseR / rad) * 3.0);
        float tw = 0.55 + 0.45 * sin(t * (1.3 + h * 2.0) + h * 60.0);
        float fade = (1.0 - smoothstep(0.55 * maxDist, maxDist, tc)) * smoothstep(1.5, 4.0, tc);
        vec3 col;
        if (nether) {
            float f = fract(h * 37.0);
            vec3 cRed = mix(vec3(1.0, 0.30, 0.05), vec3(1.0, 0.65, 0.20), f) * 2.6;
            vec3 cWarp = mix(vec3(0.15, 0.90, 0.85), vec3(0.55, 0.40, 1.0), f) * 1.9;
            vec3 cSoul = mix(vec3(0.25, 0.75, 1.0), vec3(0.75, 1.0, 1.0), f) * 1.7;
            vec3 cAsh = (f > 0.93 ? vec3(1.0, 0.45, 0.12) * 2.2 : vec3(0.60, 0.55, 0.60) * 0.8);
            col = cRed * bio.x + cWarp * bio.y + cSoul * bio.z + cAsh * bio.w;
        }
        else        col = mix(vec3(0.15, 0.95, 0.85), vec3(0.85, 0.35, 1.0), fract(h * 53.0)) * 2.2;
        acc += col * (I * tw * fade);
    }
    return acc * 0.9;
}
#endif

// ---------------------------------------------------------------------------
//  End hacimsel sisi: asagida yogunlasan bosluk sisi + gurultu + Goz isigindan huzmeler.
//  Golge haritasi ile isik gorunurlugu ornekleme (Overworld hacimsel isigi ile ayni yontem).
// ---------------------------------------------------------------------------
const vec3 END_MIST_AMB = vec3(0.12, 0.07, 0.20) * (SUN_S * 0.11);

float endMistDensity(vec3 wp) {
    float m = 0.30 + 1.50 * smoothstep(78.0, 18.0, wp.y);        // aada altinda yogun sis
#if END_FOG_STEPS >= 12
    float n = fbm3(wp * vec3(0.035, 0.050, 0.035) + vec3(frameTimeCounter * 0.012, 0.0, frameTimeCounter * 0.008), 2);
    m *= 0.55 + 1.10 * n;
#endif
    return m;
}

vec3 endFog(vec3 color, vec3 rd, float dist, float jit, vec3 Ldir, vec3 Lcol) {
    float sigma = 0.0040 * END_FOG_DENSITY;
    float mu = dot(rd, Ldir);
#if END_FOG_STEPS > 0
    float maxD = min(dist, 192.0);
    float ds = maxD / float(END_FOG_STEPS);
    vec3 keyS = Lcol * (PI * phaseHG(mu, 0.6) * 0.55);
    float T = 1.0;
    vec3 insc = vec3(0.0);
    for (int i = 0; i < END_FOG_STEPS; i++) {
        float s = (float(i) + jit) * ds;
        vec3 p = rd * s;
        float sg = sigma * endMistDensity(p + cameraPosition);
        float vis = 1.0;
        vec3 sc = toShadowCoord(p);
        if (!(any(lessThan(sc.xy, vec2(0.0))) || any(greaterThan(sc.xy, vec2(1.0)))))
            vis = step(sc.z - 0.0005, texture(shadowtex1, sc.xy).r);
        float stepT = exp(-sg * ds);
        insc += T * (1.0 - stepT) * (END_MIST_AMB + keyS * vis);
        T *= stepT;
    }
    if (dist > maxD) {                                           // menzil otesi: analitik kuyruk
        float Tf = exp(-sigma * 0.8 * (dist - maxD));
        insc += T * (1.0 - Tf) * (END_MIST_AMB + keyS * 0.6);
        T *= Tf;
    }
    return color * T + insc;
#else
    float T = exp(-dist * sigma * 0.7);
    return color * T + END_MIST_AMB * (1.0 - T);
#endif
}

#endif
