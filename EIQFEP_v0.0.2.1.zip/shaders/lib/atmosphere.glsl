#ifndef EIQ_ATMOSPHERE
#define EIQ_ATMOSPHERE
#include "/lib/common.glsl"

// =============================================================================
//  Fiziksel atmosfer: Rayleigh + Mie + ozon, tek saçılım + çoklu saçılım yaklaşımı.
//  Birimler km. Gezegen: yarıçap 6360 km, atmosfer üstü 6460 km.
// =============================================================================
const float RG = 6360.0;
const float RA = 6460.0;
const vec3  BETA_R   = vec3(5.802e-3, 13.558e-3, 33.100e-3);
const float BETA_M_S = 3.996e-3;
const float BETA_M_E = 4.440e-3;
const vec3  BETA_O   = vec3(0.650e-3, 1.881e-3, 0.085e-3);
const float H_R = 8.0;
const float H_M = 1.2;
const float MS_GAIN = 0.4;        // çoklu saçılım payı
const float SKY_GAIN = 1.35;      // sanatsal gökyüzü kazancı

// Sahne ışık ölçeği: doğrudan güneş rengi ~ SUN_S, gökyüzü ışığı buna oranlı.
const float SUN_S = 4.0;
const float MOON_RATIO = 0.018;

vec3 atmoDensity(float h) {
    h = max(h, 0.0);
    return vec3(exp(-h / H_R), exp(-h / H_M), max(0.0, 1.0 - abs(h - 25.0) / 15.0));
}
vec3 atmoExtinction(vec3 d) {
    return BETA_R * d.x + vec3(BETA_M_E) * d.y + BETA_O * d.z;
}
vec2 raySphere(vec3 ro, vec3 rd, float r) {
    float b = dot(ro, rd);
    float c = dot(ro, ro) - r * r;
    float h = b * b - c;
    if (h < 0.0) return vec2(-1.0);
    h = sqrt(h);
    return vec2(-b - h, -b + h);
}
float phaseR(float c) { return 3.0 / (16.0 * PI) * (1.0 + c * c); }
float phaseM(float c, float g) {
    float k = 3.0 / (8.0 * PI) * (1.0 - g * g) / (2.0 + g * g);
    return k * (1.0 + c * c) / pow(1.0 + g * g - 2.0 * g * c, 1.5);
}
float phaseHG(float c, float g) {
    float d = 1.0 + g * g - 2.0 * g * c;
    return (1.0 - g * g) / (4.0 * PI * pow(d, 1.5));
}

// Noktadan ışık yönüne kadar geçirgenlik (gezegen gölgesi dahil)
vec3 lightTransmittance(vec3 p, vec3 L, int steps) {
    vec2 g = raySphere(p, L, RG);
    if (g.x > 0.0) return vec3(0.0);
    float len = raySphere(p, L, RA).y;
    float ds = len / float(steps);
    vec3 od = vec3(0.0);
    for (int i = 0; i < steps; i++) {
        vec3 q = p + L * (ds * (float(i) + 0.5));
        od += atmoExtinction(atmoDensity(length(q) - RG)) * ds;
    }
    return exp(-od);
}

// Tek ışık kaynağı için gökyüzü ışıması. E: ışık şiddeti (irradyans).
vec3 skyScatter(vec3 rd, vec3 L, float E, float camKm, int steps, int lsteps) {
    vec3 ro = vec3(0.0, RG + camKm, 0.0);
    float tmax = raySphere(ro, rd, RA).y;
    vec2 g = raySphere(ro, rd, RG);
    if (g.x > 0.0) tmax = min(tmax, g.x);
    float mu = dot(rd, L);
    float pr = phaseR(mu);
    float pm = phaseM(mu, 0.8);
    vec3 od = vec3(0.0);
    vec3 sum = vec3(0.0);
    float prevT = 0.0;
    for (int i = 0; i < steps; i++) {
        // kubik dagilim: alt atmosferin yogun kismi daha sik orneklenir
        float u1 = float(i + 1) / float(steps);
        float t1 = tmax * u1 * u1 * u1;
        float ds = t1 - prevT;
        float tm = prevT + 0.5 * ds;
        prevT = t1;
        vec3 p = ro + rd * tm;
        vec3 d = atmoDensity(length(p) - RG);
        vec3 ext = atmoExtinction(d);
        vec3 Tv = exp(-(od + ext * ds * 0.5));
        od += ext * ds;
        vec3 Ts = lightTransmittance(p, L, lsteps);
        vec3 scat = BETA_R * d.x * pr + vec3(BETA_M_S) * d.y * pm;
        vec3 ms = (BETA_R * d.x + vec3(BETA_M_S) * d.y) * (MS_GAIN / (4.0 * PI));
        sum += Tv * Ts * (scat + ms) * ds;
    }
    return sum * E;
}

// ---- Gök cisimleri yönleri (dünya uzayı) ------------------------------------
vec3 getSunDir()  { return normalize(mat3(gbufferModelViewInverse) * sunPosition); }
vec3 getMoonDir() { return normalize(mat3(gbufferModelViewInverse) * moonPosition); }
float cameraKm() { return max(cameraPosition.y - 63.0, 0.0) * 0.001 + 0.0006; }
float moonIllumFactor() { return 0.05 + 0.95 * (0.5 + 0.5 * cos(float(moonPhase) * PI * 0.25)); }

// Gece tabani: yildiz isigi + hava parlamasi
vec3 nightAmbient() { return vec3(0.35, 0.5, 1.0) * (0.008 * SUN_S * E_NIGHT); }

// Yildirim flasi: yildirim varligi (w > 0) oldugu karelerde 1
float lightningFlash() {
#ifdef THUNDER_FLASH
    return step(0.5, lightningBoltPosition.w);
#else
    return 0.0;
#endif
}

// Güneş + ay + gece tabanı: verilen yön için tam gökyüzü ışıması
vec3 skyRadianceFull(vec3 rd, int steps, int lsteps) {
    vec3 sunDir = getSunDir();
    vec3 moonDir = getMoonDir();
    float km = cameraKm();
    vec3 rdc = normalize(vec3(rd.x, max(rd.y, 0.0005), rd.z));
    vec3 col = vec3(0.0);
    if (sunDir.y > -0.28)
        col += skyScatter(rdc, sunDir, PI * SUN_S * SKY_GAIN, km, steps, lsteps);
    if (moonDir.y > -0.28)
        col += skyScatter(rdc, moonDir, PI * SUN_S * MOON_RATIO * moonIllumFactor() * E_NIGHT, km, steps, lsteps);
    col += nightAmbient() * (0.6 + 0.4 * (1.0 - rdc.y));
    return col;
}

// Ortam ışığı örnekleme adımları (ileri-boyama pass'lerinde azaltılabilir)
#ifndef ATMO_AMB_STEPS
  #define ATMO_AMB_STEPS 6
#endif
#ifndef ATMO_AMB_LSTEPS
  #define ATMO_AMB_LSTEPS 3
#endif

// Güneş ve ay rengi (yer seviyesinde, geçirgenlik dahil)
void sunMoonColors(out vec3 sunCol, out vec3 moonCol) {
    vec3 ro = vec3(0.0, RG + cameraKm(), 0.0);
    sunCol  = lightTransmittance(ro, getSunDir(), 12) * SUN_S;
    moonCol = lightTransmittance(ro, getMoonDir(), 8) * SUN_S * MOON_RATIO * moonIllumFactor() * E_NIGHT;
}

#if EIQ_DIM == -1
#include "/lib/nether.glsl"
#endif

// ---- Sahne ışık sabitleri (vertex aşamasında hesaplanır) ---------------------
//  lightDir/lightColor: golge isigi (gunduz gunes, gece ay)
//  amb*: yarikure ortam isigi
void computeAtmoLight(out vec3 lightDir, out vec3 lightColor,
                      out vec3 ambUp, out vec3 ambHor, out vec3 ambGround) {
#if EIQ_DIM == 0
    vec3 sunDir = getSunDir();
    vec3 moonDir = getMoonDir();
    bool day = sunAngle < 0.5;
    vec3 sunCol, moonCol;
    sunMoonColors(sunCol, moonCol);
    lightDir = day ? sunDir : moonDir;
    lightColor = day ? sunCol * E_SUN : moonCol;

    vec3 hA = normalize(vec3(sunDir.x, 0.25, sunDir.z + 1e-4));
    vec3 hB = normalize(vec3(-sunDir.x, 0.25, -sunDir.z + 1e-4));
    ambUp  = skyRadianceFull(vec3(0.0, 1.0, 0.0), ATMO_AMB_STEPS, ATMO_AMB_LSTEPS);
    ambHor = 0.5 * (skyRadianceFull(hA, ATMO_AMB_STEPS, ATMO_AMB_LSTEPS) + skyRadianceFull(hB, ATMO_AMB_STEPS, ATMO_AMB_LSTEPS));
    ambGround = 0.25 * (sunCol * max(sunDir.y, 0.0) + ambHor);

    // Stil / ince ayar: ortam isigi seviyesi + golge tonu (E_COOL > 0 mavi, < 0 sicak golge)
    {
        vec3 coolT = mix(vec3(1.0), vec3(0.90, 0.98, 1.14), saturate(E_COOL))
                   * mix(vec3(1.0), vec3(1.10, 1.00, 0.88), saturate(-E_COOL));
        vec3 aT = coolT * E_AMBIENT;
        ambUp *= aT; ambHor *= aT; ambGround *= aT;
    }

    // Yagmur: dogrudan isik soner, ortam isigi gri-mavi ve biraz koyu
    float rn = rainStrength;
    lightColor *= mix(1.0, 0.12, rn);
    vec3 gray = vec3(luma(ambUp + ambHor) * 0.5);
    ambUp  = mix(ambUp,  gray * 1.1, rn * 0.6);
    ambHor = mix(ambHor, gray,       rn * 0.6);

    // Firtina: daha karanlik, kapali gokyuzu; yildirim anlarinda beyaz-mavi flas
    float th = thunderStrength;
    lightColor *= 1.0 - 0.55 * th;
    ambUp  *= 1.0 - 0.38 * th;
    ambHor *= 1.0 - 0.38 * th;
    float fl = lightningFlash();
    vec3 flashCol = vec3(0.80, 0.86, 1.00) * SUN_S;
    ambUp     += flashCol * fl * 0.85;
    ambHor    += flashCol * fl * 0.95;
    ambGround += flashCol * fl * 0.45;
    lightColor += flashCol * fl * 0.35;
#elif EIQ_DIM == -1
    // Nether: gokyuzu yok. Ortam = biyom rengi (yumusak, yerel isiklar baskin); Kor Goz tavan ustunu aydinlatir
    vec4 nb = netherBiome();
    vec3 tint = netherTint(nb);
    float nS = NETHER_AMBIENT * 0.040 * SUN_S;
    ambUp = tint * (nS * 0.70);
    ambHor = tint * nS;
    ambGround = tint * (nS * 0.55);
  #if defined(NETHER_EYE) && defined(NETHER_EYE_LIGHT)
    lightDir = netherEyeDir();
    lightColor = tint * (0.55 * SUN_S) * smoothstep(0.02, 0.12, lightDir.y);
  #else
    lightDir = vec3(0.0, 1.0, 0.0);
    lightColor = vec3(0.0);
  #endif
#else
    // End: anahtar isik = "Boslugun Gozu" (golge isigi yonu). Sicak-eflatun, soguk turkuaz-mor ortam.
    lightDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    lightColor = vec3(1.00, 0.72, 0.60) * (0.46 * SUN_S) * END_LIGHT_STRENGTH * smoothstep(0.02, 0.18, lightDir.y);
    ambUp     = vec3(0.24, 0.20, 0.62) * (0.45 * SUN_S * 0.25) * 1.6;
    ambHor    = vec3(0.40, 0.18, 0.55) * (0.45 * SUN_S * 0.25) * 1.6;
    ambGround = vec3(0.18, 0.07, 0.28) * (0.45 * SUN_S * 0.25) * 1.6;
#endif
}

#endif
