#ifndef EIQ_BLACKHOLE
#define EIQ_BLACKHOLE
// =============================================================================
//  Kara delik (End "Boslugun Gozu" ve Nether "Kor Goz" ortak cizimi) - 0.0.0.6 yeniden yazim
//
//  Koordinat: p = (bakis yonu, goz ekseni) duzleminde, golge yaricapi = 1 olacak sekilde olceklenmis.
//   - olay ufku: r < 1 tam siyah
//   - foton halkasi: r ~ 1.05'te cok ince, Doppler isiklandirmali
//   - yigilma diski: ince disk, egimli (cos i = DISK_CI) -> dogrudan goruntu eliptik bant;
//     on yari golgenin ONUNDEN gecer, arka yari golgenin arkasinda kalir
//   - mercekli kemer: diskin arka yarisinin golgenin ustunden/altindan bukulen goruntusu
//   - diferansiyel donen turbulans: ic halkalar disa gore hizli doner
//  Gorunum Interstellar'daki Gargantua'ya yakin, tam fiziksel degildir (analitik yaklasim).
// =============================================================================
struct BHPal {
    vec3 inner;     // diskin ic kenari (en sicak)
    vec3 mid;
    vec3 outer;     // dis kenar (en soguk)
    vec3 halo;      // genis parlama
    float gain;     // genel isik carpani (SUN_S ile olceklenmis)
};

const float BH_ROLL = 0.38;      // disk egim yonu (radyan)
const float BH_CI   = 0.085;     // cos(egim): kucuk = kenardan bakis

vec3 bhDiskColor(float R, BHPal pal) {
    return mix(mix(pal.inner, pal.mid, smoothstep(1.3, 2.8, R)), pal.outer, smoothstep(2.6, 6.5, R));
}

// p: golge yaricapi biriminde konum; pw: bir pikselin p biriminde buyuklugu (kenar yumusatma)
// detail: 0 = yalnizca golge + halka, 1 = disk, 2 = disk + turbulans
vec3 blackHoleEmit(vec2 p, float pw, int detail, BHPal pal, out float cover) {
    cover = 0.0;
    float r = length(p);
    float aa = max(pw, 0.010);
    vec3 col = vec3(0.0);

    // genis parlama (golgenin arkasindan gelen yayinim)
    float glow = exp(-r * 0.46) * 0.50 + exp(-r * 0.12) * 0.040;
    vec3 behind = pal.halo * glow * (pal.gain * 0.14);
    if (r > 16.0) return behind;

    float cr = cos(BH_ROLL), sr = sin(BH_ROLL);
    vec2 q = vec2(cr * p.x + sr * p.y, -sr * p.x + cr * p.y);
    float rr = max(r, 1e-3);
    float dopSide = q.x / rr;                                    // -1 .. 1
    float dopR = pow(clamp(1.0 + 0.62 * (-dopSide), 0.25, 1.9), 2.4);   // yaklasan (sol) taraf parlak

    // foton halkasi: ince, parlak, hafif ikinci halka
    float rw = max(0.020, aa * 1.4);
    float ring = exp(-sq((r - 1.045) / rw)) + 0.22 * exp(-sq((r - 1.125) / (rw * 1.6)));
    behind += pal.inner * ring * (0.45 + 0.55 * dopR) * (pal.gain * 1.3);

    vec3 front = vec3(0.0);
    float discCover = 0.0;

    if (detail >= 1) {
        // ---- mercekli kemer: arka diskin golgenin ustunden (parlak) ve altindan (sonuk) bukulen goruntusu
        float vert = abs(q.y) / rr;
        float archM = smoothstep(0.10, 0.80, vert) * (q.y > 0.0 ? 1.0 : 0.42);
        float archP = exp(-sq((r - 1.16) / 0.11)) + (r > 1.0 ? 0.16 * exp(-(r - 1.0) * 2.4) : 0.0);
        float archR = 2.0 + (r - 1.0) * 3.2;
        float archT = 1.0;
        if (detail >= 2) {
            float ang = atan(q.y, q.x) - frameTimeCounter * 0.22 * pow(max(archR, 1.0), -1.5);
            archT = 0.60 + 0.80 * fbm2(vec2(cos(ang), sin(ang)) * 2.2 + vec2(archR * 1.4, 3.0), 3);
        }
        behind += bhDiskColor(archR, pal) * archP * archM * dopR * archT * (pal.gain * 1.2);

        // ---- dogrudan disk goruntusu (eliptik): R = disk duzlemindeki yaricap
        vec2 dq = vec2(q.x, q.y / BH_CI);
        float R = length(dq);
        const float Rin = 1.45;
        const float Rout = 7.2;
        float rad = smoothstep(Rin, Rin + 0.30, R) * (1.0 - smoothstep(Rout * 0.55, Rout, R));
        // on yari (q.y < 0) golgenin onunden gecer; arka yari yalnizca golgenin disinda ve kemerden uzakta gorunur
        bool nearHalf = q.y < 0.0;
        float farVis = smoothstep(1.0, 1.0 + aa * 2.0 + 0.04, r) * smoothstep(1.4, 3.2, abs(q.x));
        float vis = nearHalf ? 1.0 : farVis;
        if (rad * vis > 0.001) {
            float phi = atan(dq.y, dq.x);
            float turb = 1.0;
            if (detail >= 2) {
                float a2 = phi - frameTimeCounter * 0.30 * pow(max(R, 1.0), -1.5);
                vec2 np = vec2(cos(a2), sin(a2)) * (R * 0.85) + 3.7;
                turb = 0.50 + 1.00 * fbm2(np * 1.5, 3);
                turb *= 0.80 + 0.40 * fbm2(np * 5.0 + 11.0, 2);    // ince serit
            }
            float prof = pow(max(R, 1.0), -1.75);
            float dop = pow(clamp(1.0 - 0.60 * (dq.x / max(R, 1e-3)), 0.25, 1.9), 2.4);
            front = bhDiskColor(R, pal) * (rad * vis * prof * dop * turb * (pal.gain * 3.6));
            discCover = saturate(rad * vis * 1.25);
        }
    }

    float hz = smoothstep(1.0, 1.0 - aa * 1.5, r);          // olay ufku
    col = behind * (1.0 - hz) + front;
    cover = max(hz, discCover);
    return col;
}

// Merceklenmis arka plan yonu: goz merkezinden bakisa dogru orneklemeyi buker (Einstein halkasi)
// p: golge yaricapi biriminde konum
vec2 blackHoleLens(vec2 p) {
    float r = max(length(p), 0.02);
    float lens = 1.15 / (r * r) * (1.0 - smoothstep(6.0, 12.0, r));
    return p * max(1.0 - lens, 0.0);
}

#endif
