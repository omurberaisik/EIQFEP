#ifndef EIQ_CLOUDS
#define EIQ_CLOUDS
#include "/lib/atmosphere.glsl"

// =============================================================================
//  Hacimsel bulut katmani: ray-march + cok oktavli coklu sacilim yaklasimi.
//  Dusuk seviyelerde adim sayisi azalir, TAA ile gurultu temizlenir.
// =============================================================================
const float CLOUD_BASE  = 1500.0;   // dunya Y (m)
const float CLOUD_TOP   = 2300.0;
const float CLOUD_SIGMA = 0.0190;   // sogurma katsayisi (1/m)

float cloudCoverage() { return saturate(CLOUD_COVER + rainStrength * 0.28 + thunderStrength * 0.15); }

float cloudDensity(vec3 p, bool detail) {
    float h = (p.y - CLOUD_BASE) / (CLOUD_TOP - CLOUD_BASE);
    if (h < 0.0 || h > 1.0) return 0.0;
    vec2 wind = vec2(frameTimeCounter * 7.0, frameTimeCounter * 3.0) * (0.6 + 0.4 * WIND_STRENGTH);
    vec3 q = vec3((p.x + wind.x) * 0.00042, p.y * 0.0009, (p.z + wind.y) * 0.00042);
    float n = fbm3(q, 3);
    float lo = 0.80 - cloudCoverage() * 0.62;
    float d = smoothstep(lo, lo + 0.13, n);
    float hs = smoothstep(0.0, 0.15, h) * (1.0 - smoothstep(0.55, 1.0, h));
    d *= hs;
    if (detail) {
        float e = fbm3(q * 6.5 + vec3(0.0, frameTimeCounter * 0.02, 0.0), 2);
        d = saturate(d * 1.2 - (1.0 - d) * e * 0.35);
    }
    return d;
}

// rd: dunya yonu. Donus: (sacilan isik rgb, gecirgenlik)
vec4 cloudMarch(vec3 rd, vec3 lightDir, vec3 lightColor, vec3 ambCol, float jitter) {
    float y0 = cameraPosition.y;
    float t0, t1;
    if (y0 < CLOUD_BASE) {
        if (rd.y <= 0.0005) return vec4(0.0, 0.0, 0.0, 1.0);
        t0 = (CLOUD_BASE - y0) / rd.y;
        t1 = (CLOUD_TOP - y0) / rd.y;
    } else if (y0 <= CLOUD_TOP) {
        t0 = 0.0;
        if (rd.y > 0.0005)       t1 = (CLOUD_TOP - y0) / rd.y;
        else if (rd.y < -0.0005) t1 = (CLOUD_BASE - y0) / rd.y;
        else                     t1 = 6000.0;
    } else {
        if (rd.y >= -0.0005) return vec4(0.0, 0.0, 0.0, 1.0);
        t0 = (CLOUD_TOP - y0) / rd.y;
        t1 = (CLOUD_BASE - y0) / rd.y;
    }
    float fade = saturate(1.0 - t0 / 42000.0);
    if (fade <= 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
    float seg = min(t1 - t0, 6500.0);
    float dt = seg / float(CLOUD_STEPS);
    float t = t0 + dt * jitter;

    float mu = dot(rd, lightDir);
    float lobeF = phaseHG(mu, 0.62);
    float lobeB = phaseHG(mu, -0.28);

    vec3 scatter = vec3(0.0);
    float T = 1.0;
    for (int i = 0; i < CLOUD_STEPS; i++) {
        vec3 p = cameraPosition + rd * t;
        float d = cloudDensity(p, true);
        if (d > 0.004) {
            float sigma = d * CLOUD_SIGMA;
            float h = saturate((p.y - CLOUD_BASE) / (CLOUD_TOP - CLOUD_BASE));
            float tauL;
#if CLOUD_LSTEPS > 0
            tauL = 0.0;
            float ls = 55.0;
            vec3 lp = p;
            for (int j = 0; j < CLOUD_LSTEPS; j++) {
                lp += lightDir * ls;
                tauL += cloudDensity(lp, false) * CLOUD_SIGMA * ls;
                ls *= 1.9;
            }
#else
            tauL = CLOUD_SIGMA * 0.5 * (CLOUD_TOP - p.y) / max(lightDir.y, 0.2) * 0.35;
#endif
            // cok oktavli coklu sacilim yaklasimi
            float energy = 0.0;
            float a = 1.0;
            for (int o = 0; o < 3; o++) {
                float ph = mix(phaseHG(mu, 0.62 * a), phaseHG(mu, -0.28 * a), 0.3);
                energy += a * exp(-tauL * a) * ph;
                a *= 0.5;
            }
            // koyu taban / aydinlik tepe
            vec3 sunTerm = lightColor * (PI * energy);
            vec3 ambTerm = ambCol * (0.16 + 0.84 * h);
            vec3 S = sunTerm + ambTerm;
            float stepT = exp(-sigma * dt);
            scatter += T * (1.0 - stepT) * S;
            T *= stepT;
            if (T < 0.02) break;
        }
        t += dt;
    }
    // uzaklik solmasi
    return vec4(scatter * fade * E_CLOUDB, mix(1.0, T, fade));
}

// ---- Yuksek ince bulutlar (sirrus): tek duzlem, 2B gurultu, ucuz --------------------
const float CIRRUS_ALT = 9000.0;
vec4 cirrusLayer(vec3 rd, vec3 lightDir, vec3 lightColor, vec3 ambCol) {
    if (rd.y < 0.02 || cameraPosition.y > CIRRUS_ALT - 200.0) return vec4(0.0);
    float t = (CIRRUS_ALT - cameraPosition.y) / rd.y;
    vec2 p = cameraPosition.xz + rd.xz * t;
    vec2 wind = vec2(frameTimeCounter * 11.0, frameTimeCounter * 4.0) * (0.6 + 0.4 * WIND_STRENGTH);
    // gerilmis koordinat: iplik gibi uzanan yapi
    vec2 q = (p + wind) * vec2(0.00011, 0.00034);
    float warp = vnoise2(q * 2.3 + 4.0);
    float n = fbm2(q + vec2(warp * 0.8, 0.0), 4);
    float dens = smoothstep(0.34, 0.66, n) * (1.0 - 0.75 * saturate(cloudCoverage() - 0.55));
    float a = dens * 0.55 * smoothstep(0.02, 0.22, rd.y) * (1.0 - 0.85 * rainStrength);
    float mu = dot(rd, lightDir);
    vec3 col = lightColor * (0.22 + 0.55 * pow(saturate(mu), 8.0)) + ambCol * 0.75;
    return vec4(col, a);
}

// ---- Bulut golgesi: isik isininin bulut katmanini kestigi iki noktadan yogunluk -------
float cloudShadow(vec3 worldPos, vec3 lightDir) {
    if (lightDir.y < 0.12) return 1.0;
    float thick = CLOUD_TOP - CLOUD_BASE;
    float y1 = CLOUD_BASE + 0.35 * thick;
    float y2 = CLOUD_BASE + 0.75 * thick;
    vec3 p1 = worldPos + lightDir * ((y1 - worldPos.y) / lightDir.y);
    vec3 p2 = worldPos + lightDir * ((y2 - worldPos.y) / lightDir.y);
    float d = 0.5 * (cloudDensity(p1, false) + cloudDensity(p2, false));
    float tau = d * CLOUD_SIGMA * thick * 0.5 / max(lightDir.y, 0.35);
    float vis = exp(-tau * 0.35);
    // ufuga yakin isikta golge uzar ve solar
    return mix(1.0, vis, smoothstep(0.12, 0.30, lightDir.y));
}

#endif
