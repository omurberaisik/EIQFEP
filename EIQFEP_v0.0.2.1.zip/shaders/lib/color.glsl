#ifndef EIQ_COLOR
#define EIQ_COLOR
#include "/lib/common.glsl"

// =============================================================================
//  Renk: ton esleme (SDR + HDR), derecelendirme, kodlama.
//  Sahne-referansli dogrusal Rec.709 girer; 1.0 = "kagit beyazi".
// =============================================================================
const float EXPOSURE_KEY = 0.24;

// ---- SDR: log-uzayda S-egrisi (Naka-Rushton), renk korumali + dogal beyaza kayma
float nrCurve(float x, float n, float k) {
    float xn = pow(max(x, 0.0), n);
    return xn / (xn + pow(k, n));
}
vec3 nrCurve3(vec3 x, float n, float k) {
    vec3 xn = pow(max(x, vec3(0.0)), vec3(n));
    return xn / (xn + vec3(pow(k, n)));
}
vec3 tonemapEIQ(vec3 c) {
    c = max(c, vec3(0.0));
    const float n = 1.15;
    const float k = 0.67;   // nrCurve(0.18) = 0.18
    float m = max(c.r, max(c.g, c.b));
    vec3 pc = nrCurve3(c, n, k);                              // kanal basina: dogal desature
    vec3 rc = c * (nrCurve(m, n, k) / max(m, 1e-5));          // oran korumali: doygun kalir
    float t = 0.22 + 0.45 * smoothstep(1.5, 10.0, m);
    return mix(rc, pc, t);
}


// ---- Alternatif ton esleme egrileri (TONEMAP_MODE) -----------------------------
vec3 tonemapACES(vec3 x) {                       // Narkowicz ACES uyarlamasi
    x = max(x, vec3(0.0)) * 0.85;
    return saturate((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14));
}
vec3 hableCurve(vec3 x) {
    const float A = 0.15, B = 0.50, C = 0.10, D = 0.20, E = 0.02, F = 0.30;
    return ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F;
}
vec3 tonemapFilmic(vec3 x) {                     // Hable (Uncharted 2)
    x = max(x, vec3(0.0)) * 2.0;
    return saturate(hableCurve(x) / hableCurve(vec3(11.2)).x);
}
vec3 tonemapNeutral(vec3 c) {                    // Khronos PBR Neutral
    c = max(c, vec3(0.0));
    const float startCompression = 0.8 - 0.04;
    const float desaturation = 0.15;
    float x = min(c.r, min(c.g, c.b));
    float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
    c -= offset;
    float peak = max(c.r, max(c.g, c.b));
    if (peak < startCompression) return c;
    const float d = 1.0 - startCompression;
    float newPeak = 1.0 - d * d / (peak + d - startCompression);
    c *= newPeak / peak;
    float g = 1.0 - 1.0 / (desaturation * (peak - newPeak) + 1.0);
    return mix(c, vec3(newPeak), g);
}
// ---- AgX (Troy Sobotka) : log-uzayda kodlama + 6. derece polinom S-egrisi, nötr dogal desature
//      (matrisler yaygin GLSL portu; 'Punchy' bakisi: guc 1.35, doygunluk 1.4)
vec3 agxContrast(vec3 x) {
    vec3 x2 = x * x, x4 = x2 * x2;
    return +15.5 * x4 * x2 - 40.14 * x4 * x + 31.96 * x4 - 6.868 * x2 * x + 0.4298 * x2 + 0.1191 * x - 0.00232;
}
vec3 tonemapAgX(vec3 c, bool punchy) {
    const mat3 agxIn  = mat3(0.842479062253094, 0.0423282422610123, 0.0423756549057051,
                             0.0784335999999992, 0.878468636469772, 0.0784336,
                             0.0792237451477643, 0.0791661274605434, 0.879142973793104);
    const mat3 agxOut = mat3(1.19687900512017, -0.0528968517574562, -0.0529716355144438,
                            -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
                            -0.0990297440797205, -0.0989611768448433, 1.15107367264116);
    const float minEv = -12.47393, maxEv = 4.026069;
    c = agxIn * max(c, vec3(1e-10));
    c = clamp(log2(c), vec3(minEv), vec3(maxEv));
    c = (c - minEv) / (maxEv - minEv);
    c = agxContrast(c);
    if (punchy) {
        c = pow(max(c, vec3(0.0)), vec3(1.35));
        float l = luma(c);
        c = l + 1.40 * (c - l);
    }
    c = agxOut * c;
    return pow(saturate(c), vec3(2.2));              // ekran-referansli -> dogrusal (sonra sRGB kodlanir)
}
vec3 tonemapSDR(vec3 c) {
#if TONEMAP_MODE == 4
    return tonemapAgX(c, false);
#elif TONEMAP_MODE == 5
    return tonemapAgX(c, true);
#elif TONEMAP_MODE == 1
    return tonemapACES(c);
#elif TONEMAP_MODE == 2
    return tonemapFilmic(c);
#elif TONEMAP_MODE == 3
    return tonemapNeutral(c);
#else
    return tonemapEIQ(c);
#endif
}

// ---- Renk sicakligi: -1 serin (mavi) ... +1 sicak (turuncu), sahne-lineer uzayda
vec3 whiteBalance(vec3 c, float temp) {
    return c * vec3(1.0 + 0.16 * temp, 1.0 + 0.02 * temp, 1.0 - 0.18 * temp);
}

// ---- HDR: lineer govde + yumusak omuz (tepe parlakliga dogru), ton korumali
vec3 tonemapHDR(vec3 c, float peakRel) {
    c = max(c, vec3(0.0));
    float P = max(peakRel, 1.5);
    float K = 0.70 * min(P, 3.0);
    float m = max(c.r, max(c.g, c.b));
    float f = (m <= K) ? m : K + (P - K) * (1.0 - exp(-(m - K) / (P - K)));
    vec3 o = c * (f / max(m, 1e-5));
    float t = smoothstep(K, P * 1.4, m) * 0.45;      // cok parlakta beyaza dogru
    return mix(o, vec3(f), t);
}

// ---- Derecelendirme (sahne-lineer uzayda)
vec3 gradeColor(vec3 c, float contrast, float saturation) {
    c = pow(max(c, vec3(1e-5)) / 0.18, vec3(contrast)) * 0.18;
    float l = luma(c);
    c = max(mix(vec3(l), c, saturation), vec3(0.0));
#ifdef VIBRANCE
    // Canlilik: yalnizca soluk renkleri guclendirir, zaten doygun olanlara ve gri tonlara dokunmaz
    float mx = max(c.r, max(c.g, c.b)), mn = min(c.r, min(c.g, c.b));
    float s = (mx - mn) / max(mx, 1e-4);
    c = mix(vec3(luma(c)), c, 1.0 + E_VIBRANCE * (1.0 - s) * (1.0 - s) * smoothstep(0.0, 0.06, mx - mn));
    c = max(c, vec3(0.0));
#endif
    return c;
}

// ---- Kodlama
vec3 encodeScRGBnl(vec3 x) {
    return sign(x) * linearToSrgb(abs(x));
}

// Ucgen dagilimli dither (-1..1)
float triDither(vec2 fc, int frame) {
    vec4 n = blueNoise4(fc);
    return n.x + n.y - 1.0;
}

#endif
