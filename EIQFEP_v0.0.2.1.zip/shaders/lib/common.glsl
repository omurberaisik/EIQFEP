#ifndef EIQ_COMMON
#define EIQ_COMMON
#include "/lib/settings.glsl"

#define PI      3.14159265359
#define TAU     6.28318530718
#define INV_PI  0.31830988618

#ifndef EIQ_DIM
  #define EIQ_DIM 0
#endif

// ---- Ortak uniform'lar ------------------------------------------------------
uniform float frameTimeCounter;
uniform int   frameCounter;
uniform float viewWidth;
uniform float viewHeight;
uniform float near;
uniform float far;
uniform float rainStrength;
uniform float wetness;
uniform float sunAngle;
uniform int   isEyeInWater;
uniform int   moonPhase;
uniform int   worldDay;
uniform float nightVision;
uniform float blindness;
uniform ivec2 eyeBrightnessSmooth;
uniform vec3  cameraPosition;
uniform vec3  previousCameraPosition;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;
uniform vec3  shadowLightPosition;
uniform vec3  fogColor;
uniform vec4  lightningBoltPosition;
uniform float thunderStrength;
uniform sampler2D noisetex;
uniform mat4  gbufferModelView;
uniform mat4  gbufferModelViewInverse;
uniform mat4  gbufferProjection;
uniform mat4  gbufferProjectionInverse;
uniform mat4  gbufferPreviousModelView;
uniform mat4  gbufferPreviousProjection;

// ---- Golge / dunya sabitleri (iki asamada da gorunur) -------------------------
#if EIQ_DIM == 1
  const float sunPathRotation = -48.0;   // End: sabit "Goz" isigi ufka daha yakin (uzun golgeler)
#elif EIQ_DIM == -1
  const float sunPathRotation = -62.0;   // Nether: sabit "Kor Goz" isigi ufka yakin (tavan ustunde uzun golgeler)
#else
  const float sunPathRotation = -25.0;
#endif
const int   shadowMapResolution = SHADOW_RES;
const float shadowDistance = float(SHADOW_DISTANCE);
const float shadowIntervalSize = 2.0;
const float wetnessHalflife = 100.0;
const float drynessHalflife = 60.0;

// ---- Tampon bicimleri / kalicilik (yalnizca fragment asamasi) ----------------
#ifdef FSH
const int  colortex0Format = R11F_G11F_B10F;   // sahne rengi (HDR)
const int  colortex1Format = RGBA16;           // normal(oct) + isik haritasi
const int  colortex2Format = RGBA8;            // malzeme
const int  colortex3Format = RGBA16F;          // TAA gecmisi
const int  colortex4Format = RGBA16F;          // bloom kaynagi + log-luma
const int  colortex5Format = RGBA16F;          // kalici: pozlama
const int  colortex6Format = RGBA16F;          // su katmani (renk + kapsama)
const int  colortex7Format = RGBA16F;          // gokyuzu onbellegi: atmosfer (a = gecerlilik)
const int  colortex8Format = RGBA16F;          // gokyuzu onbellegi: bulut (rgb + gecirgenlik)
const bool colortex3Clear  = false;
const bool colortex5Clear  = false;
const bool colortex7Clear  = false;
const bool colortex8Clear  = false;
const bool colortex4MipmapEnabled = true;
const bool shadowtex0Mipmap = false;
const bool shadowtex1Mipmap = false;
const float centerDepthHalflife = 1.0;
#endif

uniform sampler2D depthtex0;   // her sey (saydam dahil)
uniform sampler2D depthtex1;   // saydamsiz

// Distant Horizons: uzak arazi ayri derinlik tamponunda (DH kuruluyken Iris DISTANT_HORIZONS tanimlar)
#ifndef DISTANT_HORIZONS
vec3 dhViewPosSafe(vec2 uv, float d) { return vec3(0.0, 0.0, -1.0); }
#endif
#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;
uniform mat4 dhProjectionInverse;
vec3 dhViewPos(vec2 uv, float d) {
    vec4 v = dhProjectionInverse * vec4(vec3(uv, d) * 2.0 - 1.0, 1.0);
    return v.xyz / v.w;
}
vec3 dhViewPosSafe(vec2 uv, float d) { return dhViewPos(uv, d); }
#endif


// ---- Temel matematik --------------------------------------------------------
float saturate(float x) { return clamp(x, 0.0, 1.0); }
vec2  saturate(vec2 x)  { return clamp(x, 0.0, 1.0); }
vec3  saturate(vec3 x)  { return clamp(x, 0.0, 1.0); }
float sq(float x) { return x * x; }
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

vec3 srgbToLinear(vec3 c) {
    return mix(c / 12.92, pow((c + 0.055) / 1.055, vec3(2.4)), step(vec3(0.04045), c));
}
vec3 linearToSrgb(vec3 c) {
    c = max(c, 0.0);
    return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(vec3(0.0031308), c));
}

// ---- Gurultu ----------------------------------------------------------------
float ign(vec2 fragCoord, int frame) {
    fragCoord += 5.588238 * float(frame & 63);
    return fract(52.9829189 * fract(dot(fragCoord, vec2(0.06711056, 0.00583715))));
}

uint pcgHash(uint v) {
    uint state = v * 747796405u + 2891336453u;
    uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
    return (word >> 22u) ^ word;
}
float hash13(vec3 p) {
    uvec3 q = uvec3(ivec3(floor(p)));
    uint h = pcgHash(q.x + pcgHash(q.y + pcgHash(q.z)));
    return float(h) * (1.0 / 4294967295.0);
}
float hash12(vec2 p) {
    uvec2 q = uvec2(ivec2(floor(p)));
    uint h = pcgHash(q.x + pcgHash(q.y));
    return float(h) * (1.0 / 4294967295.0);
}
vec2 hash22(vec2 p) {
    uvec2 q = uvec2(ivec2(floor(p)));
    uint h = pcgHash(q.x + pcgHash(q.y));
    uint h2 = pcgHash(h);
    return vec2(float(h), float(h2)) * (1.0 / 4294967295.0);
}

float vnoise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float n000 = hash13(i);
    float n100 = hash13(i + vec3(1, 0, 0));
    float n010 = hash13(i + vec3(0, 1, 0));
    float n110 = hash13(i + vec3(1, 1, 0));
    float n001 = hash13(i + vec3(0, 0, 1));
    float n101 = hash13(i + vec3(1, 0, 1));
    float n011 = hash13(i + vec3(0, 1, 1));
    float n111 = hash13(i + vec3(1, 1, 1));
    return mix(mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y),
               mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y), u.z);
}
float vnoise2(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash12(i), hash12(i + vec2(1, 0)), u.x),
               mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), u.x), u.y);
}
float fbm3(vec3 p, int oct) {
    float a = 0.5, s = 0.0;
    for (int i = 0; i < oct; i++) {
        s += a * vnoise3(p);
        p = p * 2.03 + vec3(17.1, 9.2, 5.7);
        a *= 0.5;
    }
    return s;
}
float fbm2(vec2 p, int oct) {
    float a = 0.5, s = 0.0;
    for (int i = 0; i < oct; i++) {
        s += a * vnoise2(p);
        p = p * 2.03 + vec2(17.1, 9.2);
        a *= 0.5;
    }
    return s;
}

// ---- Mavi gurultu (void-and-cluster, 128x128 RGBA; kanallar bagimsiz) ----------
// Doku yoksa interleaved-gradient gurultusune duser. Zamansal: altin oran kaymasi.
vec4 blueNoise4(vec2 fragCoord) {
    ivec2 sz = textureSize(noisetex, 0);
    int fr = (USE_TAA != 0) ? (frameCounter & 63) : 0;
    if (sz.x >= 64) {
        vec4 n = texelFetch(noisetex, ivec2(fragCoord) & (sz - 1), 0);
        return fract(n + 0.6180339887 * float(fr));
    }
    float a = ign(fragCoord, fr);
    return vec4(a, fract(a * 7.31 + 0.37), fract(a * 3.17 + 0.71), fract(a * 5.13 + 0.13));
}

// Vogel diski: i. ornek, toplam n, donme rot
vec2 vogel(int i, int n, float rot) {
    float r = sqrt((float(i) + 0.5) / float(n));
    float th = float(i) * 2.39996323 + rot * TAU;
    return r * vec2(cos(th), sin(th));
}

// ---- Normal paketleme (oktahedral) -------------------------------------------
vec2 octEncode(vec3 n) {
    n /= (abs(n.x) + abs(n.y) + abs(n.z));
    vec2 e = n.xy;
    if (n.z < 0.0) e = (1.0 - abs(n.yx)) * vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
    return e * 0.5 + 0.5;
}
vec3 octDecode(vec2 f) {
    f = f * 2.0 - 1.0;
    vec3 n = vec3(f, 1.0 - abs(f.x) - abs(f.y));
    float t = saturate(-n.z);
    n.xy += vec2(n.x >= 0.0 ? -t : t, n.y >= 0.0 ? -t : t);
    return normalize(n);
}

// ---- Konum yeniden olusturma --------------------------------------------------
vec3 viewPosFromDepth(vec2 uv, float depth) {
    vec4 ndc = vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    vec4 v = gbufferProjectionInverse * ndc;
    return v.xyz / v.w;
}
vec3 projectView(vec3 viewPos) {  // -> uv + depth, 0..1
    vec4 c = gbufferProjection * vec4(viewPos, 1.0);
    return c.xyz / c.w * 0.5 + 0.5;
}
float linearizeDepth(float d) {
    return (2.0 * near * far) / (far + near - (d * 2.0 - 1.0) * (far - near));
}
vec3 viewToPlayer(vec3 v) { return (gbufferModelViewInverse * vec4(v, 1.0)).xyz; }
vec3 playerToView(vec3 p) { return (gbufferModelView * vec4(p, 1.0)).xyz; }

// ---- TAA jitter (NDC) ----------------------------------------------------------
float halton(int i, int b) {
    float f = 1.0, r = 0.0;
    for (int k = 0; k < 8; k++) {
        if (i <= 0) break;
        f /= float(b);
        r += f * float(i - (i / b) * b);
        i /= b;
    }
    return r;
}
vec2 taaJitter() {
#if USE_TAA
    int i = (frameCounter & 15) + 1;
    return (vec2(halton(i, 2), halton(i, 3)) - 0.5) * 2.0 * TAA_JITTER / vec2(viewWidth, viewHeight);
#else
    return vec2(0.0);
#endif
}

#endif
