#ifndef EIQ_ENDSKY
#define EIQ_ENDSKY
// =============================================================================
//  End gokyuzu. sky.glsl icinden (starField / shootingStar tanimlandiktan sonra) eklenir.
//
//  "Boslugun Gozu": gokte sabit, devasa bir kara delik. Golge yaricapi ~2.9 derece (gunesin ~5 kati).
//   - olay ufku (siyah disk), foton halkasi, Doppler isiklandirmali yigilma diski (kenardan bakis),
//     golgenin uzerinden/altindan bukulen "arka disk" yayi
//   - kutlecekimsel mercek: arkadaki yildiz ve bulutsu ornekleme yonu merkeze dogru bukulur
//     (Einstein halkasi kendiliginden olusur)
//  Ayni yon, End'in anahtar isigi ve golge isigi yonudur: Gozun isigi dunyada golge dusurur.
// =============================================================================
#include "/lib/blackhole.glsl"
const float EYE_R0 = 0.062;

// Goz yonu = End'in golge isigi yonu (shadowLightPosition). Gecersizse sabit yedek yon.
vec3 endEyeDir() {
    vec3 s = shadowLightPosition;
    if (dot(s, s) < 1e-3) return normalize(vec3(0.35, 0.55, -0.75));
    return normalize(mat3(gbufferModelViewInverse) * s);
}

void eyeBasisFor(vec3 E, out vec3 ax, out vec3 ay) {
    vec3 up = abs(E.y) < 0.98 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    ax = normalize(cross(up, E));
    ay = cross(E, ax);
}
void eyeBasis(out vec3 E, out vec3 ax, out vec3 ay) {
    E = endEyeDir();
    eyeBasisFor(E, ax, ay);
}

BHPal endEyePal() {
    BHPal pal;
    pal.inner = vec3(1.00, 0.92, 0.80);
    pal.mid   = vec3(1.00, 0.52, 0.18);
    pal.outer = vec3(0.72, 0.14, 0.52);
    pal.halo  = vec3(1.00, 0.55, 0.30);
    pal.gain  = SUN_S;
    return pal;
}

// Arka plan ornekleme yonu: goze yakin piksellerde merkeze dogru bukulur
vec3 endEyeLens(vec3 rd) {
#if EYE_DETAIL >= 2 && defined(END_EYE)
    vec3 E, ax, ay;
    eyeBasis(E, ax, ay);
    float cd = dot(rd, E);
    if (cd < 0.3) return rd;
    float R0 = EYE_R0 * END_EYE_SIZE;
    vec2 p = vec2(dot(rd, ax), dot(rd, ay)) / (cd * R0);
    vec2 pl = blackHoleLens(p);
    return normalize(E + (ax * pl.x + ay * pl.y) * R0);
#else
    return rd;
#endif
}

// Goz katmani: donus = isima, cover = arka plani ne kadar ortuyor
vec3 endEyeEmit(vec3 rd, int detail, out float cover) {
    cover = 0.0;
#ifdef END_EYE
    vec3 E, ax, ay;
    eyeBasis(E, ax, ay);
    float cd = dot(rd, E);
    if (cd < 0.15) return vec3(0.0);
    float R0 = EYE_R0 * END_EYE_SIZE;
    vec2 p = vec2(dot(rd, ax), dot(rd, ay)) / (cd * R0);
    float pw = 2.0 / (gbufferProjection[1][1] * viewHeight) / R0;
    return blackHoleEmit(p, pw, detail, endEyePal(), cover);
#else
    return vec3(0.0);
#endif
}

// Renkli, akisli bulutsu: alan bukmeli fbm, mor tabaka + eflatun cekirdek + turkuaz iplikler + toz seritleri
vec3 endNebula(vec3 rd) {
#if NEB_OCT > 0 && defined(END_NEBULA)
    float t = frameTimeCounter * 0.006;
    vec3 q = rd * 2.4;
    float w = fbm3(q + vec3(0.0, t, 0.0), 3);
    vec3 qw = q;
  #if NEB_OCT >= 3
    qw += 1.6 * vec3(w, fbm3(q + 4.1 + t, 2), 0.7 * w);
  #endif
    float d  = fbm3(qw * 1.15 + 7.3, NEB_OCT);
    float d2 = fbm3(qw * 2.10 - 3.7 + t, max(NEB_OCT - 1, 1));
    float dust = fbm3(qw * 1.60 + 21.0, 3);
    float dens = smoothstep(0.42, 0.82, d);
    vec3 c = mix(vec3(0.05, 0.02, 0.20), vec3(0.34, 0.09, 0.58), dens);
    c = mix(c, vec3(0.95, 0.18, 0.60), smoothstep(0.55, 0.95, d) * smoothstep(0.35, 0.80, d2));
    c = mix(c, vec3(0.10, 0.80, 0.78), smoothstep(0.62, 0.90, d2) * (1.0 - dens * 0.4) * 0.8);
    float lane = 1.0 - 0.75 * smoothstep(0.50, 0.72, dust);
    vec3 gn = normalize(vec3(0.30, 0.90, -0.40));
    float bias = 0.45 + 0.55 * exp(-sq(dot(rd, gn)) / (2.0 * 0.5 * 0.5));   // galaktik duzleme yigilir
    return c * (dens * dens * lane * bias) * (SUN_S * 0.10);
#else
    return vec3(0.0);
#endif
}

// Ucuz bulutsu (yansimalar icin): tek fbm
vec3 endNebulaCheap(vec3 rd) {
#ifdef END_NEBULA
    float d = fbm3(rd * 2.8 + 7.3, 2);
    float k = smoothstep(0.40, 0.80, d);
    return mix(vec3(0.10, 0.04, 0.30), vec3(0.50, 0.14, 0.62), k) * k * (SUN_S * 0.05);
#else
    return vec3(0.0);
#endif
}

#if defined(END_AURORA) && AURORA_STEPS > 0
// End aurorasi: her zaman gorunur, turkuaz -> eflatun perdeler
vec3 endAurora(vec3 rd, float jit) {
    if (rd.y < 0.02) return vec3(0.0);
    float t = frameTimeCounter;
    vec3 acc = vec3(0.0);
    for (int i = 0; i < AURORA_STEPS; i++) {
        float f = (float(i) + jit) / float(AURORA_STEPS);
        float alt = 2500.0 + f * 5000.0;
        vec2 s = rd.xz / (rd.y + 0.10) * alt * 0.00035;
        float w = fbm2(s * 0.8 + vec2(t * 0.010, -t * 0.007), 3);
        float band = fbm2(vec2(s.x * 0.5 + w * 2.2, s.y * 0.5 - w * 1.4) + 9.0, 2) / 0.75;
        float ridge = pow(saturate(1.0 - abs(band - 0.5) * 4.0), 2.0);
        float flick = 0.65 + 0.35 * sin(t * 1.1 + w * 12.0 + f * 6.0);
        vec3 c = mix(vec3(0.10, 0.95, 0.70), vec3(0.85, 0.20, 0.95), smoothstep(0.25, 1.0, f));
        acc += c * ridge * flick * (1.0 - 0.5 * f);
    }
    acc /= float(AURORA_STEPS);
    return acc * smoothstep(0.02, 0.22, rd.y) * (SUN_S * 0.055) * AURORA_STRENGTH;
}
#endif

// Bosluk: ufkin altinda kendi etrafinda yavasca donen girdap
vec3 endAbyss(vec3 rd) {
    float below = smoothstep(0.02, -0.30, rd.y);
    if (below <= 0.0) return vec3(0.0);
    float rho = acos(clamp(-rd.y, -1.0, 1.0));      // 0 = nadir
    float a = atan(rd.z, rd.x);
    float tw = a + rho * 3.2 - frameTimeCounter * 0.015;
    float n = 0.5;
#if NEB_OCT >= 2
    n = fbm2(vec2(cos(tw), sin(tw)) * (0.6 + rho * 1.6) + 3.0, 4);
#endif
    vec3 c = mix(vec3(0.010, 0.006, 0.040), vec3(0.25, 0.08, 0.42), n * n * smoothstep(1.7, 0.2, rho));
    c += vec3(0.08, 0.40, 0.50) * exp(-rho * 6.0) * 0.5;
    return c * (SUN_S * 0.05) * below;
}

vec3 endBaseGradient(vec3 rd) {
    float hz = pow(1.0 - saturate(abs(rd.y)), 3.0);
    return vec3(0.020, 0.010, 0.045) * (SUN_S * 0.22) * (0.4 + hz * 1.2);
}

vec3 endSkyFull(vec3 rd, float jit) {
    vec3 rdb = endEyeLens(rd);
    vec3 col = endBaseGradient(rd);
    col += endNebula(rdb);
    col += starField(rdb, 1.0) * 3.2;
    col += endAbyss(rd);
#if defined(END_AURORA) && AURORA_STEPS > 0
    col += endAurora(rd, jit);
#endif
#ifdef SHOOTING_STARS
    col += shootingStar(rd, 1.0) * 2.0;
#endif
    float cover;
    vec3 em = endEyeEmit(rd, EYE_DETAIL, cover);
    return col * (1.0 - cover) + em;
}

// Yansimalar icin hafif End gokyuzu
vec3 endSkyReflection(vec3 rd) {
    vec3 col = endBaseGradient(rd) + endNebulaCheap(rd) + endAbyss(rd) * 0.8;
    float cover;
    vec3 em = endEyeEmit(rd, min(EYE_DETAIL, 1), cover);
    return col * (1.0 - cover) + em;
}

#endif
