#ifndef EIQ_LIGHTING
#define EIQ_LIGHTING
#include "/lib/materials.glsl"
#include "/lib/shadows.glsl"
#include "/lib/lpv.glsl"
#include "/lib/rt.glsl"

// =============================================================================
//  Aydinlatma modeli: dogrudan (Lambert + GGX + SSS), ortam (yarikure), blok isigi,
//  emisyon. Sabitler cagiran tarafindan g_* degiskenlerine yazilir.
// =============================================================================
vec3 g_LightDir   = vec3(0.0, 1.0, 0.0);   // dunya uzayi
vec3 g_LightColor = vec3(1.0);
vec3 g_AmbUp      = vec3(0.3);
vec3 g_AmbHor     = vec3(0.3);
vec3 g_AmbGround  = vec3(0.1);

// Isin izlemeli dolayli aydinlatma sonucu (deferred doldurur; yoksa etkisiz): gokyuzu gorunurlugu ve sekme isigi
float g_RtSkyVis  = 1.0;
vec3  g_RtBounce  = vec3(0.0);

const vec3  BLOCK_COLOR     = vec3(1.00, 0.60, 0.28);
const float BLOCK_INTENSITY = 1.7;

// ---------------------------------------------------------------------------
//  Blok isigi tek noktadan alinir. 0.0.0.3'te renkli voxel isik (LPV) ornekleme burada takilacak:
//  posRel = oyuncu-gorece konum, Nw = dunya normali, lmBlock = vanilla blok isik haritasi (0..1)
// ---------------------------------------------------------------------------
vec3 blockLightAt(vec3 posRel, vec3 Nw, float lmBlock) {
    vec3 vanilla = BLOCK_COLOR * BLOCK_INTENSITY * pow(saturate(lmBlock), 3.2);
#if LPV_ACTIVE
    float fade;
    vec3 grad;
    vec3 l = lpvSample(posRel + cameraPosition, Nw, fade, grad);
    float I = max(l.r, max(l.g, l.b));
    // Renk korunur, siddet I^3.0 (vanilla pow 3.2 egrisine yakin) ve dogrusal sonum: menzil vanilla ile ayni
    vec3 lpv = l * (I * I) * BLOCK_INTENSITY * LPV_STRENGTH;
    bool rtFound = false;
#if RT_LIGHTS_ON && defined(EIQ_DEFERRED) && defined(FSH)
    // MegaIsik: piksel icin stokastik tek isik sec (LPV tepe tirmanisi) + tek renkli golge isini.
    // Maliyet sahnedeki isik sayisindan bagimsizdir; sonuc TAA ile birikir.
    if (I > 0.03 && fade > 0.0
#ifdef ADAPTIVE_QUALITY
        && dot(posRel, posRel) < 72.0 * 72.0
#endif
        ) {
        vec4 rn = blueNoise4(gl_FragCoord.xy + vec2(19.0, 7.0));
        vec3 Lrel, Lc; float Llv;
        if (rtPickLight(posRel, Nw, rn.wzyx, Lrel, Lc, Llv)) {
            rtFound = true;
            vec3 org = posRel + Nw * 0.06;
            vec3 tgt = Lrel + (rn.xyz - 0.5) * 0.7;           // kucuk alan isigi: yumusak yarigolge
            vec3 Ld = tgt - org;
            float dist = length(Ld);
            float facing = dot(Nw, Ld / max(dist, 1e-3));
            vec3 vis = rtShadowRay(org, tgt, 36);
            lpv *= mix(vec3(1.0), vis, RT_LIGHT_SHADOW);
            lpv *= mix(1.0, 0.40 + 1.00 * saturate(facing), saturate((dist - 0.8) * 0.6));
        }
    }
#endif
#ifdef LPV_DIRECTIONAL
    // Yonlu isik: yuzey ışık kaynagina bakiyorsa daha parlak, ters yone bakiyorsa daha sonuk (N.L benzeri).
    // Kaynagin hemen yaninda (gradyan ~ 0) etki yok. (Isin izleme kaynagi bulduysa gerek yok.)
    float gm = length(grad);
    if (!rtFound && gm > 1e-4) {
        float facing = saturate(dot(Nw, grad / gm));
        lpv *= mix(1.0, 0.40 + 1.00 * facing, saturate(gm * 12.0) * 0.85);   // isin izleme yolu ile ayni aralik
    }
#endif
    float conf = saturate(I * 8.0) * fade;
    return mix(vanilla, lpv, conf);
#else
    return vanilla;
#endif
}

vec3 ambientFor(vec3 Nw) {
    float u = Nw.y;
    vec3 a = mix(g_AmbHor, g_AmbUp, saturate(u));
    return mix(a, g_AmbGround, saturate(-u));
}

float minAmbientLevel() {
    return 0.010 * 4.0 * E_CAVE + nightVision * 0.12;
}

float D_GGX(float NoH, float a) {
    float a2 = a * a;
    float d = NoH * NoH * (a2 - 1.0) + 1.0;
    return a2 / (PI * d * d);
}
float V_Smith(float NoV, float NoL, float a) {
    float k = a * 0.5;
    return 0.25 / ((NoV * (1.0 - k) + k) * (NoL * (1.0 - k) + k));
}

// albedo dogrusal; Nw, Vw dunya uzayi (Vw: yuzeyden goze)
vec3 shadeSurface(vec3 albedo, vec3 Nw, vec3 Vw, vec3 posRel, vec2 lm, float ao,
                  float smoothness, float f0, float emis, float sss,
                  vec3 shadowVis, float handDist, vec3 emisTint) {
    bool metal = f0 >= 0.9;
    vec3 diffCol = metal ? vec3(0.0) : albedo;
    vec3 F0 = metal ? albedo : vec3(f0);

    vec3 L = g_LightDir;
    float NoL = dot(Nw, L);
    float NoLc = max(NoL, 0.0);
    float NoV = max(dot(Nw, Vw), 1e-3);

    // Dogrudan isik
    vec3 direct = vec3(0.0);
    if (dot(g_LightColor, vec3(1.0)) > 1e-4) {
        float roughness = max(sq(1.0 - smoothness), 0.045);
        vec3 H = normalize(L + Vw + vec3(1e-5));
        float NoH = max(dot(Nw, H), 0.0);
        float VoH = max(dot(Vw, H), 0.0);
        vec3 F = F0 + (1.0 - F0) * pow(saturate(1.0 - VoH), 5.0);
        vec3 spec = D_GGX(NoH, roughness * roughness) * V_Smith(NoV, max(NoLc, 0.02), roughness * roughness) * F;
        vec3 kd = diffCol * (1.0 - (metal ? 0.0 : f0));
        vec3 lit = (kd + spec * PI) * NoLc;
        // alt yuzey: yumusak sarma + arkadan gecis
        float wrap = saturate((NoL + 0.45) / 1.45);
        float back = pow(saturate(dot(-Vw, L)), 3.0);
        vec3 sssTerm = albedo * (wrap * 0.55 + back * 0.65) * sss;
        direct = g_LightColor * (lit * shadowVis + sssTerm * mix(shadowVis, vec3(1.0), 0.35));
    }

    // Ortam isigi
    float skyAmt = pow(saturate(lm.y), 2.4);
    vec3 amb = ambientFor(Nw) * skyAmt * ao * g_RtSkyVis;
#if EIQ_DIM == -1
    amb += netherLavaGlow(posRel + cameraPosition, Nw) * ao * g_RtSkyVis;
#endif
    vec3 ambient = diffCol * (amb + g_RtBounce);
    // Metal ortam yansimasi (kaba)
    ambient += F0 * ambientFor(reflect(-Vw, Nw)) * skyAmt * ao * smoothness * (metal ? 1.0 : 0.15);

    // Blok isigi
    vec3 block = blockLightAt(posRel, Nw, lm.x) * mix(1.0, ao, 0.6);

    // Elde tasinan isik
    float hl = 0.0;
    if (handDist > 0.0) hl = sq(saturate(1.0 - handDist)) ;
    block += BLOCK_COLOR * BLOCK_INTENSITY * 1.1 * hl * max(NoV * 0.7 + 0.3, 0.0);

    vec3 minAmb = vec3(minAmbientLevel()) * (0.5 + 0.5 * saturate(lm.y + lm.x));

    vec3 col = direct + ambient + diffCol * (block + minAmb);
    col += albedo * emisTint * (emis * EMIS_MAX * emissionScale());
    return col;
}


// =============================================================================
//  Isin izleme yardimcilari (seviye 5)
// =============================================================================
#if RT_ON
// Tek orneklik golge haritasi gorunurlugu (carpma noktalari icin ucuz)
float shadowVisSimple(vec3 posRel, vec3 Nw) {
    vec3 sc = toShadowCoord(posRel + Nw * 0.12);
    if (any(lessThan(sc.xy, vec2(0.0))) || any(greaterThan(sc.xy, vec2(1.0))) || sc.z > 1.0) return 1.0;
    return step(sc.z - 0.0009, texture(shadowtex1, sc.xy).r);
}

// Voksel carpma noktasinin yaklasik isimasi (Lambert): dogrudan isik + ortam + renkli blok isigi.
// skyProxy: gokyuzu gorunurlugu tahmini (0..1)
vec3 rtRadiance(RtHit h, float skyProxy) {
    if (rtMax3(h.emit) > 0.0) return h.emit * 4.0;               // yayicinin kendi isigi
    float NoL = saturate(dot(h.N, g_LightDir));
    vec3 direct = vec3(0.0);
    if (NoL > 0.0 && dot(g_LightColor, vec3(1.0)) > 1e-4)
        direct = g_LightColor * NoL * shadowVisSimple(h.posRel, h.N);
    vec3 amb = ambientFor(h.N) * skyProxy;
    float fade; vec3 grad;
    vec3 l = lpvSample(h.posRel + cameraPosition, h.N, fade, grad);
    float I = rtMax3(l);
    vec3 blk = l * (I * I) * BLOCK_INTENSITY * LPV_STRENGTH;
    return h.albedo * (direct + amb + blk);
}

// Kosinus agirlikli tek isin: uzun menzilli gokyuzu perdelemesi + bir sekmeli renk tasimasi.
// Yakin alan (< 1.2 blok) ekran uzayi GTAO'ya birakilir (cift sayim olmasin).
void rtGI(vec3 posRel, vec3 Nw, float lmSky, vec4 bn) {
    g_RtSkyVis = 1.0;
    g_RtBounce = vec3(0.0);
    vec3 T = normalize(abs(Nw.y) < 0.99 ? cross(Nw, vec3(0.0, 1.0, 0.0)) : cross(Nw, vec3(1.0, 0.0, 0.0)));
    vec3 B = cross(Nw, T);
    float phi = TAU * bn.z;
    float sr = sqrt(bn.w);
    vec3 dir = normalize(T * (cos(phi) * sr) + B * (sin(phi) * sr) + Nw * sqrt(max(1.0 - bn.w, 0.0)));
    RtHit h = rtTrace(posRel + Nw * 0.03, dir, 1.2, 22.0, 48);
    float vis = 1.0;
    if (h.hit) {
        vis = mix(0.0, 0.5, smoothstep(6.0, 22.0, h.t));
        float k = 1.0 - smoothstep(10.0, 22.0, h.t);
        g_RtBounce = rtRadiance(h, pow(saturate(lmSky), 2.0) * 0.7) * k * 0.9 * RT_GI_STRENGTH;
    }
    vis *= mix(1.0, luma(h.trans), 1.0);
    // Voksel izgarasinin siniri: son %25'te GI soner (toroidal sarma / eksik veri yerine lightmap'e gec)
    vec3 rr = abs(posRel + (cameraPosition - floor(cameraPosition))) / vec3(RT_EXT);
    float edgeFade = 1.0 - smoothstep(0.75, 1.0, max(rr.x, max(rr.y, rr.z)));
    g_RtSkyVis = mix(1.0, vis, saturate(0.85 * RT_GI_STRENGTH) * edgeFade);
    g_RtBounce *= edgeFade;
}
#endif

#endif
