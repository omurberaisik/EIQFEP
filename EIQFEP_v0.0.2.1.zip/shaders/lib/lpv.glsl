#ifndef EIQ_LPV
#define EIQ_LPV
#include "/lib/materials.glsl"

// =============================================================================
//  LPV: renkli voksel isik yayilimi
//
//  Goruntuler (shaders.properties):
//    voxEmit  RGBA8   (her kare temizlenir)  rgb = isik rengi, a = seviye (1 = 15)
//    voxOpac  RGBA8   (her kare temizlenir)  rgb = isik tonu (saydam) / ortalama albedo (opak), a = opaklik (1 = opak)
//    lpvImgA/B RGBA16F (kalici, ping-pong)   rgb = isik, a = bayrak: 0 hava, 1 opak(dolgu), 2 yayici
//
//  Izgara dunya koordinatina toroidal bagli: voksel = mod(floor(dunya), boyut). Oyuncu hareket
//  edince eski icerik komsulardan kendini temizler (kaynaksiz deger her adimda soner).
// =============================================================================
const ivec3 LPV_DIMS = ivec3(LPV_X, LPV_Y, LPV_Z);
const float LPV_STEP = 1.0 / 15.0;   // blok basina dogrusal sonum: vanilla ile ayni menzil (seviye L -> L-1 blok)

ivec3 lpvWrap(ivec3 v) { return ((v % LPV_DIMS) + LPV_DIMS) % LPV_DIMS; }

// Titresim: yalnizca alev/mesale/lav gibi yayicilar
float lpvFlicker(int id, ivec3 vi) {
#ifdef LIGHT_FLICKER
    if (!(id == ID_FIRE || id == ID_SOULFIRE || id == ID_EM_WARM || id == ID_EM_TORCH || id == ID_EM_CANDLE
       || id == ID_EM_FURNACE || id == ID_LAVA || id == ID_EM_SOUL || id == ID_EM_TEAL)) return 1.0;
    float h = hash13(vec3(vi));
    float t = frameTimeCounter * (7.0 + 5.0 * h);
    float n = sin(t + h * 40.0) * 0.5 + sin(t * 2.3 + h * 13.0) * 0.3 + sin(t * 5.7) * 0.2;
    return 1.0 + ((id == ID_LAVA) ? 0.03 : 0.06) * n;
#else
    return 1.0;
#endif
}

// ---------------------------------------------------------------------------
//  Orneklem (deferred ve ileri boyama): 8 komsu voksel, trilineer
// ---------------------------------------------------------------------------
#if LPV_ACTIVE
uniform sampler3D lpvTexA;

// grad: parlaklik gradyani (dunya uzayi, kaynaga dogru). 8 kosenin ayni degerlerinden ucretsiz: ek okuma yok.
// Opak (dolgu) vokseller gradyana katilmaz: duvar arkasi yalanci yon uretmesin.
vec3 lpvSample(vec3 worldPos, vec3 Nw, out float fade, out vec3 grad) {
    grad = vec3(0.0);
    vec3 ext = vec3(LPV_DIMS) * 0.5;
    vec3 d = abs(worldPos - cameraPosition) / ext;
    fade = 1.0 - smoothstep(0.70, 0.92, max(d.x, max(d.y, d.z)));
    if (fade <= 0.0) return vec3(0.0);

    vec3 p = worldPos + Nw * 0.55 - 0.5;           // voksel merkezi uzayi, yuzun on tarafindan
    ivec3 i0 = ivec3(floor(p));
    vec3 f = fract(p);
    vec4 c[8];
    for (int k = 0; k < 8; k++)
        c[k] = texelFetch(lpvTexA, lpvWrap(i0 + ivec3(k & 1, (k >> 1) & 1, (k >> 2) & 1)), 0);
    vec3 col = mix(mix(mix(c[0].rgb, c[1].rgb, f.x), mix(c[2].rgb, c[3].rgb, f.x), f.y),
                   mix(mix(c[4].rgb, c[5].rgb, f.x), mix(c[6].rgb, c[7].rgb, f.x), f.y), f.z);
#ifdef LPV_DIRECTIONAL
    float L[8];
    float airSum = 0.0, airCnt = 0.0;
    for (int k = 0; k < 8; k++) {
        L[k] = max(c[k].r, max(c[k].g, c[k].b));
        bool solid = c[k].a > 0.5 && c[k].a < 1.5;
        if (!solid) { airSum += L[k]; airCnt += 1.0; }
    }
    float airMean = airCnt > 0.0 ? airSum / airCnt : 0.0;
    for (int k = 0; k < 8; k++) {
        bool solid = c[k].a > 0.5 && c[k].a < 1.5;
        if (solid) L[k] = airMean;
    }
    grad.x = mix(mix(L[1] - L[0], L[3] - L[2], f.y), mix(L[5] - L[4], L[7] - L[6], f.y), f.z);
    grad.y = mix(mix(L[2] - L[0], L[3] - L[1], f.x), mix(L[6] - L[4], L[7] - L[5], f.x), f.z);
    grad.z = mix(mix(L[4] - L[0], L[5] - L[1], f.x), mix(L[6] - L[2], L[7] - L[3], f.x), f.y);
#endif
    return col;
}
#endif

// ---------------------------------------------------------------------------
//  Voksellestirme (shadow vertex asamasi): yuzun 4 kosesi de blogun voksel'ini yazar.
//  Fragment yerine vertex: yuzeyi isik yonune paralel (sifir alanli) yuzler de yazilir.
// ---------------------------------------------------------------------------
#if defined(VSH) && defined(SHADOW_STAGE) && LPV_ACTIVE
uniform image3D voxEmit;
uniform image3D voxOpac;

void lpvVoxelize(int id, vec3 playerPos, vec3 midBlock, vec3 voxAlbedo) {
    bool ent = id >= ID_ENT_BASE;
    vec3 wp = playerPos + cameraPosition;
    vec3 center = ent ? floor(wp) + 0.5 : wp + midBlock / 64.0;
    vec3 ext = vec3(LPV_DIMS) * 0.5 - 2.0;
    if (any(greaterThan(abs(center - cameraPosition), ext))) return;
    ivec3 vi = lpvWrap(ivec3(floor(center)));

    vec4 em = blockLightEmitter(id);
    if (!ent) {
        vec4 vo = voxelOpacity(id);
        // Opak voksellerde rgb = blogun ortalama rengi (isin izleme isabet rengi); saydamlarda isik tonu
        imageStore(voxOpac, vi, vec4(vo.w > 0.97 ? voxAlbedo : vo.rgb, vo.w));
    } else if (em.w <= 0.0) {
        return;       // isik yaymayan varlik voksellenmez
    }
    if (em.w > 0.0) {
        float lv = min(em.w / 15.0 * lpvFlicker(id, vi), 1.0);
        imageStore(voxEmit, vi, vec4(em.rgb, lv));
    }
}
#endif

#endif
