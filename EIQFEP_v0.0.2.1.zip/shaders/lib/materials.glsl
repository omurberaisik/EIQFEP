#ifndef EIQ_MATERIALS
#define EIQ_MATERIALS
#include "/lib/common.glsl"

// =============================================================================
//  Malzeme sistemi: blok kimligi tablosu + labPBR 1.3 cozumleme + islaklik.
//  Kimlikler block.properties dosyasindaki ile ayni olmalidir.
// =============================================================================
#define ID_WATER     8
#define ID_LEAVES    10
#define ID_PLANT     11      // tek blok bitki
#define ID_TALL_LO   12      // cift boy bitkinin alt yarisi
#define ID_TALL_HI   13      // cift boy bitkinin ust yarisi
#define ID_STACKED   14      // ust uste dizilen bitki: kamis, deniz otu, kelp (dunya konumuna bagli, dikissiz)
#define ID_SNOW      15      // kar: parilti
#define ID_CHORUS    67      // chorus cicegi/bitkisi: hafif parlama
#define ID_OBSIDIAN  68      // obsidyen: parlak, gokyuzunu yansitir
#define ID_PURPUR    69      // mor blok: saten
#define ID_ENDSTONE  72      // end tasi: kozmik toz parildamasi
#define ID_GLASS     20
#define ID_ICE       21
#define ID_SLIME     22
#define ID_PORTAL    30
#define ID_ENDPORTAL 31
#define ID_LAVA      40
#define ID_FIRE      41
#define ID_SOULFIRE  43
#define ID_MAGMA     42
#define ID_EM_WARM   50
#define ID_EM_COOL   51
#define ID_EM_SOUL   52
#define ID_EM_RED    53
#define ID_EM_AMETH  54
#define ID_EM_LAPIS  55
#define ID_EM_EMER   56
#define ID_EM_DIAM   57
#define ID_EM_GREEN  59
#define ID_EM_PINK   60
#define ID_EM_GLOW   58      // glowstone: sari-altin isik (seviye 15)
#define ID_NETHERRACK 80     // netherrack / nylium / nether tuglasi
#define ID_WART      81      // wart bloklari
#define ID_BASALT    82      // bazalt / blackstone ailesi
#define ID_QUARTZ    83      // kuvars
#define ID_SOULSAND  84      // ruh kumu / toprağı
#define ID_NGOLD     85      // nether altin cevheri / yaldizli blackstone
#define ID_EM_SCULK  61
#define ID_EM_TORCH  62      // mesale: seviye 14
#define ID_EM_FURNACE 63     // yanan firin: seviye 13
#define ID_EM_CANDLE 64      // yanan mum
#define ID_EM_TEAL   65      // bakir mesale/fener (turkuaz)
#define ID_EM_BUD    66      // ametist sarkit/tomurcuk: seviye 4
#define ID_METAL     70
#define ID_TINTED    99      // tinted_glass: isigi buyuk olcude keser
#define ID_STAINED0  100     // 100..115: 16 boyali cam
#define ID_STAINED1  115
#define ID_ENT_BASE  200     // 200+: isik yayan varliklar (entity.properties)
#define ID_ENT_BLAZE 200
#define ID_ENT_MAGMA 201
#define ID_ENT_GLOWSQ 202
#define ID_ENT_ALLAY 203
#define ID_ENT_FIREBALL 204
#define ID_ENT_CRYSTAL 205
#define ID_ENT_LIGHTNING 206
#define ID_ENT_XP    207

bool isPlantId(int id) { return id >= ID_PLANT && id <= ID_STACKED; }

bool isGlassId(int id) {
    return id == ID_GLASS || id == ID_TINTED || (id >= ID_STAINED0 && id <= ID_STAINED1);
}

// Boyali camin isik tonu (100 beyaz ... 115 siyah, Minecraft renk sirasi)
vec3 glassTint(int id) {
    if (id == ID_GLASS)  return vec3(0.96, 0.98, 1.00);
    if (id == ID_TINTED) return vec3(0.35, 0.30, 0.45);
    int k = id - ID_STAINED0;
    if (k == 0)  return vec3(0.95, 0.95, 0.95);   // beyaz
    if (k == 1)  return vec3(1.00, 0.55, 0.15);   // turuncu
    if (k == 2)  return vec3(0.90, 0.25, 0.90);   // eflatun
    if (k == 3)  return vec3(0.35, 0.65, 1.00);   // acik mavi
    if (k == 4)  return vec3(1.00, 0.90, 0.20);   // sari
    if (k == 5)  return vec3(0.50, 0.95, 0.20);   // limon
    if (k == 6)  return vec3(1.00, 0.55, 0.75);   // pembe
    if (k == 7)  return vec3(0.50, 0.50, 0.52);   // gri
    if (k == 8)  return vec3(0.75, 0.75, 0.78);   // acik gri
    if (k == 9)  return vec3(0.15, 0.80, 0.85);   // camgobegi
    if (k == 10) return vec3(0.55, 0.20, 0.85);   // mor
    if (k == 11) return vec3(0.20, 0.30, 0.95);   // mavi
    if (k == 12) return vec3(0.55, 0.35, 0.20);   // kahverengi
    if (k == 13) return vec3(0.25, 0.70, 0.25);   // yesil
    if (k == 14) return vec3(0.95, 0.20, 0.20);   // kirmizi
    return vec3(0.15, 0.15, 0.17);                // siyah
}

// Voksel opaklik sinifi: rgb = isik tonu, w = opaklik (1 = tam opak, 0 = acik).
// Haritada olmayan (eslesmeyen) bloklar tam opak sayilir.
vec4 voxelOpacity(int id) {
    if (id == ID_WATER)   return vec4(0.72, 0.90, 1.00, 0.30);
    if (id == ID_LEAVES)  return vec4(0.80, 0.95, 0.75, 0.32);
    if (isPlantId(id))    return vec4(1.00, 1.00, 1.00, 0.04);
    if (id == ID_ICE)     return vec4(0.80, 0.92, 1.00, 0.25);
    if (id == ID_SLIME)   return vec4(0.70, 1.00, 0.60, 0.20);
    if (id == ID_PORTAL)  return vec4(0.90, 0.60, 1.00, 0.05);
    if (id == ID_FIRE || id == ID_SOULFIRE) return vec4(1.00, 1.00, 1.00, 0.00);
    if (id == ID_TINTED)  return vec4(glassTint(id), 0.70);
    if (isGlassId(id))    return vec4(glassTint(id), 0.05);
    return vec4(1.0, 1.0, 1.0, 1.0);
}

struct Mat {
    float smoothness;   // 0 pürüzlü .. 1 ayna
    float f0;           // dielektrik F0; >= 0.9 metal işareti
    float emis;         // 0..1 (deferred'de EMIS_MAX ile çarpılır)
    float sss;          // 0..1 alt yüzey saçılması
    float porosity;     // 0..1 (ıslaklık için)
};

const float EMIS_MAX = 10.0;

bool isEmissiveId(int id) { return (id >= 40 && id <= 66); }

Mat blockMaterial(int id, vec3 albedo) {
    Mat m;
    m.smoothness = 0.06; m.f0 = 0.04; m.emis = 0.0; m.sss = 0.0; m.porosity = 0.5;
    float l = luma(albedo);
    float bright = smoothstep(0.35, 0.80, l);
    if (id == ID_LEAVES)      { m.smoothness = 0.12; m.f0 = 0.03; m.sss = 0.65; m.porosity = 0.2; }
    else if (isPlantId(id))   { m.smoothness = 0.10; m.f0 = 0.02; m.sss = 0.55; m.porosity = 0.2; }
    else if (isGlassId(id))   { m.smoothness = 0.95; m.f0 = 0.04; m.porosity = 0.0; }
    else if (id == ID_ICE)    { m.smoothness = 0.90; m.f0 = 0.04; m.sss = 0.15; m.porosity = 0.0; }
    else if (id == ID_SLIME)  { m.smoothness = 0.80; m.f0 = 0.04; m.sss = 0.50; m.porosity = 0.0; }
    else if (id == ID_METAL)  { m.smoothness = 0.78; m.f0 = 0.95; m.porosity = 0.0; }
    else if (id == ID_SNOW)   { m.smoothness = 0.32; m.f0 = 0.02; m.sss = 0.25; m.porosity = 0.0; }
    else if (id == ID_OBSIDIAN) { m.smoothness = 0.88; m.f0 = 0.06; m.porosity = 0.0; }
    else if (id == ID_PURPUR)   { m.smoothness = 0.55; m.f0 = 0.05; m.porosity = 0.1; }
    else if (id == ID_ENDSTONE) { m.smoothness = 0.12; m.f0 = 0.03; m.sss = 0.08; m.porosity = 0.1; }
    else if (id == ID_NETHERRACK) { m.smoothness = 0.10; m.f0 = 0.03; m.porosity = 0.0; }
    else if (id == ID_WART)     { m.smoothness = 0.22; m.f0 = 0.03; m.sss = 0.22; m.porosity = 0.0; }
    else if (id == ID_BASALT)   { m.smoothness = 0.38; m.f0 = 0.05; m.porosity = 0.0; }
    else if (id == ID_QUARTZ)   { m.smoothness = 0.62; m.f0 = 0.05; m.sss = 0.10; m.porosity = 0.0; }
    else if (id == ID_SOULSAND) { m.smoothness = 0.05; m.f0 = 0.02; m.porosity = 0.0; }
    else if (id == ID_NGOLD)    { m.smoothness = 0.30; m.f0 = 0.05; m.porosity = 0.0; m.emis = 0.30 * smoothstep(0.55, 0.85, l); }
    else if (id == ID_CHORUS)   { m.smoothness = 0.25; m.f0 = 0.03; m.sss = 0.30; m.emis = 0.10 + 0.20 * bright; }
#ifdef EMISSIVE_BLOCKS
    else if (id == ID_LAVA)   { m.emis = 0.60 + 0.40 * smoothstep(0.30, 0.90, l); m.porosity = 0.0; }
    else if (id == ID_EM_GLOW){ m.emis = 0.25 + 0.75 * bright; }
    else if (id == ID_FIRE || id == ID_SOULFIRE) { m.emis = 1.00; m.porosity = 0.0; }
    else if (id == ID_EM_TORCH || id == ID_EM_FURNACE || id == ID_EM_CANDLE) { m.emis = 0.12 + 0.88 * bright; }
    else if (id == ID_EM_TEAL) { m.emis = 0.12 + 0.88 * bright; }
    else if (id == ID_EM_BUD)  { m.emis = 0.42 + 0.30 * bright; m.smoothness = 0.35; }
    else if (id == ID_MAGMA)  { m.emis = 0.20 + 0.80 * bright; }
    else if (id == ID_EM_WARM){ m.emis = 0.12 + 0.88 * bright; }
    else if (id == ID_EM_COOL){ m.emis = 0.20 + 0.80 * bright; }
    else if (id == ID_EM_SOUL){ m.emis = 0.12 + 0.88 * bright; }
    else if (id == ID_EM_RED) { m.emis = 0.50 + 0.30 * bright; m.smoothness = 0.15; }
    else if (id == ID_EM_AMETH){ m.emis = 0.42 + 0.30 * bright; m.smoothness = 0.35; }
    else if (id == ID_EM_LAPIS){ m.emis = 0.28 + 0.20 * bright; m.smoothness = 0.25; }
    else if (id == ID_EM_EMER){ m.emis = 0.30 + 0.20 * bright; m.smoothness = 0.35; }
    else if (id == ID_EM_DIAM){ m.emis = 0.30 + 0.20 * bright; m.smoothness = 0.50; }
    else if (id == ID_EM_GREEN){ m.emis = 0.20 + 0.70 * bright; }
    else if (id == ID_EM_PINK){ m.emis = 0.20 + 0.70 * bright; }
    else if (id == ID_EM_SCULK){ m.emis = 0.55 * bright; }
    else if (id == ID_ENT_BLAZE)    { m.emis = 0.45 + 0.45 * bright; m.smoothness = 0.10; }
    else if (id == ID_ENT_MAGMA)    { m.emis = 0.30 + 0.60 * bright; }
    else if (id == ID_ENT_GLOWSQ)   { m.emis = 0.35 + 0.55 * bright; m.smoothness = 0.35; }
    else if (id == ID_ENT_ALLAY)    { m.emis = 0.50 + 0.40 * bright; m.smoothness = 0.30; }
    else if (id == ID_ENT_FIREBALL) { m.emis = 1.00; }
    else if (id == ID_ENT_CRYSTAL)  { m.emis = 0.55 + 0.35 * bright; m.smoothness = 0.60; }
    else if (id == ID_ENT_LIGHTNING){ m.emis = 1.00; }
    else if (id == ID_ENT_XP)       { m.emis = 1.00; }
#endif
    return m;
}

// ---------------------------------------------------------------------------
//  Isik rengi tablosu: ISIK SEVIYESI (0..15) ve RENK. 0.0.0.3'te voxel isik (LPV) bu tablodan
//  enjekte edilecek. Yalnizca gorsel parlama ile ayni renkleri paylasir; oyunun isik seviyesini
//  degistirmez. Donus: rgb renk, w = baslangic isik seviyesi (0 = isik yaymaz)
// ---------------------------------------------------------------------------
vec4 blockLightEmitter(int id) {
    if (id == ID_LAVA)      return vec4(1.00, 0.42, 0.10, 15.0);
    if (id == ID_FIRE)      return vec4(1.00, 0.55, 0.15, 15.0);
    if (id == ID_SOULFIRE)  return vec4(0.20, 0.70, 1.00, 10.0);
    if (id == ID_EM_TORCH)  return vec4(1.00, 0.62, 0.30, 14.0);
    if (id == ID_EM_FURNACE)return vec4(1.00, 0.50, 0.18, 13.0);
    if (id == ID_EM_CANDLE) return vec4(1.00, 0.68, 0.34, 6.0);
    if (id == ID_EM_TEAL)   return vec4(0.15, 0.95, 0.80, 14.0);
    if (id == ID_EM_BUD)    return vec4(0.62, 0.30, 1.00, 4.0);
    if (id == ID_MAGMA)     return vec4(1.00, 0.35, 0.08, 3.0);
    if (id == ID_EM_WARM)   return vec4(1.00, 0.62, 0.30, 15.0);
    if (id == ID_EM_GLOW)   return vec4(1.00, 0.84, 0.42, 15.0);
    if (id == ID_EM_COOL)   return vec4(0.80, 0.95, 1.00, 15.0);
    if (id == ID_EM_SOUL)   return vec4(0.20, 0.70, 1.00, 10.0);
    if (id == ID_EM_RED)    return vec4(1.00, 0.10, 0.05, 7.0);
    if (id == ID_EM_AMETH)  return vec4(0.62, 0.30, 1.00, 10.0);
    if (id == ID_EM_LAPIS)  return vec4(0.15, 0.32, 1.00, 10.0);
    if (id == ID_EM_EMER)   return vec4(0.10, 1.00, 0.35, 10.0);
    if (id == ID_EM_DIAM)   return vec4(0.20, 1.00, 0.95, 10.0);
    if (id == ID_EM_GREEN)  return vec4(0.35, 1.00, 0.30, 15.0);
    if (id == ID_EM_PINK)   return vec4(1.00, 0.55, 0.85, 15.0);
    if (id == ID_EM_SCULK)  return vec4(0.15, 0.90, 0.85, 6.0);
    if (id == ID_PORTAL)    return vec4(0.72, 0.15, 1.00, 11.0);
    // Varliklar
    if (id == ID_ENT_BLAZE)     return vec4(1.00, 0.55, 0.12, 11.0);
    if (id == ID_ENT_MAGMA)     return vec4(1.00, 0.38, 0.08, 7.0);
    if (id == ID_ENT_GLOWSQ)    return vec4(0.20, 0.90, 1.00, 8.0);
    if (id == ID_ENT_ALLAY)     return vec4(0.30, 0.70, 1.00, 8.0);
    if (id == ID_ENT_FIREBALL)  return vec4(1.00, 0.50, 0.10, 12.0);
    if (id == ID_ENT_CRYSTAL)   return vec4(0.90, 0.25, 1.00, 12.0);
    if (id == ID_ENT_LIGHTNING) return vec4(0.85, 0.90, 1.00, 15.0);
    if (id == ID_ENT_XP)        return vec4(0.45, 1.00, 0.20, 6.0);
    return vec4(0.0);
}

// labPBR 1.3 ozellik haritasi. Donus: haritanin varligi
bool decodeLabPBR(vec4 s, inout Mat m) {
    if (s.r + s.g + s.b < 0.002) return false;
    m.smoothness = s.r;
    float f = s.g * 255.0;
    m.f0 = (f >= 230.0) ? 0.95 : s.g;
    float b = s.b * 255.0;
    if (b <= 64.0) { m.porosity = b / 64.0; m.sss = 0.0; }
    else           { m.porosity = 0.0; m.sss = saturate((b - 65.0) / 190.0); }
    float e = s.a * 255.0;
    m.emis = (e < 254.5) ? e / 254.0 : 0.0;
    return true;
}

// Emisyon nihai yoğunluğu (ayar çarpanı dahil)
float emissionScale() {
#ifdef EMISSIVE_BLOCKS
    return EMISSIVE_STRENGTH;
#else
    return 1.0;
#endif
}

// ---- Islaklik ----------------------------------------------------------------
vec2 rippleNormal(vec2 p, float t) {
    // Izgara hücrelerinde rastgele halkalar
    vec2 grid = p * 2.2;
    vec2 id = floor(grid);
    vec2 acc = vec2(0.0);
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            vec2 cid = id + vec2(float(i), float(j));
            vec2 h = hash22(cid);
            vec2 c = cid + 0.2 + 0.6 * h;
            float ph = fract(t * 0.9 + hash12(cid + 7.0));
            float d = length(grid - c);
            float r = ph * 0.75;
            float w = exp(-sq((d - r) * 11.0)) * (1.0 - ph);
            vec2 dir = (grid - c) / max(d, 1e-3);
            acc += dir * w * sin((d - r) * 28.0);
        }
    }
    return acc;
}

float puddleMask(vec2 p) {
    float n = fbm2(p * 0.33, 3);
    return smoothstep(0.52, 0.66, n);
}

#endif
