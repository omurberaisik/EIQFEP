#ifndef EIQ_NETHER
#define EIQ_NETHER
// =============================================================================
//  Nether cekirdegi (0.0.0.6): biyom renkleri, sis rengi, ortam isigi, Kor Goz yonu.
//  atmosphere.glsl icinden (SUN_S tanimlandiktan sonra) eklenir.
//
//  Biyom tespiti: Nether'de fogColor biyoma ozgudur ve Minecraft tarafindan yumusatilir:
//   nether_wastes 0x330808, crimson 0x330303, warped 0x1a051a, soul_sand_valley 0x1b4745, basalt 0x685f70
// =============================================================================

// x = kirmizi (wastes/crimson), y = warped, z = ruh kumu vadisi, w = bazalt deltasi (toplam 1)
vec4 netherBiome() {
    vec3 f = fogColor;
    float l = luma(f);
    float soul = smoothstep(0.07, 0.19, f.g - f.r);
    float basalt = smoothstep(0.24, 0.34, l) * (1.0 - soul);
    float warped = smoothstep(0.45, 0.90, f.b / max(f.r, 1e-3)) * (1.0 - soul) * (1.0 - basalt);
    float red = max(1.0 - soul - basalt - warped, 0.0);
    return vec4(red, warped, soul, basalt);
}

// Biyomun isik/duman rengi (normalize edilmis, parlak)
vec3 netherTint(vec4 w) {
    float crim = 1.0 - smoothstep(0.03, 0.16, fogColor.g / max(fogColor.r, 1e-3));   // 1 = crimson
    vec3 red = mix(vec3(1.00, 0.30, 0.08), vec3(1.00, 0.13, 0.06), crim);
    vec3 warped = vec3(0.30, 0.50, 1.00);
    vec3 soul = vec3(0.12, 0.72, 0.90);
    vec3 basalt = vec3(0.62, 0.55, 0.66);
    return red * w.x + warped * w.y + soul * w.z + basalt * w.w;
}

float netherFogK(vec4 w) { return w.x * 1.0 + w.y * 1.15 + w.z * 1.30 + w.w * 1.75; }

// Uzak sis / ufuk rengi. y: dunya yuksekligi; lav denizine yakin = turuncu parilti
vec3 netherHaze(vec3 tint, float y) {
    float lowK = smoothstep(80.0, 30.0, y);
    vec3 c = mix(tint * 0.85, mix(tint, vec3(1.0, 0.38, 0.10), 0.55) * 1.55, lowK);
    return c * (0.045 * SUN_S) * (0.6 + 0.4 * NETHER_FOG_GLOW + 0.4);
}

// Lav denizinin (y ~ 31) isigi: asagidan gelen turuncu isik, yukseldikce soner
vec3 netherLavaGlow(vec3 wpos, vec3 Nw) {
#ifdef NETHER_LAVA_GLOW
    float h = exp(-max(wpos.y - 32.0, 0.0) / 16.0);
    float down = 0.55 + 0.45 * saturate(-Nw.y) + 0.20 * (1.0 - abs(Nw.y));
    return vec3(1.0, 0.36, 0.09) * (h * down * 0.060 * SUN_S * NETHER_AMBIENT);
#else
    return vec3(0.0);
#endif
}

// Kor Goz: End'deki gibi golge isigi yonu (shadowLightPosition); gecersizse sabit yedek yon
vec3 netherEyeDir() {
    vec3 s = shadowLightPosition;
    if (dot(s, s) < 1e-3) return normalize(vec3(0.45, 0.45, -0.77));
    return normalize(mat3(gbufferModelViewInverse) * s);
}

#endif
