#ifndef EIQ_NETHERFOG
#define EIQ_NETHERFOG
#include "/lib/atmosphere.glsl"
#include "/lib/lpv.glsl"
// Nether sisi (0.0.0.6): biyom renkli, lav denizine dogru yogunlasan, LPV isiklarindan isik toplayan hacimsel sis
vec3 netherFog(vec3 color, vec3 rd, float dist, float jit) {
    vec4 nb = netherBiome();
    vec3 tint = netherTint(nb);
    float sigma = 0.0075 * NETHER_FOG_DENSITY * netherFogK(nb);
    float y0 = cameraPosition.y;
  #if NETHER_FOG_STEPS > 0
    float maxD = min(dist, 128.0);
    float ds = maxD / float(NETHER_FOG_STEPS);
    float T = 1.0;
    vec3 insc = vec3(0.0);
    for (int i = 0; i < NETHER_FOG_STEPS; i++) {
        float s = (float(i) + jit) * ds;
        vec3 wp = cameraPosition + rd * s;
        float dens = 1.0 + 1.4 * smoothstep(75.0, 30.0, wp.y);
    #if NETHER_FOG_STEPS >= 12
        dens *= 0.60 + 0.80 * fbm3(wp * vec3(0.045, 0.065, 0.045) + vec3(0.0, frameTimeCounter * 0.03, frameTimeCounter * 0.012), 2);
    #endif
        float sg = sigma * dens;
        vec3 lightc = vec3(0.0);
    #if LPV_ACTIVE
        float fade; vec3 grad;
        vec3 l = lpvSample(wp, vec3(0.0), fade, grad);
        float I = max(l.r, max(l.g, l.b));
        lightc = l * (I * I) * (1.7 * 2.2 * LPV_STRENGTH * NETHER_FOG_GLOW) * fade;
    #endif
        float stepT = exp(-sg * ds);
        insc += T * (1.0 - stepT) * (netherHaze(tint, wp.y) + lightc);
        T *= stepT;
    }
    if (dist > maxD) {
        float Tf = exp(-sigma * 1.3 * (dist - maxD));
        insc += T * (1.0 - Tf) * netherHaze(tint, y0 + rd.y * dist);
        T *= Tf;
    }
    return color * T + insc;
  #else
    float T = exp(-dist * sigma * (1.0 + 0.5 * smoothstep(75.0, 30.0, y0)));
    return color * T + netherHaze(tint, y0) * (1.0 - T);
  #endif
}
#endif
