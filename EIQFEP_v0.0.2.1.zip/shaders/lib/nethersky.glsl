#ifndef EIQ_NETHERSKY
#define EIQ_NETHERSKY
// =============================================================================
//  Nether "gokyuzu" (tavan ustu ve render mesafesi otesi): kor bulutlari + Kor Goz (kara delik).
//  sky.glsl icinden (starField tanimlandiktan sonra) eklenir.
//  Kor Goz'un diski biyom rengini tasir: kirmizi wastes'te lav-turuncu, ruh vadisinde camgobegi.
// =============================================================================
#include "/lib/blackhole.glsl"
const float NEYE_R0 = 0.070;

BHPal netherEyePal(vec3 tint) {
    BHPal pal;
    pal.inner = mix(vec3(1.00, 0.95, 0.82), tint, 0.18);
    pal.mid   = mix(tint, vec3(1.0, 0.62, 0.25), 0.35) * 1.15;
    pal.outer = tint * tint * 0.55;
    pal.halo  = tint;
    pal.gain  = SUN_S;
    return pal;
}

vec3 netherEyeLens(vec3 rd) {
#if defined(NETHER_EYE) && EYE_DETAIL >= 2
    vec3 E = netherEyeDir();
    vec3 up = abs(E.y) < 0.98 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 ax = normalize(cross(up, E));
    vec3 ay = cross(E, ax);
    float cd = dot(rd, E);
    if (cd < 0.3) return rd;
    float R0 = NEYE_R0 * NETHER_EYE_SIZE;
    vec2 p = vec2(dot(rd, ax), dot(rd, ay)) / (cd * R0);
    vec2 pl = blackHoleLens(p);
    return normalize(E + (ax * pl.x + ay * pl.y) * R0);
#else
    return rd;
#endif
}

vec3 netherEyeEmit(vec3 rd, vec3 tint, int detail, out float cover) {
    cover = 0.0;
#ifdef NETHER_EYE
    vec3 E = netherEyeDir();
    vec3 up = abs(E.y) < 0.98 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 ax = normalize(cross(up, E));
    vec3 ay = cross(E, ax);
    float cd = dot(rd, E);
    if (cd < 0.15) return vec3(0.0);
    float R0 = NEYE_R0 * NETHER_EYE_SIZE;
    vec2 p = vec2(dot(rd, ax), dot(rd, ay)) / (cd * R0);
    float pw = 2.0 / (gbufferProjection[1][1] * viewHeight) / R0;
    return blackHoleEmit(p, pw, detail, netherEyePal(tint), cover);
#else
    return vec3(0.0);
#endif
}

vec3 netherSkyFull(vec3 rd, float jit) {
    vec4 nb = netherBiome();
    vec3 tint = netherTint(nb);
    vec3 haze = netherHaze(tint, cameraPosition.y);
    vec3 rdb = netherEyeLens(rd);
    // ufuk parlak, yukari koyu; ufkun altinda lavin yukari vuran isigi
    float up = saturate(rd.y);
    float dn = smoothstep(0.0, -0.45, rd.y);
    vec3 col = haze * mix(0.55, 0.10, smoothstep(0.0, 0.85, up)) * (1.0 + 2.4 * dn);
#if NEB_OCT > 0
    // alttan aydinlanan kor/kul bulutlari
    vec2 cp = rdb.xz / (abs(rdb.y) + 0.35) * 1.4 + vec2(frameTimeCounter * 0.010, -frameTimeCounter * 0.006);
    float n = fbm2(cp, min(NEB_OCT, 4));
    float cl = smoothstep(0.45, 0.80, n);
    col += tint * cl * (0.10 * SUN_S) * (0.35 + 0.65 * (1.0 - up)) * smoothstep(-0.2, 0.15, rd.y);
#endif
    col += starField(rdb, 0.5) * vec3(1.0, 0.55, 0.45) * 2.0 * smoothstep(0.1, 0.5, up);
    float cover;
    vec3 em = netherEyeEmit(rd, tint, EYE_DETAIL, cover);
    return col * (1.0 - cover) + em;
}

vec3 netherSkyReflection(vec3 rd) {
    vec4 nb = netherBiome();
    vec3 tint = netherTint(nb);
    vec3 haze = netherHaze(tint, cameraPosition.y);
    float cover;
    vec3 em = netherEyeEmit(rd, tint, min(EYE_DETAIL, 1), cover);
    return haze * 0.7 * (1.0 - cover) + em;
}
#endif
