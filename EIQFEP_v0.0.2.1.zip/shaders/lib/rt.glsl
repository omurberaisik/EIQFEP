#ifndef EIQ_RT
#define EIQ_RT
#include "/lib/lpv.glsl"

// =============================================================================
//  EIQFEP isin izleme (yalnizca seviye 5): LPV voksel izgarasi uzerinde yazilim DDA.
//
//  Veri (compute pass 0 yazar, bkz. program/lpv.glsl):
//    rtGeoTex   : rgb = blok ortalama rengi (opak) / isik tonu (saydam), a = opaklik
//    rtBrickTex : 4x4x4 blokluk tugla basina 0/1 (icinde opaklik var mi)
//    lpvTexA    : LPV; a bayragi 1 = opak dolgu, 2 = isik yayici
//
//  Izleme "tugla atlamali": bos 4x4x4 tugladan tek adimda cikilir (iki seviyeli DDA etkisi).
//  Koordinatlar oyuncu-goreceli; hucreler base = floor(cameraPosition) cevresinde indekslenir,
//  boylece buyuk dunya koordinatlarinda kayan nokta hassasiyeti kaybolmaz.
//  Izgara disina cikan isin "bilinmiyor" (outside) doner: cagiran gokyuzu/golge haritasina duser.
//
//  SINIR: izgara yalnizca blok boyutunda ve opaklik bilgisi "tam blok" kabul edilir
//  (yari blok/mesale/cit de dolu sayilir). Bu yuzden gelen isinlarin baslangic hucresi yok sayilir.
// =============================================================================
#if RT_ON
uniform sampler3D rtGeoTex;
uniform sampler3D rtBrickTex;

const ivec3 RT_EXT = ivec3(LPV_X / 2 - 3, LPV_Y / 2 - 3, LPV_Z / 2 - 3);

struct RtHit {
    bool  hit;       // opak voksele carpti
    bool  outside;   // izgara disina cikti (sonuc bilinmiyor)
    float t;
    vec3  posRel;    // oyuncu-goreceli carpma noktasi
    vec3  N;         // carpilan yuzun normali (dunya)
    vec3  albedo;    // dogrusal
    vec3  emit;      // yayici ise isik rengi*seviye
    vec3  trans;     // yol boyunca renkli saydam kayip (cam, yaprak, su)
    int   steps;     // harcanan DDA adimi (olcum icin)
};

float rtMax3(vec3 v) { return max(v.r, max(v.g, v.b)); }

// ro: oyuncu-goreceli baslangic, rd: normalize yon. Hucrelerin t ilerlemesi tMin'den baslar:
// tMin'den onceki hucreler (ve baslangic hucresinin kendisi) isabet sayilmaz.
// useBricks = false: tugla atlama kapali (dogruluk testi / olcum)
RtHit rtTrace(vec3 ro, vec3 rd, float tMin, float maxT, int maxSteps, bool useBricks) {
    RtHit h;
    h.hit = false; h.outside = false; h.t = maxT; h.posRel = ro + rd * maxT;
    h.N = -rd; h.albedo = vec3(0.0); h.emit = vec3(0.0); h.trans = vec3(1.0); h.steps = 0;

    ivec3 base = ivec3(floor(cameraPosition));
    vec3 shift = cameraPosition - vec3(base);
    vec3 o = ro + shift;
    vec3 sg = vec3(rd.x >= 0.0 ? 1.0 : -1.0, rd.y >= 0.0 ? 1.0 : -1.0, rd.z >= 0.0 ? 1.0 : -1.0);
    vec3 d = sg * max(abs(rd), vec3(1e-6));
    vec3 invD = 1.0 / d;
    vec3 fwd = step(vec3(0.0), d);          // 1: bu eksende pozitif yon
    ivec3 c0 = ivec3(floor(o));
    float t = tMin;
    int axis = -1;

    for (int i = 0; i < maxSteps; i++) {
        if (t >= maxT) break;
        vec3 p = o + d * t;
        ivec3 c = ivec3(floor(p));
        if (any(greaterThan(abs(c), RT_EXT))) { h.outside = true; h.t = t; h.posRel = p - shift; break; }
        ivec3 w = lpvWrap(base + c);
        h.steps++;

        vec3 tn;
        float brick = useBricks ? texelFetch(rtBrickTex, w >> 2, 0).r : 1.0;
        if (brick < 0.001) {
            // bos tugla: cikis duzlemine atla
            vec3 bmin = vec3(c - (w & 3));
            tn = (bmin + fwd * 4.0 - o) * invD;
        } else {
            if (any(notEqual(c, c0))) {
                vec4 g = texelFetch(rtGeoTex, w, 0);
                if (g.a > 0.97) {
                    h.hit = true;
                    h.t = t;
                    h.posRel = p - shift;
                    vec3 n = vec3(0.0);
                    if (axis == 0) n.x = -sg.x; else if (axis == 1) n.y = -sg.y; else if (axis == 2) n.z = -sg.z;
                    else n = -rd;
                    h.N = n;
                    h.albedo = srgbToLinear(g.rgb);
                    vec4 L = texelFetch(lpvTexA, w, 0);
                    if (L.a > 1.5) h.emit = L.rgb;
                    break;
                } else if (g.a > 0.045) {
                    // renkli saydam kayip: cam (a<0.1) tonunu tam uygular, yaprak/su kismen sogurur
                    h.trans *= (g.a < 0.1) ? g.rgb : mix(vec3(1.0), g.rgb, 0.5) * (1.0 - g.a);
                }
            }
            tn = (vec3(c) + fwd - o) * invD;
        }
        float te = min(tn.x, min(tn.y, tn.z));
        axis = (tn.x <= tn.y) ? ((tn.x <= tn.z) ? 0 : 2) : ((tn.y <= tn.z) ? 1 : 2);
        t = max(te, t) + 1e-3;
    }
    return h;
}
RtHit rtTrace(vec3 ro, vec3 rd, float tMin, float maxT, int maxSteps) {
    return rtTrace(ro, rd, tMin, maxT, maxSteps, true);
}

// Gozlenen noktadan hedefe renkli gecirgenlik (0 = tamamen kapali). Hedef vokselin kendisi sayilmaz.
vec3 rtShadowRay(vec3 ro, vec3 target, int maxSteps) {
    vec3 dv = target - ro;
    float L = length(dv);
    if (L < 0.9) return vec3(1.0);
    RtHit h = rtTrace(ro, dv / L, 0.0, L - 0.85, maxSteps);
    return h.hit ? vec3(0.0) : h.trans;
}

// ---------------------------------------------------------------------------
//  MegaIsik: LPV alaninda "tepe tirmanisi" ile pikselin isigini veren yayiciyi stokastik sec.
//  Her adimda ust (daha parlak) komsulardan biri secilir; yayiciya ulasinca durur. Boylece
//  sahnedeki isik sayisi ne olursa olsun piksel basina 1 secim + 1 golge isini harcanir.
//  rnd: [0,1) x4 (mavi gurultu); donus: yayici bulundu mu.
// ---------------------------------------------------------------------------
#define RT_LIGHT_WALK 14
bool rtPickLight(vec3 posRel, vec3 Nw, vec4 rnd, out vec3 lightRel, out vec3 lightCol, out float lightLvl) {
    lightRel = vec3(0.0); lightCol = vec3(0.0); lightLvl = 0.0;
    ivec3 base = ivec3(floor(cameraPosition));
    vec3 pw = posRel + (cameraPosition - vec3(base)) + Nw * 0.55;
    ivec3 c = ivec3(floor(pw));
    if (any(greaterThan(abs(c), RT_EXT))) return false;
    vec4 cur = texelFetch(lpvTexA, lpvWrap(base + c), 0);
    if (cur.a > 0.5 && cur.a < 1.5) return false;               // opak dolgu icinde
    const ivec3 dirs[6] = ivec3[6](ivec3(1, 0, 0), ivec3(-1, 0, 0), ivec3(0, 1, 0),
                                   ivec3(0, -1, 0), ivec3(0, 0, 1), ivec3(0, 0, -1));
    for (int i = 0; i < RT_LIGHT_WALK; i++) {
        if (cur.a > 1.5) {
            lightRel = vec3(c) + 0.5 - (cameraPosition - vec3(base));
            lightCol = cur.rgb / max(rtMax3(cur.rgb), 1e-4);
            lightLvl = rtMax3(cur.rgb);
            return true;
        }
        float Ic = rtMax3(cur.rgb);
        // akan secim (reservoir): agirlik = yokus yonundeki fark + yayici onceligi
        float acc = 0.0;
        int pick = -1;
        vec4 pickVal = vec4(0.0);
        for (int k = 0; k < 6; k++) {
            ivec3 cn = c + dirs[k];
            if (any(greaterThan(abs(cn), RT_EXT))) continue;
            vec4 v = texelFetch(lpvTexA, lpvWrap(base + cn), 0);
            if (v.a > 0.5 && v.a < 1.5) continue;
            float In = rtMax3(v.rgb);
            float wgt = (In > Ic + 0.004) ? (In - Ic) : 0.0;
            if (v.a > 1.5) wgt += 1.0;
            if (wgt <= 0.0) continue;
            acc += wgt;
            float u = fract(rnd[(i + k) & 3] + 0.6180339887 * float(i * 6 + k));
            if (u * acc <= wgt) { pick = k; pickVal = v; }
        }
        if (pick < 0) return false;
        c += dirs[pick];
        cur = pickVal;
    }
    return false;
}
#endif

#endif
