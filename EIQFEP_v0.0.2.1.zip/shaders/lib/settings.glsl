#ifndef EIQ_SETTINGS
#define EIQ_SETTINGS
// =============================================================================
//  EIQFEP - Every Image Quality For Every PC
//  Ayarlar. Tum seviye turevleri bu dosyada tanimlanir.
// =============================================================================

// ---- Ana secici -------------------------------------------------------------
#define EIQ_LEVEL 3 //[1 2 3 4 5]

// ---- Isik ve golge ----------------------------------------------------------
#define SHADOW_DISTANCE 128 //[64 96 128 160 192 256]
#define EMISSIVE_BLOCKS
#define EMISSIVE_STRENGTH 1.0 //[0.5 1.0 1.5 2.0]
#define NIGHT_BRIGHTNESS 1.0 //[0.5 1.0 1.5 2.0]
#define SHADOW_SOFTNESS 1.0 //[0.5 0.75 1.0 1.5 2.0]
#define AO_STRENGTH 1.0 //[0.0 0.5 0.75 1.0 1.25 1.5]

// ---- Renkli isik (LPV) ------------------------------------------------------
#define LPV_ENABLED
#define LPV_STRENGTH 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
#define HAND_LIGHT
#define LIGHT_FLICKER

// ---- Atmosfer ---------------------------------------------------------------
#define CLOUD_COVER 0.5 //[0.3 0.4 0.5 0.6 0.7]
#define WIND_STRENGTH 1.0 //[0.0 0.5 1.0 1.5 2.0]
#define THUNDER_FLASH
#define AURORA
#define AURORA_STRENGTH 1.0 //[0.5 0.75 1.0 1.5 2.0]
#define AURORA_FREQUENCY 0.35 //[0.0 0.15 0.35 0.6 1.0]
#define SHOOTING_STARS
#define CIRRUS
#define SNOW_SPARKLE
#define CLOUD_SHADOWS
#define SKY_TEMPORAL
#define ADAPTIVE_QUALITY
#define BIOME_FOG
#define MORNING_MIST
#define LPV_DIRECTIONAL

// ---- Isin izleme (yalnizca seviye 5; voksel tabanli, OpenGL 4.3+) -----------------
#define RAYTRACING
#define RT_REFLECTIONS
#define RT_GI
#define RT_GI_STRENGTH 1.0 //[0.5 0.75 1.0 1.25 1.5]
#define RT_LIGHTS
#define RT_LIGHT_SHADOW 0.80 //[0.4 0.6 0.8 1.0]

// ---- Isik huzmeleri (god ray) -------------------------------------------------------
#define GODRAYS
#define GODRAYS_STRENGTH 1.0 //[0.5 0.75 1.0 1.5 2.0]
#define VOLUMETRIC_STRENGTH 1.0 //[0.5 1.0 1.5 2.0 3.0]

// ---- End ---------------------------------------------------------------------------
#define END_EYE
#define END_EYE_SIZE 1.0 //[0.7 1.0 1.3 1.6]
#define END_NEBULA
#define END_AURORA
#define END_MOTES
#define END_FOG_DENSITY 1.0 //[0.5 0.75 1.0 1.5 2.0]
#define END_LIGHT_STRENGTH 1.0 //[0.5 0.75 1.0 1.25 1.5]
#define END_STONE_GLINT

// ---- Nether (0.0.0.6: surumun ana konusu) ---------------------------------------------
#define NETHER_EMBERS
#define NETHER_AMBIENT 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
#define NETHER_FOG_DENSITY 1.0 //[0.5 0.75 1.0 1.5 2.0]
#define NETHER_FOG_GLOW 1.0 //[0.0 0.5 1.0 1.5 2.0]
#define NETHER_LAVA_GLOW
#define NETHER_HEAT_HAZE
#define NETHER_GRADE
#define NETHER_EYE
#define NETHER_EYE_SIZE 1.0 //[0.7 1.0 1.3 1.6]
#define NETHER_EYE_LIGHT

// ---- Malzeme ----------------------------------------------------------------
#define AUTO_NORMAL_STRENGTH 1.0 //[0.0 0.5 1.0 1.5 2.0]
#define WET_SURFACES

// ---- Goruntu ----------------------------------------------------------------
#define AUTO_EXPOSURE
#define EXPOSURE_BIAS 0.0 //[-2.0 -1.5 -1.0 -0.5 0.0 0.5 1.0 1.5 2.0]
#define BLOOM_STRENGTH 1.0 //[0.0 0.25 0.5 0.75 1.0 1.5 2.0]
#define SUN_SIZE 1.0 //[0.25 0.5 0.75 1.0 1.5 2.0]
#define SATURATION 1.0 //[0.6 0.8 1.0 1.1 1.2 1.3]
#define VIBRANCE 0.15 //[0.0 0.1 0.15 0.25 0.4 0.6]
#define CONTRAST 1.0 //[0.8 0.9 1.0 1.1 1.2]
#define VIGNETTE 0.15 //[0.0 0.15 0.3 0.45]
#define TONEMAP_MODE 0 //[0 1 2 3 4 5]
#define COLOR_TEMP 0.0 //[-1.0 -0.5 -0.25 0.0 0.25 0.5 1.0]

// ---- Stil ve ince ayar (0.0.2) ---------------------------------------------------
//  STYLE: 0 EIQ (dogal) | 1 BSL tarzi (canli, sicak gunes + mavi golge) | 2 Karanlik mod (kasvetli)
//  Asagidaki kaydiricilar secilen stilin USTUNE biner (carpan/toplama): kendi zevkine gore ayarla.
#define STYLE 0 //[0 1 2]
#define AMBIENT_LIGHT 1.0 //[0.5 0.7 0.85 1.0 1.15 1.3 1.5 2.0]
#define SUNLIGHT 1.0 //[0.5 0.7 0.85 1.0 1.15 1.3 1.5 2.0]
#define SHADOW_COOLNESS 0.0 //[-1.0 -0.5 0.0 0.5 1.0]
#define SKY_SATURATION 1.0 //[0.6 0.8 1.0 1.2 1.4 1.6]
#define SKY_BRIGHTNESS 1.0 //[0.6 0.8 1.0 1.2 1.4]
#define CLOUD_BRIGHTNESS 1.0 //[0.6 0.8 1.0 1.2 1.4]
#define FOG_DENSITY 1.0 //[0.0 0.5 0.75 1.0 1.5 2.0 3.0]
#define CAVE_DARKNESS 1.0 //[0.0 0.25 0.5 1.0 2.0]
#define WATER_TURBIDITY 1.0 //[0.5 0.75 1.0 1.5 2.0]

// ---- Kamera ----------------------------------------------------------------
//#define MOTION_BLUR
#define MOTION_BLUR_STRENGTH 1.0 //[0.5 1.0 1.5 2.0]
#define FILM_GRAIN 0.0 //[0.0 0.25 0.5 1.0 1.5]
#define CHROMA_ABERR 0.0 //[0.0 0.5 1.0 1.5 2.0]
//#define RAIN_DROPS
//#define LENS_FLARE
//#define DOF
#define DOF_STRENGTH 1.0 //[0.5 1.0 1.5 2.0]

#define TAA_JITTER 1.0
#define TAA_ALPHA_MIN 0.07
#define TAA_ALPHA_MAX 0.40
#define TAA_CLIP 1
#define TAA_CATMULL 1
#define TAA_VAR_GAMMA 1.4
#define SHARPEN_AMOUNT 0.60

// =============================================================================
//  Stil on ayarlari: (ST_*) degerleri kullanici kaydiricilariyla birlestirilir (E_*)
// =============================================================================
#if STYLE == 1          // BSL tarzi: canli renkler, sicak gunes, mavi golge, parlak bulut, hafif sis
  #define ST_EV 0.25
  #define ST_SAT 1.28
  #define ST_VIB 0.20
  #define ST_CON 1.10
  #define ST_VIG 0.00
  #define ST_TEMP 0.08
  #define ST_NIGHT 0.80
  #define ST_AMB 1.15
  #define ST_SUN 1.20
  #define ST_COOL 0.60
  #define ST_SKYSAT 1.40
  #define ST_SKYB 1.05
  #define ST_CLOUDB 1.12
  #define ST_FOG 0.85
  #define ST_CAVE 1.00
  #define ST_BLOOM 1.30
  #define ST_EXPMAX 2.2
#elif STYLE == 2        // Karanlik mod: dusuk ortam isigi, koyu gece/magara, yuksek kontrast, soguk ton
  #define ST_EV -0.75
  #define ST_SAT 0.88
  #define ST_VIB -0.10
  #define ST_CON 1.14
  #define ST_VIG 0.15
  #define ST_TEMP -0.10
  #define ST_NIGHT 0.45
  #define ST_AMB 0.70
  #define ST_SUN 0.90
  #define ST_COOL 0.35
  #define ST_SKYSAT 0.85
  #define ST_SKYB 0.85
  #define ST_CLOUDB 0.85
  #define ST_FOG 1.25
  #define ST_CAVE 0.25
  #define ST_BLOOM 0.80
  #define ST_EXPMAX 1.4
#else                   // EIQ: dogal (degisiklik yok)
  #define ST_EV 0.0
  #define ST_SAT 1.0
  #define ST_VIB 0.0
  #define ST_CON 1.0
  #define ST_VIG 0.0
  #define ST_TEMP 0.0
  #define ST_NIGHT 0.70
  #define ST_AMB 1.0
  #define ST_SUN 1.0
  #define ST_COOL 0.0
  #define ST_SKYSAT 1.0
  #define ST_SKYB 1.0
  #define ST_CLOUDB 1.0
  #define ST_FOG 1.0
  #define ST_CAVE 1.0
  #define ST_BLOOM 1.0
  #define ST_EXPMAX 2.0
#endif
#define E_EXPOSURE_EV (EXPOSURE_BIAS + ST_EV)
#define E_SATURATION  (SATURATION * ST_SAT)
#define E_VIBRANCE    max(VIBRANCE + ST_VIB, 0.0)
#define E_CONTRAST    (CONTRAST * ST_CON)
#define E_VIGNETTE    max(VIGNETTE + ST_VIG, 0.0)
#define E_COLOR_TEMP  (COLOR_TEMP + ST_TEMP)
#define E_NIGHT       (NIGHT_BRIGHTNESS * ST_NIGHT)
#define E_AMBIENT     (AMBIENT_LIGHT * ST_AMB)
#define E_SUN         (SUNLIGHT * ST_SUN)
#define E_COOL        (SHADOW_COOLNESS + ST_COOL)
#define E_SKYSAT      (SKY_SATURATION * ST_SKYSAT)
#define E_SKYB        (SKY_BRIGHTNESS * ST_SKYB)
#define E_CLOUDB      (CLOUD_BRIGHTNESS * ST_CLOUDB)
#define E_FOG         (FOG_DENSITY * ST_FOG)
#define E_CAVE        (CAVE_DARKNESS * ST_CAVE)
#define E_BLOOM       (BLOOM_STRENGTH * ST_BLOOM)

// =============================================================================
//  Seviye turevleri (deger iceren define'lar Iris tarafindan secenek sayilmaz)
// =============================================================================
#if EIQ_LEVEL == 1
  #define SHADOW_RES 1024
  #define SHADOW_TAPS 4
  #define SHADOW_PCSS 0
  #define SHADOW_COLORED 0
  #define CONTACT_STEPS 0
  #define AO_MODE 0
  #define GTAO_SLICES 0
  #define GTAO_STEPS 0
  #define NORMAL_GEN 0
  #define SKY_STEPS 6
  #define SKY_LSTEPS 3
  #define CLOUD_STEPS 4
  #define CLOUD_LSTEPS 0
  #define STARS_DETAIL 0
  #define VL_STEPS 0
  #define SSR_STEPS 0
  #define USE_TAA 0
  #define USE_FXAA 1
  #define BLOOM_LODS 3
  #define SHARPEN 0
  #define AURORA_STEPS 0
#elif EIQ_LEVEL == 2
  #define SHADOW_RES 1536
  #define SHADOW_TAPS 8
  #define SHADOW_PCSS 0
  #define SHADOW_COLORED 1
  #define CONTACT_STEPS 0
  #define AO_MODE 1
  #define GTAO_SLICES 0
  #define GTAO_STEPS 0
  #define NORMAL_GEN 1
  #define SKY_STEPS 8
  #define SKY_LSTEPS 3
  #define CLOUD_STEPS 6
  #define CLOUD_LSTEPS 1
  #define STARS_DETAIL 1
  #define VL_STEPS 0
  #define SSR_STEPS 0
  #define USE_TAA 0
  #define USE_FXAA 1
  #define BLOOM_LODS 4
  #define SHARPEN 0
  #define AURORA_STEPS 0
#elif EIQ_LEVEL == 3
  #define SHADOW_RES 2048
  #define SHADOW_TAPS 12
  #define SHADOW_PCSS 1
  #define SHADOW_COLORED 1
  #define CONTACT_STEPS 8
  #define AO_MODE 2
  #define GTAO_SLICES 2
  #define GTAO_STEPS 6
  #define NORMAL_GEN 2
  #define SKY_STEPS 10
  #define SKY_LSTEPS 4
  #define CLOUD_STEPS 9
  #define CLOUD_LSTEPS 2
  #define STARS_DETAIL 2
  #define VL_STEPS 8
  #define SSR_STEPS 14
  #define USE_TAA 1
  #define USE_FXAA 0
  #define BLOOM_LODS 5
  #define SHARPEN 1
  #define AURORA_STEPS 10
#elif EIQ_LEVEL == 4
  #define SHADOW_RES 3072
  #define SHADOW_TAPS 16
  #define SHADOW_PCSS 1
  #define SHADOW_COLORED 1
  #define CONTACT_STEPS 12
  #define AO_MODE 2
  #define GTAO_SLICES 3
  #define GTAO_STEPS 8
  #define NORMAL_GEN 2
  #define SKY_STEPS 12
  #define SKY_LSTEPS 5
  #define CLOUD_STEPS 13
  #define CLOUD_LSTEPS 3
  #define STARS_DETAIL 2
  #define VL_STEPS 16
  #define SSR_STEPS 26
  #define USE_TAA 1
  #define USE_FXAA 0
  #define BLOOM_LODS 6
  #define SHARPEN 1
  #define AURORA_STEPS 14
#else
  #define SHADOW_RES 4096
  #define SHADOW_TAPS 24
  #define SHADOW_PCSS 1
  #define SHADOW_COLORED 1
  #define CONTACT_STEPS 16
  #define AO_MODE 2
  #define GTAO_SLICES 4
  #define GTAO_STEPS 10
  #define NORMAL_GEN 2
  #define SKY_STEPS 16
  #define SKY_LSTEPS 6
  #define CLOUD_STEPS 18
  #define CLOUD_LSTEPS 4
  #define STARS_DETAIL 2
  #define VL_STEPS 24
  #define SSR_STEPS 40
  #define USE_TAA 1
  #define USE_FXAA 0
  #define BLOOM_LODS 7
  #define SHARPEN 1
  #define AURORA_STEPS 20
#endif


// =============================================================================
//  Seviye turevleri 2: god ray, End, parcaciklar
// =============================================================================
#if EIQ_LEVEL == 1
  #define GODRAY_STEPS 0
  #define END_FOG_STEPS 0
  #define MOTE_STEPS 0
  #define NEB_OCT 0
  #define EYE_DETAIL 0
  #define NETHER_FOG_STEPS 0
#elif EIQ_LEVEL == 2
  #define GODRAY_STEPS 8
  #define END_FOG_STEPS 0
  #define MOTE_STEPS 4
  #define NEB_OCT 2
  #define EYE_DETAIL 1
  #define NETHER_FOG_STEPS 0
#elif EIQ_LEVEL == 3
  #define GODRAY_STEPS 14
  #define END_FOG_STEPS 8
  #define MOTE_STEPS 6
  #define NEB_OCT 3
  #define EYE_DETAIL 2
  #define NETHER_FOG_STEPS 8
#elif EIQ_LEVEL == 4
  #define GODRAY_STEPS 20
  #define END_FOG_STEPS 12
  #define MOTE_STEPS 8
  #define NEB_OCT 4
  #define EYE_DETAIL 2
  #define NETHER_FOG_STEPS 12
#else
  #define GODRAY_STEPS 28
  #define END_FOG_STEPS 16
  #define MOTE_STEPS 10
  #define NEB_OCT 5
  #define EYE_DETAIL 2
  #define NETHER_FOG_STEPS 16
#endif
#ifndef GODRAYS
  #undef GODRAY_STEPS
  #define GODRAY_STEPS 0
#endif


// =============================================================================
//  GPU yetenegi ve voksel (LPV) turevleri
//  GPU_COMPUTE: OpenGL 4.3+ (compute + image). macOS (4.1) ve eski GPU'larda 0 -> vanilla blok isigi.
// =============================================================================
#ifdef IS_IRIS
  #if MC_GL_VERSION >= 430
    #define GPU_COMPUTE 1
  #else
    #define GPU_COMPUTE 0
  #endif
#else
  #define GPU_COMPUTE 0
#endif

// Izgara boyutu seviyeye baglidir (shaders.properties ayni kosullari kullanir)
#if EIQ_LEVEL == 3
  #define LPV_X 64
  #define LPV_Y 48
  #define LPV_Z 64
#elif EIQ_LEVEL == 4
  #define LPV_X 96
  #define LPV_Y 48
  #define LPV_Z 96
#else
  #define LPV_X 128
  #define LPV_Y 64
  #define LPV_Z 128
#endif

// Zamansal gokyuzu onbellegi: seviye 3+ (atmosfer + bulut, 2x2 desenle 4 karede bir yenilenir)
#if (EIQ_LEVEL >= 3) && defined(SKY_TEMPORAL)
  #define SKY_CACHE_ON 1
#else
  #define SKY_CACHE_ON 0
#endif

// Bulut golgeleri seviye 3+ (ekstra 2 bulut ornegi / piksel)
#if (EIQ_LEVEL >= 3) && defined(CLOUD_SHADOWS)
  #define CLOUD_SHADOW_ON 1
#else
  #define CLOUD_SHADOW_ON 0
#endif

#if GPU_COMPUTE && (EIQ_LEVEL >= 3) && defined(LPV_ENABLED)
  #define LPV_ACTIVE 1
#else
  #define LPV_ACTIVE 0
#endif

// Isin izleme: seviye 4-5 + LPV (voksel izgarasi) etkin + ana anahtar acik
#if LPV_ACTIVE && (EIQ_LEVEL >= 4) && defined(RAYTRACING)
  #define RT_ON 1
  #define RT_BRICK_X (LPV_X / 4)
  #define RT_BRICK_Y (LPV_Y / 4)
  #define RT_BRICK_Z (LPV_Z / 4)
  #ifdef RT_REFLECTIONS
    #define RT_REFL_ON 1
  #else
    #define RT_REFL_ON 0
  #endif
  #ifdef RT_GI
    #define RT_GI_ON 1
  #else
    #define RT_GI_ON 0
  #endif
  #ifdef RT_LIGHTS
    #define RT_LIGHTS_ON 1
  #else
    #define RT_LIGHTS_ON 0
  #endif
#else
  #define RT_ON 0
  #define RT_REFL_ON 0
  #define RT_GI_ON 0
  #define RT_LIGHTS_ON 0
#endif

#endif
