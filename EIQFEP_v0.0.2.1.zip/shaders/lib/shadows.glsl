#ifndef EIQ_SHADOWS
#define EIQ_SHADOWS
#include "/lib/common.glsl"

// =============================================================================
//  Golge: carpitilmis (distort) tek harita, PCF / PCSS, renkli saydam golge,
//  ekran uzayi temas golgesi.
// =============================================================================
uniform sampler2D shadowtex0;   // tum yuzeyler
uniform sampler2D shadowtex1;   // sadece opak
uniform sampler2D shadowcolor0; // saydam renk
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;

const float SHADOW_DISTORT = 0.85;
const float SHADOW_Z_SCALE = 0.2;

float shadowDistortFactor(vec2 p) { return (1.0 - SHADOW_DISTORT) + length(p) * SHADOW_DISTORT; }
vec2  shadowDistort(vec2 p)       { return p / shadowDistortFactor(p); }

// Oyuncu-gorece konum -> golge haritasi uv + derinlik (0..1)
vec3 toShadowCoord(vec3 posRel) {
    vec4 sv = shadowModelView * vec4(posRel, 1.0);
    vec3 sc = (shadowProjection * sv).xyz;
    sc.xy = shadowDistort(sc.xy);
    sc.z *= SHADOW_Z_SCALE;
    return sc * 0.5 + 0.5;
}

// Dondurulen: rgb gorunurluk (renkli saydam golge dahil)
vec3 getShadow(vec3 posRel, vec3 Nw, vec3 Lw, float noise) {
    float NoL = dot(Nw, Lw);
    float texelW = 2.0 * shadowDistance / float(SHADOW_RES);

    vec3 sc0 = toShadowCoord(posRel);
    float f = shadowDistortFactor(sc0.xy * 2.0 - 1.0);
    float slope = min(sqrt(max(1.0 - NoL * NoL, 0.0)) / max(abs(NoL), 0.1), 3.0);
    float bias = texelW * f * (1.2 + slope);
    vec3 sc = toShadowCoord(posRel + Nw * bias);

    if (any(lessThan(sc.xy, vec2(0.0))) || any(greaterThan(sc.xy, vec2(1.0))) || sc.z > 1.0)
        return vec3(1.0);

    float zb = 0.00012 + 0.00018 * slope;
    float texelUV = 1.0 / float(SHADOW_RES);
    float radius = texelUV * 1.6;

#ifdef ADAPTIVE_QUALITY
    float shDist = length(posRel);
    int taps = shDist < 40.0 ? SHADOW_TAPS : max(SHADOW_TAPS / 2, 4);
#else
    const int taps = SHADOW_TAPS;
#endif
#if SHADOW_PCSS
#ifdef ADAPTIVE_QUALITY
    if (shDist < 64.0)
#endif
    {
        float searchR = 0.0055;
        float sum = 0.0;
        float cnt = 0.0;
        for (int i = 0; i < 6; i++) {
            vec2 o = vogel(i, 6, noise) * searchR;
            float d = texture(shadowtex1, sc.xy + o).r;
            if (d < sc.z - zb) { sum += d; cnt += 1.0; }
        }
        if (cnt > 0.5) {
            float avg = sum / cnt;
            float dz = (sc.z - avg) * (10.0 / abs(shadowProjection[2][2]));
            float widthW = dz * 0.035 * SHADOW_SOFTNESS;
            float r = widthW * shadowProjection[0][0] * 0.5 / f;
            radius = clamp(r, texelUV * 1.6, 0.011 * SHADOW_SOFTNESS);
        }
    }
#endif

    float visO = 0.0;
    float visA = 0.0;
    for (int i = 0; i < SHADOW_TAPS; i++) {
        if (i >= taps) break;
        vec2 uv = sc.xy + vogel(i, taps, noise) * radius;
        visO += step(sc.z - zb, texture(shadowtex1, uv).r);
#if SHADOW_COLORED
        visA += step(sc.z - zb, texture(shadowtex0, uv).r);
#endif
    }
    visO /= float(taps);
#if SHADOW_COLORED
    visA /= float(taps);
    vec4 tint = texture(shadowcolor0, sc.xy);
    vec3 tintCol = mix(vec3(1.0), tint.rgb, tint.a);
    vec3 vis = vec3(visA) + (visO - visA) * tintCol;
#else
    vec3 vis = vec3(visO);
#endif

    // Golge mesafesi sonunda yumusak cikis
    float edge = smoothstep(0.88, 1.0, length(posRel.xz) / shadowDistance);
    return mix(vis, vec3(1.0), edge);
}

// Ekran uzayi temas golgesi. Lv: gorunum uzayinda isik yonu.
float contactShadow(vec3 vp, vec3 Lv, float jit) {
#if CONTACT_STEPS > 0
#ifdef ADAPTIVE_QUALITY
    if (length(vp) > 110.0) return 1.0;     // cok uzakta (sis icinde) atla
#endif
    float len = 0.55 + 0.012 * length(vp);
    float stepL = len / float(CONTACT_STEPS);
    for (int i = 0; i < CONTACT_STEPS; i++) {
        vec3 p = vp + Lv * (stepL * (float(i) + jit + 0.35));
        vec3 s = projectView(p);
        if (s.x < 0.0 || s.x > 1.0 || s.y < 0.0 || s.y > 1.0) break;
        float sd = texture(depthtex1, s.xy).r;
        float sz = viewPosFromDepth(s.xy, sd).z;
        float diff = sz - p.z;
        if (diff > 0.02 && diff < 0.30) return 0.0;
    }
#endif
    return 1.0;
}

#endif
