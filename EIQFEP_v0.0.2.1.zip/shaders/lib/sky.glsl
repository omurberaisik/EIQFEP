#ifndef EIQ_SKY
#define EIQ_SKY
#include "/lib/clouds.glsl"

// =============================================================================
//  Gok: atmosfer + gunes/ay diski + yildizlar + samanyolu + bulutlar.
// =============================================================================
const float SUN_RADIUS  = 0.1120 * SUN_SIZE;   // radyan (0.0140'in 8 kati; ~6.4 derece yaricap)
const float MOON_RADIUS = 0.0115;

vec3 rotateAxis(vec3 v, vec3 k, float a) {
    float c = cos(a), s = sin(a);
    return v * c + cross(k, v) * s + k * dot(k, v) * (1.0 - c);
}

// Yildiz alani: gok kuresi yildizlari gunes ile birlikte doner
vec3 starField(vec3 rd, float vis) {
    if (vis <= 0.001) return vec3(0.0);
    float tilt = radians(-25.0);
    vec3 axis = vec3(sin(tilt), 0.0, cos(tilt));
    vec3 s0 = rotateAxis(rd, axis, -sunAngle * TAU);
    vec3 col = vec3(0.0);
#if STARS_DETAIL >= 0
    for (int L = 0; L < (STARS_DETAIL >= 2 ? 2 : 1); L++) {
        float S = (L == 0) ? 70.0 : 150.0;
        vec3 g = s0 * S;
        vec3 id = floor(g);
        float h0 = hash13(id + float(L) * 31.7);
        if (h0 > 0.032) continue;
        vec3 jit = vec3(hash13(id + 7.1), hash13(id + 13.3), hash13(id + 29.9)) * 0.6 + 0.2;
        float dist = length(g - (id + jit));
        float mag = pow(hash13(id + 3.3), 5.0);
        float r = 0.10 + 0.10 * mag;
        float core = smoothstep(r, 0.0, dist);
        core *= core;
        vec3 tint = mix(vec3(1.0, 0.72, 0.52), vec3(0.62, 0.76, 1.0), hash13(id + 91.1));
        float tw = 1.0 + 0.25 * sin(frameTimeCounter * 2.5 + h0 * 900.0);
        col += tint * core * (0.25 + 3.2 * mag) * tw * (L == 0 ? 1.0 : 0.6);
    }
#endif
#if STARS_DETAIL >= 2
    vec3 gn = normalize(vec3(0.30, 0.90, -0.40));
    float bd = dot(s0, gn);
    float band = exp(-bd * bd / (2.0 * 0.15 * 0.15));
    float cloud = fbm3(s0 * 5.0, 4);
    float dust  = fbm3(s0 * 9.0 + 4.0, 3);
    float mw = band * (0.35 + 0.9 * cloud) * (1.0 - 0.55 * smoothstep(0.45, 0.7, dust));
    col += mix(vec3(0.55, 0.62, 0.95), vec3(1.0, 0.82, 0.62), saturate(band * cloud * 1.4)) * mw * 0.40;
#endif
    return col * vis * (SUN_S * 0.04);
}


#if defined(AURORA) && AURORA_STEPS > 0
// Kutup isiklari: renkli perdeler, birkac yukseklik duzleminde ornekleme.
// Her oyun gunu icin AURORA_FREQUENCY olasiligi ile gorunur.
vec3 auroraLayer(vec3 rd, float vis, float jit) {
    if (vis <= 0.001 || rd.y < 0.015) return vec3(0.0);
    if (hash12(vec2(float(worldDay), 41.0)) > AURORA_FREQUENCY) return vec3(0.0);
    float t = frameTimeCounter;
    vec3 acc = vec3(0.0);
    for (int i = 0; i < AURORA_STEPS; i++) {
        float f = (float(i) + jit) / float(AURORA_STEPS);
        float alt = 3000.0 + f * 4500.0;
        vec2 s = rd.xz / (rd.y + 0.10) * alt * 0.00035;
        float w = fbm2(s * 0.8 + vec2(t * 0.012, -t * 0.008), 3);
        float band = fbm2(vec2(s.x * 0.5 + w * 2.2, s.y * 0.5 - w * 1.4) + 3.0, 2) / 0.75;
        float ridge = pow(saturate(1.0 - abs(band - 0.5) * 4.0), 2.0);
        float flick = 0.65 + 0.35 * sin(t * 1.3 + w * 12.0 + f * 6.0);
        vec3 c = mix(vec3(0.15, 1.0, 0.45), vec3(0.55, 0.25, 0.95), smoothstep(0.35, 1.0, f));
        acc += c * ridge * flick * (1.0 - 0.6 * f);
    }
    acc /= float(AURORA_STEPS);
    float hor = smoothstep(0.015, 0.20, rd.y);
    return acc * hor * vis * SUN_S * 0.22 * AURORA_STRENGTH;
}
#endif

#ifdef SHOOTING_STARS
// Kayan yildiz: her 9 saniyelik dilimde olasilikla bir iz, ~0.9 sn gorunur
vec3 shootingStar(vec3 rd, float vis) {
    if (vis <= 0.001 || rd.y < 0.02) return vec3(0.0);
    const float T = 9.0;
    float slot = floor(frameTimeCounter / T);
    float ph = fract(frameTimeCounter / T);
    if (hash12(vec2(slot, 17.0)) > 0.55 || ph > 0.10) return vec3(0.0);
    float u = ph / 0.10;
    float a = hash12(vec2(slot, 5.0)) * TAU;
    float e = 0.35 + 0.55 * hash12(vec2(slot, 9.0));
    vec3 s = vec3(cos(a) * sqrt(1.0 - e * e), e, sin(a) * sqrt(1.0 - e * e));
    float b = hash12(vec2(slot, 23.0)) * TAU;
    vec3 tang = normalize(cross(s, vec3(cos(b), 0.35, sin(b))) + vec3(1e-5));
    vec3 head = normalize(s + tang * (u * 0.35));
    vec3 tail = normalize(s + tang * (u * 0.35 - 0.10));
    vec3 ab = head - tail;
    float k = saturate(dot(rd - tail, ab) / max(dot(ab, ab), 1e-6));
    float d = length(rd - (tail + ab * k));
    float core = smoothstep(0.0016, 0.0, d);
    return vec3(0.9, 0.95, 1.0) * core * k * k * sin(u * PI) * vis * SUN_S * 0.4;
}
#endif

float moonShade(vec3 rd, vec3 moonDir, out float disc) {
    vec3 up = abs(moonDir.y) < 0.99 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 ax = normalize(cross(up, moonDir));
    vec3 ay = cross(moonDir, ax);
    vec2 uv = vec2(dot(rd, ax), dot(rd, ay)) / MOON_RADIUS;
    float r2 = dot(uv, uv);
    disc = 0.0;
    if (r2 >= 1.0 || dot(rd, moonDir) < 0.0) return 0.0;
    disc = 1.0;
    vec3 n = vec3(uv, sqrt(1.0 - r2));
    float ph = float(moonPhase) * PI * 0.25;        // 0 = dolunay, 4 = yeni ay
    vec3 Lm = vec3(sin(ph), 0.0, cos(ph));
    float lit = saturate(dot(n, Lm) * 3.0 + 0.0);
    float maria = 0.55 + 0.45 * smoothstep(0.35, 0.65, fbm2(uv * 2.6 + 3.0, 4));
    float earthshine = 0.025;
    return (lit * maria + earthshine) ;
}

#include "/lib/endsky.glsl"
#if EIQ_DIM == -1
#include "/lib/nethersky.glsl"
#endif

// Atmosfer tabani (puruzsuz: zamansal onbellege uygun) + ufuk alti sonumu
vec3 skyStyle(vec3 c) {
    return max(mix(vec3(luma(c)), c, E_SKYSAT), vec3(0.0)) * E_SKYB;
}
vec3 skyAtmoBase(vec3 rd, vec3 ambGround) {
    vec3 col = skyStyle(skyRadianceFull(rd, SKY_STEPS, SKY_LSTEPS));
    float below = smoothstep(0.0, -0.22, rd.y);
    return mix(col, col * 0.30 + ambGround * 0.30, below);
}

// atmoPre/cloudPre: onbellekten gelen atmosfer ve bulut (havePre = true ise hesaplanmaz)
vec3 renderSkyEx(vec3 rd, vec3 sunCol, vec3 moonCol, vec3 lightDir, vec3 lightColor,
                 vec3 ambUp, vec3 ambGround, float cloudJitter,
                 vec3 atmoPre, vec4 cloudPre, bool havePre) {
#if EIQ_DIM == 0
    vec3 sunDir = getSunDir();
    vec3 moonDir = getMoonDir();
    vec3 col = havePre ? atmoPre : skyAtmoBase(rd, ambGround);

    float night = smoothstep(0.06, -0.16, sunDir.y) * (1.0 - 0.85 * rainStrength);
    float up = smoothstep(-0.02, 0.06, rd.y);

    // yıldızlar
    col += starField(rd, night * up);
#if defined(AURORA) && AURORA_STEPS > 0
    col += auroraLayer(rd, night * up * (1.0 - rainStrength), cloudJitter);
#endif
#ifdef SHOOTING_STARS
    col += shootingStar(rd, night * up);
#endif

    // güneş diski
    float cs = dot(rd, sunDir);
    float sAng = acos(clamp(cs, -1.0, 1.0));
    float sunVis = up * smoothstep(-0.10, 0.02, sunDir.y) * (1.0 - 0.9 * rainStrength);
    if (sAng < SUN_RADIUS * 3.0 && sunVis > 0.0) {
        float k = saturate(sAng / SUN_RADIUS);
        float limb = mix(0.60, 1.0, sqrt(max(1.0 - k * k, 0.0)));
        float edge = 1.0 - smoothstep(0.90, 1.0, k);                 // yumusak kenar
        vec3 sunRad = sunCol * 16.0;                                  // buyuk disk: alan basina parlaklik dusuk tutulur
        col += sunVis * (sunRad * limb * edge + sunCol * 0.9 * exp(-max(sAng - SUN_RADIUS, 0.0) * 40.0));
    }
    // Mie hale (aureole): diskin kenarindan baslayan genis, sicak, alcak gunesde guclenen parilti
    if (sunVis > 0.0) {
        float d = max(acos(clamp(cs, -1.0, 1.0)) - SUN_RADIUS, 0.0);
        float low = 1.0 - smoothstep(0.05, 0.55, sunDir.y);
        float halo = 0.55 * exp(-d * 9.0) + 0.25 * exp(-d * 3.0);
        col += sunVis * sunCol * halo * (0.45 + 0.9 * low) * (1.0 - 0.8 * rainStrength);
    }

    // ay diski
    float md;
    float mshade = moonShade(rd, moonDir, md);
    if (md > 0.0) {
        float moonVis = up * (0.18 + 0.82 * smoothstep(0.15, -0.10, sunDir.y)) * (1.0 - 0.9 * rainStrength);
        col = mix(col, vec3(0.86, 0.9, 1.0) * SUN_S * 0.25 * mshade * moonVis + col * 0.15, md * moonVis);
    }

    // yildirim flasi (gokyuzu aydinlanir; bulutlar ambUp uzerinden zaten flasi alir)
    col += vec3(0.80, 0.86, 1.00) * SUN_S * 0.80 * lightningFlash() * (0.45 + 0.55 * (1.0 - saturate(rd.y)));

    // yuksek ince bulutlar
#ifdef CIRRUS
    {
        vec4 ci = cirrusLayer(rd, lightDir, lightColor, ambUp);
        col = mix(col, ci.rgb, ci.a);
    }
#endif

    // bulutlar
    vec4 cl = havePre ? cloudPre : cloudMarch(rd, lightDir, lightColor, ambUp, cloudJitter);
    col = col * cl.a + cl.rgb;
    return col;
#elif EIQ_DIM == -1
    return netherSkyFull(rd, cloudJitter);
#else
    return endSkyFull(rd, cloudJitter);
#endif
}

vec3 renderSky(vec3 rd, vec3 sunCol, vec3 moonCol, vec3 lightDir, vec3 lightColor,
               vec3 ambUp, vec3 ambGround, float cloudJitter) {
    return renderSkyEx(rd, sunCol, moonCol, lightDir, lightColor, ambUp, ambGround, cloudJitter,
                       vec3(0.0), vec4(0.0, 0.0, 0.0, 1.0), false);
}

// Yansimalar icin hafif gokyuzu: atmosfer + gunes/ay parlamasi (bulut ve yildiz yok)
vec3 renderSkyReflection(vec3 rd, vec3 sunCol, vec3 moonCol) {
#if EIQ_DIM == 0
    vec3 col = skyStyle(skyRadianceFull(rd, 6, 3));
    vec3 sunDir = getSunDir();
    vec3 moonDir = getMoonDir();
    float sAng = acos(clamp(dot(rd, sunDir), -1.0, 1.0));
    float sunVis = smoothstep(-0.10, 0.02, sunDir.y) * (1.0 - 0.9 * rainStrength);
    col += sunVis * (sunCol * 16.0 * (1.0 - smoothstep(0.9 * SUN_RADIUS, SUN_RADIUS, sAng)) + sunCol * 0.9 * exp(-max(sAng - SUN_RADIUS, 0.0) * 40.0));
    float mAng = acos(clamp(dot(rd, moonDir), -1.0, 1.0));
    col += moonCol * 40.0 * (mAng < MOON_RADIUS ? 1.0 : 0.0) * (1.0 - 0.9 * rainStrength);
    return col;
#elif EIQ_DIM == -1
    return netherSkyReflection(rd);
#else
    return endSkyReflection(rd);
#endif
}

#endif
