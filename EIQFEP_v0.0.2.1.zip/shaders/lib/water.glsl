#ifndef EIQ_WATER
#define EIQ_WATER
#include "/lib/common.glsl"

// Su: kanal basina sogurma (Beer-Lambert) ve kaustik deseni
const vec3 WATER_ABSORB = vec3(0.90, 0.28, 0.14) * WATER_TURBIDITY;   // 1/m  (kirmizi hizli soner)

float causticRidge(vec2 q) {
    float n = vnoise2(q);
    return pow(saturate(1.0 - abs(n * 2.0 - 1.0)), 5.0);
}

// Hareketli, kirinmis isik agi. Cikis ~0..2, ortalama ~0.5
float causticPattern(vec2 p, float t) {
    vec2 w = vec2(vnoise2(p * 0.9 + t * 0.35), vnoise2(p * 0.9 - t * 0.30 + 7.1));
    vec2 q = p * 1.6 + (w - 0.5) * 1.4;
    float a = causticRidge(q + vec2(t * 0.20, t * 0.12));
    float b = causticRidge(q * 1.37 - vec2(t * 0.17, -t * 0.22) + 3.7);
    return a * b * 3.0 + (a + b) * 0.35;
}

// Gunes gorunurlugu ve aciya bagli kaustik carpani (1 civarinda)
float causticFactor(vec3 worldPos, float sunK) {
    float c = causticPattern(worldPos.xz, frameTimeCounter);
    return 1.0 + (c - 0.5) * 1.6 * sunK;
}
#endif
