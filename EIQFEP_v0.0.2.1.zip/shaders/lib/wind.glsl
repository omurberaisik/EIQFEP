#ifndef EIQ_WIND
#define EIQ_WIND
#include "/lib/materials.glsl"

// =============================================================================
//  Ruzgar. DIKKAT: Iris'te at_midBlock = (blok merkezi - kose) * 64  (merkeze giden vektor).
//  Koseden yuksekligi: vy = 0.5 - at_midBlock.y / 64  (0 = blok tabani, 1 = blok tepesi)
// =============================================================================
float blockHeightFromMid(float midY) { return 0.5 - midY / 64.0; }

vec3 applyWind(vec3 playerPos, int id, float vy) {
    if (id != ID_LEAVES && !isPlantId(id)) return playerPos;
    vec3 wp = playerPos + cameraPosition;
    float t = frameTimeCounter;
    float str = WIND_STRENGTH * (0.45 + 0.9 * rainStrength);
    float gust = 0.5 + 0.5 * sin(dot(wp.xz, vec2(0.11, 0.07)) + t * 0.35);
    float ph = dot(wp.xz, vec2(0.9, 0.6)) + t * 1.9;
    vec2 sway = vec2(sin(ph), cos(ph * 0.83 + 1.3)) * (0.5 + gust);
    vec2 flutter = vec2(sin(t * 4.1 + wp.x * 1.7 + wp.y * 2.3), cos(t * 3.7 + wp.z * 1.9)) * 0.35;

    float amp;
    if (id == ID_LEAVES) {
        amp = 0.030;                                   // komsu yapraklar ayni konum islevini paylasir: dikissiz
    } else if (id == ID_STACKED) {
        // kamis / kelp / deniz otu: tabana degil dunya konumuna bagli, uzun govdede kopukluk olmaz
        sway = vec2(sin(ph * 0.6 + wp.y * 0.7), cos(ph * 0.5 + wp.y * 0.6 + 1.3)) * (0.5 + 0.5 * gust);
        flutter = vec2(0.0);
        amp = 0.035;
    } else {
        float h = vy;                                  // bitki boyunca 0..1
        float k = 0.075;
        if (id == ID_TALL_LO) { h = 0.5 * vy; k = 0.140; }
        if (id == ID_TALL_HI) { h = 0.5 + 0.5 * vy; k = 0.140; }   // alt yari tepesiyle ust yari tabani ayni kayar
        amp = k * h * h;
    }
    playerPos.xz += (sway + flutter) * amp * str;
    return playerPos;
}
#endif
