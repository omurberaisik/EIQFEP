// =============================================================================
//  EIQFEP - composite3: bloom kaynagi + log-parlaklik (otomatik pozlama icin)
//  colortex4 mipmap'lenir; final bu mip zincirini okur.
// =============================================================================
#include "/lib/common.glsl"

#ifdef VSH
out vec2 texcoord;
void main() { gl_Position = ftransform(); texcoord = gl_MultiTexCoord0.xy; }
#endif

#ifdef FSH
in vec2 texcoord;
uniform sampler2D colortex0;
layout(location = 0) out vec4 outColor;

void main() {
    vec3 c = texture(colortex0, texcoord).rgb;
    c = min(c, vec3(48.0));                       // ates bocegi (firefly) siniri
    float l = luma(c);
    outColor = vec4(c, log2(l + 1e-3));
}
#endif
