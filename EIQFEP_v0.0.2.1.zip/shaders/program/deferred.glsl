// =============================================================================
//  EIQFEP - deferred: gokyuzu + G-buffer'dan PBR aydinlatma
// =============================================================================
#define EIQ_DEFERRED
#include "/lib/common.glsl"
#include "/lib/sky.glsl"
#include "/lib/lighting.glsl"
#include "/lib/ao.glsl"

#ifdef VSH
out vec2 texcoord;
flat out vec3 vLightDir;
flat out vec3 vLightColor;
flat out vec3 vSunColor;
flat out vec3 vMoonColor;
flat out vec3 vAmbUp;
flat out vec3 vAmbHor;
flat out vec3 vAmbGround;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    computeAtmoLight(vLightDir, vLightColor, vAmbUp, vAmbHor, vAmbGround);
#if EIQ_DIM == 0
    sunMoonColors(vSunColor, vMoonColor);
#else
    vSunColor = vec3(0.0);
    vMoonColor = vec3(0.0);
#endif
}
#endif

#ifdef FSH
in vec2 texcoord;
flat in vec3 vLightDir;
flat in vec3 vLightColor;
flat in vec3 vSunColor;
flat in vec3 vMoonColor;
flat in vec3 vAmbUp;
flat in vec3 vAmbHor;
flat in vec3 vAmbGround;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform int heldBlockLightValue;

layout(location = 0) out vec4 outColor;
#if EIQ_DIM == 0
layout(location = 1) out vec4 outSkyA;   // colortex7: atmosfer onbellegi (a = 1: gecerli gokyuzu)
layout(location = 2) out vec4 outSkyC;   // colortex8: bulut onbellegi
uniform sampler2D colortex7;
uniform sampler2D colortex8;
#endif

#if EIQ_DIM == 0 && SKY_CACHE_ON
// Onceki karedeki onbellekten iki-dogrusal okuma. Dort komsudan biri bile gecersizse (gokyuzu degil /
// ekran disi) reddedilir ve piksel taze hesaplanir.
bool fetchSkyCache(vec2 uv, out vec3 atmo, out vec4 cloud) {
    atmo = vec3(0.0); cloud = vec4(0.0, 0.0, 0.0, 1.0);
    vec2 sz = vec2(viewWidth, viewHeight);
    vec2 pp = uv * sz - 0.5;
    ivec2 i0 = ivec2(floor(pp));
    vec2 f = fract(pp);
    if (i0.x < 0 || i0.y < 0 || i0.x + 1 >= int(viewWidth) || i0.y + 1 >= int(viewHeight)) return false;
    vec4 a00 = texelFetch(colortex7, i0, 0);
    vec4 a10 = texelFetch(colortex7, i0 + ivec2(1, 0), 0);
    vec4 a01 = texelFetch(colortex7, i0 + ivec2(0, 1), 0);
    vec4 a11 = texelFetch(colortex7, i0 + ivec2(1, 1), 0);
    if (min(min(a00.a, a10.a), min(a01.a, a11.a)) < 0.5) return false;
    atmo = mix(mix(a00.rgb, a10.rgb, f.x), mix(a01.rgb, a11.rgb, f.x), f.y);
    vec4 c00 = texelFetch(colortex8, i0, 0);
    vec4 c10 = texelFetch(colortex8, i0 + ivec2(1, 0), 0);
    vec4 c01 = texelFetch(colortex8, i0 + ivec2(0, 1), 0);
    vec4 c11 = texelFetch(colortex8, i0 + ivec2(1, 1), 0);
    cloud = mix(mix(c00, c10, f.x), mix(c01, c11, f.x), f.y);
    return true;
}
#endif

void main() {
#if EIQ_DIM == 0
    outSkyA = vec4(0.0);
    outSkyC = vec4(0.0);
#endif
    float depth = texture(depthtex0, texcoord).r;
    vec3 color = texture(colortex0, texcoord).rgb;
    bool dhPix = false;
    float dhd = 1.0;
#ifdef DISTANT_HORIZONS
    if (depth >= 1.0) { dhd = texture(dhDepthTex0, texcoord).r; dhPix = dhd < 1.0; }
#endif

    g_LightDir = vLightDir; g_LightColor = vLightColor;
    g_AmbUp = vAmbUp; g_AmbHor = vAmbHor; g_AmbGround = vAmbGround;

    // ---- Gokyuzu -------------------------------------------------------------
    if (depth >= 1.0 && !dhPix) {
        vec3 viewPos = viewPosFromDepth(texcoord, 1.0);
        vec3 rd = normalize(mat3(gbufferModelViewInverse) * viewPos);
        float jit = blueNoise4(gl_FragCoord.xy).z;
#if USE_TAA == 0
        jit = 0.5 + (jit - 0.5) * 0.25;        // TAA yok: gurultuyu birikim temizleyemez, jitter'i kis
#endif
#if EIQ_DIM == 0 && SKY_CACHE_ON
        {
            // 2x2 desen: her piksel 4 karede bir tazelenir, aradaki karelerde onceki kareden yeniden projekte edilir
            ivec2 ip = ivec2(gl_FragCoord.xy);
            bool myTurn = ((ip.x & 1) + 2 * (ip.y & 1)) == (frameCounter & 3);
            vec3 atmo = vec3(0.0);
            vec4 cl = vec4(0.0, 0.0, 0.0, 1.0);
            bool ok = false;
            if (!myTurn) {
                vec4 pc = gbufferPreviousProjection * vec4(mat3(gbufferPreviousModelView) * rd * 100.0, 1.0);
                if (pc.w > 0.0) ok = fetchSkyCache(pc.xy / pc.w * 0.5 + 0.5, atmo, cl);
            }
            if (!ok) {
                atmo = skyAtmoBase(rd, vAmbGround);
                cl = cloudMarch(rd, vLightDir, vLightColor, vAmbUp, jit);
            }
            outSkyA = vec4(atmo, 1.0);
            outSkyC = cl;
            color = renderSkyEx(rd, vSunColor, vMoonColor, vLightDir, vLightColor, vAmbUp, vAmbGround, jit, atmo, cl, true);
        }
#else
        color = renderSky(rd, vSunColor, vMoonColor, vLightDir, vLightColor, vAmbUp, vAmbGround, jit);
#endif
        outColor = vec4(color, 1.0);
        return;
    }

    // ---- Ileri boyanmis yuzeyler (portal, parcacik...) aydinlatilmaz ----------
    vec4 gm = texture(colortex2, texcoord);
    if (gm.a > 0.99) {
        outColor = vec4(color, 1.0);
        return;
    }

    // ---- G-buffer cozumleme ----------------------------------------------------
    vec4 g1 = texture(colortex1, texcoord);
    vec3 N = octDecode(g1.xy);
    vec2 lm = g1.zw;
    bool isHand = depth < 0.56;

    vec3 vp = dhPix ? dhViewPosSafe(texcoord, dhd) : viewPosFromDepth(texcoord, depth);
    vec3 posRel = viewToPlayer(vp);
    vec3 Nw = normalize(mat3(gbufferModelViewInverse) * N);
    vec3 Vw = normalize(-posRel);

    vec4 bn = blueNoise4(gl_FragCoord.xy);
    float n1 = bn.x;
    float n2 = bn.y;

    float smoothness = gm.r;
    float f0 = gm.g;
    float emis = gm.b;
    float sss = gm.a / 0.9;

    // ---- Golge -----------------------------------------------------------------
    vec3 shadowVis = vec3(1.0);
    float NoL = dot(Nw, g_LightDir);
    bool lit = dot(g_LightColor, vec3(1.0)) > 1e-4;
    if (lit && !isHand && (NoL > -0.15 || sss > 0.05) && lm.y > 0.02) {
        shadowVis = getShadow(posRel, Nw, g_LightDir, n1);
#if CONTACT_STEPS > 0
        if (NoL > 0.0 && shadowVis.r > 0.02 && !dhPix) {
            vec3 Lv = normalize(mat3(gbufferModelView) * g_LightDir);
            shadowVis *= contactShadow(vp, Lv, n2);
        }
#endif
    } else if (isHand) {
        shadowVis = vec3(saturate(lm.y * 1.2));
    }
#if CLOUD_SHADOW_ON && EIQ_DIM == 0
    if (lit && !isHand && lm.y > 0.3)
        shadowVis *= mix(1.0, cloudShadow(posRel + cameraPosition, g_LightDir), smoothstep(0.3, 0.8, lm.y));
#endif
    // Gokten gelen isik yoksa (magara) dogrudan isigi sonumle
    shadowVis *= smoothstep(0.02, 0.20, lm.y + (isHand ? 1.0 : 0.0));

    // ---- AO ----------------------------------------------------------------------
    float ao = 1.0;
#if AO_MODE > 0
    if (!isHand && !dhPix) ao = pow(computeAO(texcoord, vp, N, n1, n2), AO_STRENGTH);
#endif

    float handDist = 0.0;
    if (heldBlockLightValue > 0)
        handDist = max(length(posRel), 0.05) / (float(heldBlockLightValue) * 0.8 + 1.0);

#if RT_GI_ON
  #ifdef ADAPTIVE_QUALITY
    float rtK = 1.0 - smoothstep(40.0, 64.0, length(posRel));       // uzakta isin izlemeli GI atlanir (sisle zaten sonuk)
    g_RtSkyVis = 1.0; g_RtBounce = vec3(0.0);
    if (!isHand && !dhPix && rtK > 0.0) {
        rtGI(posRel, Nw, lm.y, bn);
        g_RtSkyVis = mix(1.0, g_RtSkyVis, rtK);
        g_RtBounce *= rtK;
    }
  #else
    if (!isHand && !dhPix) rtGI(posRel, Nw, lm.y, bn);
  #endif
#endif

    color = shadeSurface(color, Nw, Vw, posRel, lm, ao, smoothness, f0, emis, sss,
                         shadowVis, handDist, vec3(1.0));
    outColor = vec4(color, 1.0);
}
#endif
