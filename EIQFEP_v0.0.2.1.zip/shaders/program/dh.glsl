// =============================================================================
//  EIQFEP - Distant Horizons (DENEYSEL, yalnizca DH kuruluyken yuklenir)
//  dh_terrain / dh_water: uzak araziyi ayni G-buffer'a yazar; deferred ve sis pass'i
//  depthtex0 == 1 olan yerde dhDepthTex0'a bakarak bu pikselleri arazi sayar.
//  Malzeme kimligi (dhMaterialId) kullanilmaz: tum uzak arazi duz PBR.
// =============================================================================
#include "/lib/common.glsl"

#ifdef VSH
out vec4 vcolor;
out vec3 normalV;
void main() {
    vec4 vpos = gl_ModelViewMatrix * gl_Vertex;
    vcolor = gl_Color;
    normalV = normalize(gl_NormalMatrix * gl_Normal);
    gl_Position = gl_ProjectionMatrix * vpos;
    gl_Position.xy += taaJitter() * gl_Position.w;
}
#endif

#ifdef FSH
in vec4 vcolor;
in vec3 normalV;
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outN;
layout(location = 2) out vec4 outMat;

void main() {
#ifdef DH_WATER
    vec3 albedo = vec3(0.03, 0.14, 0.24);
    float sm = 0.90;
#else
    vec3 albedo = srgbToLinear(vcolor.rgb);
    float sm = 0.06;
#endif
    outColor = vec4(albedo, 1.0);
    outN = vec4(octEncode(normalize(normalV)), 0.0, 0.92);   // uzakta gok isigi kabul edilir, blok isigi yok
    outMat = vec4(sm, 0.04, 0.0, 0.0);
}
#endif
