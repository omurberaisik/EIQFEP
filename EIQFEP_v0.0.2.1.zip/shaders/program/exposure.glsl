// =============================================================================
//  EIQFEP - composite4: otomatik pozlama
//  Yalnizca colortex5 (0,0) texelini yazar; diger pikseller atilir.
// =============================================================================
#include "/lib/common.glsl"
#include "/lib/color.glsl"

#ifdef VSH
out vec2 texcoord;
void main() { gl_Position = ftransform(); texcoord = gl_MultiTexCoord0.xy; }
#endif

#ifdef FSH
in vec2 texcoord;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform float frameTime;
layout(location = 0) out vec4 outColor;

void main() {
    if (ivec2(gl_FragCoord.xy) != ivec2(0)) discard;

    float prev = texelFetch(colortex5, ivec2(0), 0).r;
#ifdef AUTO_EXPOSURE
    // Olcum: tek bir tepe mip yerine orta duzey mip uzerinde 4x4 orneklik izgara (merkez agirlikli).
    // (Ekran boyutu genelde 2'nin kuvveti degil; NPOT mip zincirinin tepesi surucuye gore guvenilmez.)
    float maxLod = floor(log2(max(viewWidth, viewHeight)));
    float lod = max(maxLod - 3.0, 0.0);
    vec3 accRgb = vec3(0.0);
    float accLog = 0.0;
    float wsum = 0.0;
    for (int iy = 0; iy < 4; iy++) {
        for (int ix = 0; ix < 4; ix++) {
            vec2 uv = (vec2(float(ix), float(iy)) + 0.5) / 4.0;
            float w = 1.0 + 1.2 * (1.0 - smoothstep(0.0, 0.5, length(uv - 0.5)));
            vec4 t = textureLod(colortex4, uv, lod);
            accRgb += t.rgb * w;
            accLog += t.a * w;
            wsum += w;
        }
    }
    float Llog = exp2(accLog / wsum);                          // log-ortalama (karanlik agirlikli)
    float Llin = luma(accRgb / wsum);                          // dogrusal ortalama (parlak kaynaklar)
    float L = pow(Llog, 0.68) * pow(max(Llin, 1e-4), 0.32);    // goz parlak kaynaklara da uyum saglar
    float target = clamp(EXPOSURE_KEY / max(L, 1e-4), 0.05, float(ST_EXPMAX));
    if (prev < 1e-3) prev = target;
    float dt = clamp(frameTime, 0.001, 0.25);
    float rate = (target < prev) ? 3.2 : 1.1;           // parlakta hizli, karanlikta yavas
    float e = mix(prev, target, 1.0 - exp(-dt * rate));
#else
    float e = 0.28;
#endif
    outColor = vec4(e, 0.0, 0.0, 1.0);
}
#endif
