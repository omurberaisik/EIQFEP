// =============================================================================
//  EIQFEP - final: bloom, pozlama, derecelendirme, ton esleme (SDR / HDR), kodlama
//  HDR: "Shaders + HDR" modu yukluyse scRGB-nl cikis, aksi halde sRGB.
//  HDR kodu bu dosyada izole tutulur: mod arayuzu degisirse tek yer guncellenir.
// =============================================================================
#include "/lib/common.glsl"
#include "/lib/color.glsl"

#ifdef VSH
out vec2 texcoord;
void main() { gl_Position = ftransform(); texcoord = gl_MultiTexCoord0.xy; }
#endif

#ifdef FSH
in vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D colortex4;
uniform sampler2D colortex5;

#if HDR_MOD_INSTALLED
uniform float HdrGameMinimumBrightness;
uniform float HdrGamePeakBrightness;
uniform float HdrGamePaperWhiteBrightness;
#endif

layout(location = 0) out vec4 outColor;

#ifdef MOTION_BLUR
// Kamera hareketi bulaniklugu: yeniden projeksiyon hizi boyunca 8 ornek
vec3 motionBlur(vec3 c) {
    float depth = texture(depthtex0, texcoord).r;
    if (depth < 0.56) return c;                    // el
    vec2 prevUV;
    if (depth >= 1.0) {
        vec3 dirW = mat3(gbufferModelViewInverse) * normalize(viewPosFromDepth(texcoord, 1.0));
        vec4 pc = gbufferPreviousProjection * vec4(mat3(gbufferPreviousModelView) * dirW * 100.0, 1.0);
        if (pc.w <= 0.0) return c;
        prevUV = pc.xy / pc.w * 0.5 + 0.5;
    } else {
        vec3 world = viewToPlayer(viewPosFromDepth(texcoord, depth)) + cameraPosition;
        vec3 pv = (gbufferPreviousModelView * vec4(world - previousCameraPosition, 1.0)).xyz;
        vec4 pc = gbufferPreviousProjection * vec4(pv, 1.0);
        if (pc.w <= 0.0) return c;
        prevUV = pc.xy / pc.w * 0.5 + 0.5;
    }
    vec2 vel = (texcoord - prevUV) * (0.5 * MOTION_BLUR_STRENGTH);
    float len = length(vel);
    if (len < 1e-4) return c;
    vel *= min(1.0, 0.06 / len);                   // en fazla ekranin %6'si
    float jit = blueNoise4(gl_FragCoord.xy).y;
    vec3 acc = c;
    for (int i = 0; i < 8; i++) {
        float k = (float(i) + jit) / 8.0 - 0.5;
        acc += texture(colortex0, clamp(texcoord + vel * k, vec2(0.0005), vec2(0.9995))).rgb;
    }
    return acc / 9.0;
}
#endif

// Film greni: parlak bolgelerde azalan, her karede degisen
float filmGrain(float l) {
    if (FILM_GRAIN <= 0.0) return 1.0;
    float g = hash12(gl_FragCoord.xy + vec2(float(frameCounter & 255) * 13.7, 7.3)) - 0.5;
    return 1.0 + g * FILM_GRAIN * 0.12 * (1.2 - saturate(l));
}

#if EIQ_DIM == 1
// End: golgelerde turkuaz-mor, parlak bolgelerde sicak sapma (cinematic split-tone)
vec3 endGrade(vec3 c) {
    float l = luma(c);
    float sh = 1.0 - smoothstep(0.02, 0.35, l);
    float hi = smoothstep(0.25, 1.50, l);
    c *= mix(vec3(1.0), vec3(0.90, 0.97, 1.10), sh * 0.6);
    c *= mix(vec3(1.0), vec3(1.06, 0.99, 0.95), hi * 0.5);
    return c;
}
#endif

#if EIQ_DIM == -1
// Nether: golgelerde biyom rengine kayan sicak ton, parlak bolgelerde altin sapma (sinematik split-tone)
vec3 netherGrade(vec3 c) {
#ifdef NETHER_GRADE
    float l = luma(c);
    float sh = 1.0 - smoothstep(0.02, 0.30, l);
    float hi = smoothstep(0.35, 2.0, l);
    vec3 fc = normalize(fogColor + 0.02);
    c *= mix(vec3(1.0), fc * 1.7, 0.20 * sh);
    c *= mix(vec3(1.0), vec3(1.07, 0.98, 0.85), hi * 0.5);
#endif
    return c;
}

#ifdef NETHER_HEAT_HAZE
// Lav denizine yakin uzak yuzeylerde sicak hava titresimi (ekran uzayi dalgalanma)
vec2 netherHeatOffset(vec2 uv) {
    float d = texture(depthtex0, uv).r;
    vec3 vp = viewPosFromDepth(uv, min(d, 0.9999));
    vec3 wp = viewToPlayer(vp) + cameraPosition;
    float h = exp(-max(wp.y - 32.0, 0.0) / 7.0) * smoothstep(8.0, 40.0, length(vp));
    float t = frameTimeCounter;
    vec2 w = vec2(sin(wp.y * 1.7 + t * 2.1 + wp.x * 0.3), cos(wp.y * 1.3 - t * 1.7 + wp.z * 0.3));
    return w * (h * 0.0016);
}
#endif
#endif

vec3 sampleBloom(vec2 uv) {
    vec3 acc = vec3(0.0);
    float wsum = 0.0;
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    for (int l = 1; l <= BLOOM_LODS; l++) {
        float lod = float(l);
        float w = 1.0 / (1.0 + 0.42 * lod);
        vec2 o = px * exp2(lod) * 0.5;
        vec3 s = textureLod(colortex4, uv, lod).rgb * 0.4;
        s += textureLod(colortex4, uv + vec2( o.x,  o.y), lod).rgb * 0.15;
        s += textureLod(colortex4, uv + vec2(-o.x,  o.y), lod).rgb * 0.15;
        s += textureLod(colortex4, uv + vec2( o.x, -o.y), lod).rgb * 0.15;
        s += textureLod(colortex4, uv + vec2(-o.x, -o.y), lod).rgb * 0.15;
        acc += s * w;
        wsum += w;
    }
    return acc / wsum;
}

#ifdef RAIN_DROPS
// Lens uzerinde yagmur damlalari: 2 olcekli izgara, her hucrede buyuyup kayan bir damla.
// Donus: uv kaymasi (damla icinde ters goruntu gibi kirilma). Yalnizca yagmurda ve acik havada.
vec2 rainDropOffset(vec2 uv) {
    float k = rainStrength * smoothstep(0.35, 0.90, float(eyeBrightnessSmooth.y) / 240.0);
    if (k < 0.01 || isEyeInWater != 0) return vec2(0.0);
    float aspect = viewWidth / viewHeight;
    vec2 off = vec2(0.0);
    for (int L = 0; L < 2; L++) {
        float scale = (L == 0) ? 7.0 : 13.0;
        vec2 p = vec2(uv.x * aspect, uv.y) * scale;
        vec2 cell = floor(p);
        vec2 h = hash22(cell + float(L) * 31.0);
        float life = fract(frameTimeCounter * (0.10 + 0.06 * h.x) + h.y);
        if (hash12(cell + 91.0 + float(L)) > 0.55 * k + 0.15) continue;      // her hucrede damla yok
        float r = 0.30 * smoothstep(0.0, 0.18, life) * (1.0 - 0.55 * smoothstep(0.7, 1.0, life));
        vec2 c = cell + vec2(0.2 + 0.6 * h.x, 0.75 - 0.55 * life * life + 0.1 * h.y);   // asagi kayar
        vec2 dlt = p - c;
        dlt.y *= 0.8;
        float dist = length(dlt);
        float m = smoothstep(r, r * 0.55, dist);
        off += (-dlt / max(r, 1e-3)) * m * 0.018 * (L == 0 ? 1.0 : 0.6);
    }
    return vec2(off.x / aspect, off.y);
}
#endif

#ifdef DOF
// Alan derinligi: odak = ekran merkezindeki (yumusatilmis) derinlik. CoC ~ |1/zf - 1/z|.
uniform float centerDepthSmooth;
float cocPx(float depth) {
    if (depth < 0.56) return 0.0;                                   // el net kalir
    float zf = max(linearizeDepth(centerDepthSmooth), 0.3);
    float z = depth >= 1.0 ? 1.0e4 : linearizeDepth(depth);
    return min(abs(1.0 / zf - 1.0 / z) * DOF_STRENGTH * 60.0 * (viewHeight / 1080.0), 12.0);
}
vec3 depthOfField(vec3 c, vec2 uv) {
    float d0 = texture(depthtex1, uv).r;
    float r0 = cocPx(d0);
    float rMax = max(r0, 0.0);
    if (rMax < 0.6) return c;
    float jit = blueNoise4(gl_FragCoord.xy).x;
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    vec3 acc = c;
    float wsum = 1.0;
    for (int i = 0; i < 12; i++) {
        vec2 o = vogel(i, 12, jit) * rMax;
        vec2 suv = uv + o * px;
        float ds = texture(depthtex1, suv).r;
        float rs = cocPx(ds);
        float w = saturate(rs - length(o) + 1.0);      // ornegin kendi bulaniklik yaricapi merkeze ulasiyorsa katki verir
        // on plandaki net piksel arka planin icine sizmasin
        if (ds < d0) w *= saturate(rs / max(r0, 1.0));
        vec3 s = texture(colortex0, suv).rgb;
        acc += s * w;
        wsum += w;
    }
    return acc / wsum;
}
#endif

#ifdef LENS_FLARE
// Gunes parlamasi: gunes ekrandaysa ve gokyuzu gorunuyorsa ekran merkezine dogru hayalet halkalar + halo.
vec3 lensFlare(vec2 uv) {
    vec3 sv = sunPosition;
    if (sv.z > 0.0) return vec3(0.0);
    vec4 cs = gbufferProjection * vec4(sv, 1.0);
    vec2 suv = cs.xy / cs.w * 0.5 + 0.5;
    if (suv.x < -0.1 || suv.x > 1.1 || suv.y < -0.1 || suv.y > 1.1) return vec3(0.0);
    // gorunurluk: gunes cevresinde 5 ornekten kacinin gokyuzu oldugu
    float vis = 0.0;
    vec2 pxo = vec2(0.012, 0.012 * viewWidth / viewHeight);
    for (int i = 0; i < 5; i++) {
        vec2 o = (i == 0) ? vec2(0.0) : vec2((i & 1) == 0 ? 1.0 : -1.0, (i & 2) == 0 ? 1.0 : -1.0) * pxo;
        vec2 q = suv + o;
        if (q.x > 0.0 && q.x < 1.0 && q.y > 0.0 && q.y < 1.0) vis += step(1.0, texture(depthtex0, q).r) * 0.2;
    }
    float edge = smoothstep(0.0, 0.15, min(min(suv.x, 1.0 - suv.x), min(suv.y, 1.0 - suv.y)));
    float sunUp = (gbufferModelViewInverse * vec4(sunPosition, 0.0)).y;
    vis *= edge * smoothstep(0.0, 0.1, sunUp) * (1.0 - rainStrength);
    if (vis <= 0.0) return vec3(0.0);
    vec2 a = vec2((uv.x - 0.5) * viewWidth / viewHeight, uv.y - 0.5);
    vec2 s0 = vec2((suv.x - 0.5) * viewWidth / viewHeight, suv.y - 0.5);
    vec3 acc = vec3(0.0);
    for (int g = 0; g < 4; g++) {                    // sunden merkezin otesine uzanan hayaletler
        float k = -0.35 - 0.45 * float(g);
        vec2 gc = s0 * k;
        float d = length(a - gc);
        float rad = 0.05 + 0.03 * float(g);
        vec3 tint = (g == 0) ? vec3(1.0, 0.8, 0.5) : (g == 1) ? vec3(0.6, 0.9, 1.0) : (g == 2) ? vec3(0.9, 0.6, 1.0) : vec3(0.7, 1.0, 0.7);
        acc += tint * smoothstep(rad, rad * 0.4, d) * 0.05 / (1.0 + float(g));
        acc += tint * exp(-sq((d - rad) * 60.0)) * 0.03;        // halka
    }
    float ds = length(a - s0);
    acc += vec3(1.0, 0.85, 0.6) * (exp(-ds * 7.0) * 0.10);        // halo
    return acc * vis;
}
#endif

void main() {
    vec2 tc = texcoord;
#if EIQ_DIM == -1 && defined(NETHER_HEAT_HAZE)
    tc += netherHeatOffset(texcoord);
#endif
#ifdef RAIN_DROPS
    tc += rainDropOffset(texcoord);
#endif
    vec3 c = texture(colortex0, tc).rgb;
    float expo = texelFetch(colortex5, ivec2(0), 0).r;
    if (expo < 1e-3) expo = 0.28;
    expo *= exp2(E_EXPOSURE_EV);

#ifdef DOF
    c = depthOfField(c, tc);
#endif

    // Keskinlestirme: yerel min/max ile sinirli (halo yok). DOF acikken atlanir (bulaniklik geri alinmasin)
#if SHARPEN && !defined(DOF)
    {
        vec2 px = 1.0 / vec2(viewWidth, viewHeight);
        vec3 n0 = texture(colortex0, tc + vec2(px.x, 0.0)).rgb;
        vec3 n1 = texture(colortex0, tc - vec2(px.x, 0.0)).rgb;
        vec3 n2 = texture(colortex0, tc + vec2(0.0, px.y)).rgb;
        vec3 n3 = texture(colortex0, tc - vec2(0.0, px.y)).rgb;
        vec3 w0 = c / (1.0 + c), w1 = n0 / (1.0 + n0), w2 = n1 / (1.0 + n1), w3 = n2 / (1.0 + n2), w4 = n3 / (1.0 + n3);
        vec3 mn = min(w0, min(min(w1, w2), min(w3, w4)));
        vec3 mx = max(w0, max(max(w1, w2), max(w3, w4)));
        vec3 blur = (w1 + w2 + w3 + w4) * 0.25;
        vec3 sh = clamp(w0 + (w0 - blur) * SHARPEN_AMOUNT, mn, mx);
        c = sh / max(vec3(1.0) - sh, vec3(1e-3));
    }
#endif

#ifdef MOTION_BLUR
    c = motionBlur(c);
#endif

    // Kromatik sapma: kirmizi/mavi kanallari merkezden disa dogru kaydirir (fark olarak eklenir: onceki efektler korunur)
    if (CHROMA_ABERR > 0.0) {
        vec2 dv = (tc - 0.5) * (0.006 * CHROMA_ABERR);
        c.r += texture(colortex0, tc + dv).r - texture(colortex0, tc).r;
        c.b += texture(colortex0, tc - dv).b - texture(colortex0, tc).b;
        c = max(c, vec3(0.0));
    }

    // Bloom
#if BLOOM_LODS > 0
#if EIQ_DIM == 1
    c += sampleBloom(tc) * (0.052 * E_BLOOM);        // End'de Goz ve isiltilar daha cok parlar
#else
    c += sampleBloom(tc) * (0.040 * E_BLOOM);
#endif
#endif

#ifdef LENS_FLARE
    c += lensFlare(texcoord) / max(expo, 1e-3) * 0.6;
#endif
    c *= expo;
    c = whiteBalance(c, E_COLOR_TEMP);

    // Vinyet
    vec2 vc = texcoord * 2.0 - 1.0;
    vc.x *= viewWidth / viewHeight;
    c *= 1.0 - E_VIGNETTE * pow(saturate(dot(vc, vc) * 0.30), 1.6);

    c = gradeColor(c, E_CONTRAST, E_SATURATION);
#if EIQ_DIM == 1
    c = endGrade(c);
#elif EIQ_DIM == -1
    c = netherGrade(c);
#endif

#if HDR_MOD_INSTALLED && HDR_ENABLED
    float paper = max(HdrGamePaperWhiteBrightness, 1.0);
    float peakRel = max(HdrGamePeakBrightness / paper, 1.0);
    vec3 d = tonemapHDR(c, peakRel);
    d *= filmGrain(luma(d));
    d += triDither(gl_FragCoord.xy, frameCounter) * (1.0 / 1023.0);
    outColor = vec4(encodeScRGBnl(d), 1.0);
#else
    vec3 d = tonemapSDR(c);
    d *= filmGrain(luma(d));
    vec3 e = linearToSrgb(d);
    e += triDither(gl_FragCoord.xy, frameCounter) * (1.0 / 255.0);
    outColor = vec4(saturate(e), 1.0);
#endif
}
#endif
