// =============================================================================
//  EIQFEP - composite1: sis, havasal perspektif, hacimsel isik huzmeleri,
//  su alti ve lav sisi. Gokyuzu pikselleri (depth=1) yalnizca su alti/lav icin islenir.
// =============================================================================
#include "/lib/common.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/shadows.glsl"
#include "/lib/water.glsl"
#include "/lib/atmofx.glsl"
#if EIQ_DIM == -1
#include "/lib/netherfog.glsl"
#endif

#ifdef VSH
out vec2 texcoord;
flat out vec3 vLightDir;
flat out vec3 vLightColor;
flat out vec3 vAmbUp;
flat out vec3 vAmbHor;
flat out vec3 vAmbGround;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    computeAtmoLight(vLightDir, vLightColor, vAmbUp, vAmbHor, vAmbGround);
}
#endif

#ifdef FSH
in vec2 texcoord;
flat in vec3 vLightDir;
flat in vec3 vLightColor;
flat in vec3 vAmbUp;
flat in vec3 vAmbHor;
flat in vec3 vAmbGround;
uniform sampler2D colortex0;
uniform float eiqHot;      // shaders.properties: cul/kurak biyom (0..1)
uniform float eiqHumid;    // bataklik/orman nemi (0..1)
layout(location = 0) out vec4 outColor;

// Ustel yukseklik sisinin optik derinligi (kapali form)
float fogTau(float sigma0, float y0, float rdY, float d, float H) {
    float a = sigma0 * exp(-max(y0, 0.0) / H);
    float k = rdY / H;
    if (abs(k) < 1e-4) return a * d;
    return a * (1.0 - exp(-k * d)) / k;
}

// Ekran uzayi huzmeler + bosluk sporlari / korler: sis uygulandiktan sonra eklenir
vec3 postFx(vec3 rd, float dist, bool sky, float eyeSky) {
    vec3 fx = vec3(0.0);
    vec4 bn = blueNoise4(gl_FragCoord.xy);
#if GODRAY_STEPS > 0 && EIQ_DIM != -1
    if (dot(vLightColor, vec3(1.0)) > 1e-3) {
        float cosA = dot(rd, vLightDir);
  #if EIQ_DIM == 0
        float low = 1.0 + 1.6 * (1.0 - smoothstep(0.0, 0.5, vLightDir.y));
        float k = 0.10 * GODRAYS_STRENGTH * low * (1.0 - 0.75 * rainStrength) * mix(0.35, 1.0, smoothstep(0.1, 0.6, eyeSky));
  #else
        float k = 0.13 * GODRAYS_STRENGTH;
  #endif
        fx += godRays(texcoord, vLightDir, vLightColor, cosA, bn.z) * (k * (sky ? 0.5 : 1.0));
    }
#endif
#if MOTE_STEPS > 0
  #if EIQ_DIM == 1 && defined(END_MOTES)
    fx += motes(rd, sky ? 60.0 : min(dist, 60.0), bn.x, false, 0.16, vec4(0.0));
  #elif EIQ_DIM == -1 && defined(NETHER_EMBERS)
    fx += motes(rd, sky ? 48.0 : min(dist, 48.0), bn.x, true, 0.12, netherBiome());
  #endif
#endif
    return fx;
}


void main() {
    vec3 color = texture(colortex0, texcoord).rgb;
    float depth = texture(depthtex0, texcoord).r;
    bool dhPix = false;
    float dhd = 1.0;
#ifdef DISTANT_HORIZONS
    if (depth >= 1.0) { dhd = texture(dhDepthTex0, texcoord).r; dhPix = dhd < 1.0; }
#endif
    bool sky = depth >= 1.0 && !dhPix;
    vec3 vp = dhPix ? dhViewPosSafe(texcoord, dhd) : viewPosFromDepth(texcoord, sky ? 0.9999 : depth);
    vec3 posRel = viewToPlayer(vp);
    float dist = length(posRel);
    vec3 rd = posRel / max(dist, 1e-4);
    float mu = dot(rd, vLightDir);

    float eyeSky = float(eyeBrightnessSmooth.y) / 240.0;

    // ---------------------------------------------------------------- su alti
    if (isEyeInWater == 1) {
        float d = sky ? 70.0 : min(dist, 70.0);
        vec3 absorb = WATER_ABSORB * 0.30;
        vec3 T = exp(-absorb * d);
#if EIQ_LEVEL >= 3
        if (!sky && dot(vLightColor, vec3(1.0)) > 1e-3) {
            vec3 wpS = posRel + cameraPosition;
            if (wpS.y < cameraPosition.y - 0.2) {
                float sunK = saturate(luma(vLightColor) / (SUN_S * 0.55)) * saturate(vLightDir.y * 2.5);
                color *= mix(1.0, causticFactor(wpS, sunK), exp(-d * 0.10));
            }
        }
#endif
        vec3 wcol = vec3(0.020, 0.16, 0.20);
        vec3 light = vAmbUp * 0.55 + vLightColor * 0.22 * max(vLightDir.y, 0.0);
        light *= mix(0.12, 1.0, smoothstep(0.0, 0.7, eyeSky));
        vec3 scat = wcol * light * (vec3(1.0) - T);

        float shaft = 0.0;
#if VL_STEPS > 0
        if (dot(vLightColor, vec3(1.0)) > 1e-3) {
            float vlLen = min(d, 40.0);
            float stp = vlLen / float(VL_STEPS);
            float jit = blueNoise4(gl_FragCoord.xy).w;
            for (int i = 0; i < VL_STEPS; i++) {
                vec3 p = rd * ((float(i) + jit) * stp);
                vec3 sc = toShadowCoord(p);
                if (any(lessThan(sc.xy, vec2(0.0))) || any(greaterThan(sc.xy, vec2(1.0)))) continue;
                float vis = step(sc.z - 0.0005, texture(shadowtex1, sc.xy).r);
                shaft += vis * stp * exp(-0.09 * (float(i) + jit) * stp);
            }
            shaft *= 0.035;
        }
#endif
        scat += vLightColor * vec3(0.35, 0.95, 1.0) * PI * phaseHG(mu, 0.7) * shaft;
        color = color * T + scat;
        if (blindness > 0.0) color *= exp(-(sky ? 60.0 : dist) * blindness * 0.25);
        outColor = vec4(color, 1.0);
        return;
    }

    // ---------------------------------------------------------------- lav
    if (isEyeInWater == 2) {
        float d = sky ? 6.0 : min(dist, 6.0);
        float T = exp(-d * 0.65);
        color = color * T + vec3(1.6, 0.42, 0.06) * (1.0 - T) * 2.2;
        if (blindness > 0.0) color *= exp(-(sky ? 60.0 : dist) * blindness * 0.25);
        outColor = vec4(color, 1.0);
        return;
    }

    if (sky) {
        color += postFx(rd, dist, true, eyeSky);
        // Kor etkisi: gokyuzu da (sonsuz uzaklik) sonmeli
        if (blindness > 0.0) color *= exp(-60.0 * blindness * 0.25);
        outColor = vec4(color, 1.0);
        return;
    }

    // ---------------------------------------------------------------- dunya
    float y0 = cameraPosition.y - 63.0;
    float tau;
    vec3 inCol;
#if EIQ_DIM == 0
    float sigma0 = 0.00042 * E_FOG * (1.0 + 7.0 * rainStrength + 2.0 * wetness);
    tau = fogTau(sigma0, y0, rd.y, dist, 190.0);
    // Karanlik ortamlarda (magara) sis soner
    float indoor = mix(0.10, 1.0, smoothstep(0.05, 0.75, eyeSky));
#ifdef BIOME_FOG
    tau *= 1.0 + 0.9 * eiqHot + 1.2 * eiqHumid;          // cul tozu / nemli hava
#endif
#ifdef MORNING_MIST
    {
        // Gun dogumu / alacakaranlikta alcak yer sisi (yukseklik olcegi 22 m); nemli biyomlarda daha yogun
        float edgeT = min(sunAngle, 1.0 - sunAngle);
        float mistK = (1.0 - smoothstep(0.0, 0.08, edgeT)) + 0.8 * (1.0 - smoothstep(0.0, 0.05, abs(sunAngle - 0.5)));
        mistK *= 1.0 + 1.5 * eiqHumid;
        tau += fogTau(0.0045 * E_FOG * mistK, y0, rd.y, dist, 22.0);
    }
#endif
    tau *= mix(0.35, 1.0, indoor);
    vec3 ambCol = vAmbHor * indoor;
#ifdef BIOME_FOG
    ambCol *= mix(vec3(1.0), vec3(1.18, 1.00, 0.78), eiqHot) * mix(vec3(1.0), vec3(0.88, 1.06, 0.90), eiqHumid);
#endif
    float sunVis = indoor;
    // Alcak gunesle (dogus/batis) hacimsel isik daha guclu saciliyor; kullanici carpani ile birlikte
    float volBoost = VOLUMETRIC_STRENGTH * (1.0 + 1.8 * (1.0 - smoothstep(0.0, 0.45, vLightDir.y)));
    vec3 sunTerm = vLightColor * PI * phaseHG(mu, 0.58) * 0.9 * volBoost;
    float lightAcc = 0.0;
  #if VL_STEPS > 0
    if (dot(vLightColor, vec3(1.0)) > 1e-3 && eyeSky > 0.02) {
        float vlLen = min(dist, 96.0);
        float stp = vlLen / float(VL_STEPS);
        float jit = blueNoise4(gl_FragCoord.xy).w;
        float acc = 0.0;
        for (int i = 0; i < VL_STEPS; i++) {
            float s = (float(i) + jit) * stp;
            vec3 p = rd * s;
            vec3 sc = toShadowCoord(p);
            float vis = 1.0;
            if (!(any(lessThan(sc.xy, vec2(0.0))) || any(greaterThan(sc.xy, vec2(1.0)))))
                vis = step(sc.z - 0.0005, texture(shadowtex1, sc.xy).r);
            float sg = sigma0 * exp(-max(y0 + rd.y * s, 0.0) / 190.0);
            acc += vis * sg * stp * exp(-sg * s);
        }
        float tauNear = fogTau(sigma0, y0, rd.y, vlLen, 190.0);
        float farLit = max(exp(-tauNear) - exp(-tau), 0.0);
        lightAcc = acc + farLit;
        sunVis = 1.0;
    } else
  #endif
    {
        lightAcc = (1.0 - exp(-tau)) * sunVis;
    }
    inCol = ambCol * (1.0 - exp(-tau)) + sunTerm * lightAcc;
    float T = exp(-tau);
    color = color * T + inCol;
#elif EIQ_DIM == -1
    color = netherFog(color, rd, dist, blueNoise4(gl_FragCoord.xy).w);
#else
    color = endFog(color, rd, dist, blueNoise4(gl_FragCoord.xy).w, vLightDir, vLightColor);
#endif

    color += postFx(rd, dist, false, eyeSky);

    // Kor etkisi (blindness)
    if (blindness > 0.0) color *= exp(-dist * blindness * 0.25);

    outColor = vec4(color, 1.0);
}
#endif
