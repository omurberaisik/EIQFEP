// =============================================================================
//  EIQFEP - gbuffers (tum geometri programlari tek dosyada)
//  PASS_TERRAIN / ENTITY / HAND  : G-buffer'a yazar (deferred aydinlatir)
//  PASS_WATER                    : saydamlar (su, cam, portal) ileri boyama
//  PASS_TEXTURED(_LIT) / BASIC   : parcaciklar ve cizgiler, ileri boyama
//  PASS_WEATHER                  : yagmur / kar
// =============================================================================
#if defined(PASS_WATER) || defined(PASS_TEXTURED) || defined(PASS_TEXTURED_LIT) || defined(PASS_WEATHER)
  #define FORWARD_LIT
  #define ATMO_AMB_STEPS 4
  #define ATMO_AMB_LSTEPS 2
#endif

#include "/lib/common.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/materials.glsl"
#include "/lib/wind.glsl"
#include "/lib/lighting.glsl"

// ============================================================================
#ifdef VSH
in vec4 mc_Entity;
in vec2 mc_midTexCoord;
in vec4 at_tangent;
in vec4 at_midBlock;
uniform int blockEntityId;

out vec2 texcoord;
out vec2 lmcoord;
out vec4 vcolor;
out vec3 normalV;
out vec4 tangentV;
out vec3 playerPosV;
flat out int idV;
flat out vec2 tileMidV;
flat out vec2 tileHalfV;
#ifdef FORWARD_LIT
flat out vec3 vLightDir;
flat out vec3 vLightColor;
flat out vec3 vAmbUp;
flat out vec3 vAmbHor;
flat out vec3 vAmbGround;
#endif

void main() {
    vec4 vpos = gl_ModelViewMatrix * gl_Vertex;
    vec3 playerPos = (gbufferModelViewInverse * vpos).xyz;

    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vcolor   = gl_Color;

    int id = int(mc_Entity.x + 0.5);
#if defined(PASS_TERRAIN) || defined(PASS_WATER)
    if (blockEntityId > 0) id = blockEntityId;
#endif
    idV = id;

    vec3 n = normalize(gl_NormalMatrix * gl_Normal);
#ifdef PASS_TERRAIN
    playerPos = applyWind(playerPos, id, blockHeightFromMid(at_midBlock.y));
    if (isPlantId(id)) n = normalize((gbufferModelView * vec4(0.0, 1.0, 0.0, 0.0)).xyz);
#endif
    normalV = n;
    vec3 tgV = gl_NormalMatrix * at_tangent.xyz;
    tangentV = vec4(dot(tgV, tgV) > 1e-8 ? normalize(tgV) : vec3(0.0), at_tangent.w);
    tileMidV = mc_midTexCoord;
    tileHalfV = abs(texcoord - mc_midTexCoord);
    playerPosV = playerPos;

#ifdef PASS_HAND
    gl_Position = gl_ProjectionMatrix * vpos;
#else
    vec3 viewP = (gbufferModelView * vec4(playerPos, 1.0)).xyz;
    gl_Position = gl_ProjectionMatrix * vec4(viewP, 1.0);
#endif
    gl_Position.xy += taaJitter() * gl_Position.w;

#ifdef FORWARD_LIT
    computeAtmoLight(vLightDir, vLightColor, vAmbUp, vAmbHor, vAmbGround);
#endif
}
#endif

// ============================================================================
#ifdef FSH
in vec2 texcoord;
in vec2 lmcoord;
in vec4 vcolor;
in vec3 normalV;
in vec4 tangentV;
in vec3 playerPosV;
flat in int idV;
flat in vec2 tileMidV;
flat in vec2 tileHalfV;
#ifdef FORWARD_LIT
flat in vec3 vLightDir;
flat in vec3 vLightColor;
flat in vec3 vAmbUp;
flat in vec3 vAmbHor;
flat in vec3 vAmbGround;
#endif

uniform sampler2D gtexture;
uniform sampler2D normals;
uniform sampler2D specular;
uniform vec4 entityColor;
uniform int heldBlockLightValue;

layout(location = 0) out vec4 outColor;
#ifndef PASS_WEATHER
layout(location = 1) out vec4 outN;
layout(location = 2) out vec4 outMat;
#endif
#ifdef PASS_WATER
layout(location = 3) out vec4 outWater;   // colortex6: su katmani (rgb = sacilma rengi, a = kapsama)
#endif

vec2 lightmapUV() {
    vec2 l = clamp((lmcoord - 0.0313) * 1.0667, 0.0, 1.0);
#if EIQ_DIM != 0
    l.y = 1.0;        // End/Nether'in (0.0.0.6) gokyuzu isigi yok (has_skylight = false): acik alan kabul edilir, perdeleme AO / golge haritasi / isin izlemeden gelir
#endif
    return l;
}

#ifndef PASS_WEATHER
void writePassthrough(vec3 color, float alpha, vec2 lm) {
    outColor = vec4(color, alpha);
    outN = vec4(0.5, 0.5, lm);
    outMat = vec4(0.0, 0.0, 0.0, 1.0);   // a = 1 : deferred aydinlatmayi atla
}
#endif

// ----------------------------------------------------------------------------
//  Otomatik normal: doku parlakligindan yukseklik, pikselden bagimsiz yumusak
// ----------------------------------------------------------------------------
#if defined(PASS_TERRAIN) && NORMAL_GEN > 0
float texHeight(ivec2 p, ivec2 lo, ivec2 hi) {
    p = clamp(p, lo, hi);
    return luma(texelFetch(gtexture, p, 0).rgb);
}
float texHeightBil(vec2 pt, ivec2 lo, ivec2 hi) {
    vec2 f = fract(pt - 0.5);
    ivec2 i = ivec2(floor(pt - 0.5));
    float a = texHeight(i, lo, hi);
    float b = texHeight(i + ivec2(1, 0), lo, hi);
    float c = texHeight(i + ivec2(0, 1), lo, hi);
    float d = texHeight(i + ivec2(1, 1), lo, hi);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}
vec3 autoNormalTS() {
    ivec2 asz = textureSize(gtexture, 0);
    vec2 szf = vec2(asz);
    ivec2 lo = max(ivec2(floor((tileMidV - tileHalfV) * szf + 0.5)), ivec2(0));
    ivec2 hi = min(ivec2(floor((tileMidV + tileHalfV) * szf - 0.5)), asz - 1);
    if (hi.x <= lo.x || hi.y <= lo.y) return vec3(0.0, 0.0, 1.0);
    vec2 pt = texcoord * szf;
    float dhdu, dhdv;
  #if NORMAL_GEN == 1
    ivec2 p = ivec2(floor(pt));
    dhdu = texHeight(p + ivec2(1, 0), lo, hi) - texHeight(p - ivec2(1, 0), lo, hi);
    dhdv = texHeight(p + ivec2(0, 1), lo, hi) - texHeight(p - ivec2(0, 1), lo, hi);
    dhdu *= 0.5; dhdv *= 0.5;
  #else
    const float st = 0.8;
    dhdu = texHeightBil(pt + vec2(st, 0.0), lo, hi) - texHeightBil(pt - vec2(st, 0.0), lo, hi);
    dhdv = texHeightBil(pt + vec2(0.0, st), lo, hi) - texHeightBil(pt - vec2(0.0, st), lo, hi);
    dhdu /= (2.0 * st); dhdv /= (2.0 * st);
  #endif
    float s = 1.6 * AUTO_NORMAL_STRENGTH;
    return normalize(vec3(-dhdu * s, dhdv * s, 1.0));
}
#endif

// ----------------------------------------------------------------------------
//  Ileri boyama yardimcisi (parcacik, cam, portal vs.)
// ----------------------------------------------------------------------------
#ifdef FORWARD_LIT
vec3 forwardShade(vec3 albedo, vec3 Nv, vec2 lm, float emis, float sss, float smoothness) {
    g_LightDir = vLightDir; g_LightColor = vLightColor;
    g_AmbUp = vAmbUp; g_AmbHor = vAmbHor; g_AmbGround = vAmbGround;
    vec3 Nw = normalize(mat3(gbufferModelViewInverse) * Nv);
    vec3 Vw = normalize(-playerPosV);
    vec3 sh = vec3(saturate(lm.y * 1.25));
  #if EIQ_LEVEL >= 2
    if (dot(g_LightColor, vec3(1.0)) > 1e-3 && lm.y > 0.05) {
        float nz = blueNoise4(gl_FragCoord.xy).x;
        sh = getShadow(playerPosV, Nw, g_LightDir, nz);
    }
  #endif
    return shadeSurface(albedo, Nw, Vw, playerPosV, lm, 1.0, smoothness, 0.04, emis, sss, sh, 0.0, vec3(1.0));
}
#endif

// ----------------------------------------------------------------------------
//  Su dalgalari (analitik gradyan)
// ----------------------------------------------------------------------------
#ifdef PASS_WATER
vec3 waterNormalW(vec3 wp) {
    float t = frameTimeCounter;
    vec2 p = wp.xz;
    vec2 grad = vec2(0.0);
  #if EIQ_LEVEL >= 3
    const int NW = 7;
  #else
    const int NW = 4;
  #endif
    float rough = 1.0 + rainStrength * 1.2;
    for (int i = 0; i < NW; i++) {
        float a = float(i) * 2.399 + 0.6;
        vec2 d = vec2(cos(a), sin(a));
        float f = 0.50 * pow(1.52, float(i));
        float amp = 0.052 * rough / pow(1.50, float(i));
        float ph = dot(d, p) * f + t * sqrt(f) * 1.15;
        grad += d * cos(ph) * f * amp;
    }
    // ince detay: kayan gurultu gradyani
    vec2 q = p * 1.7 + vec2(t * 0.22, -t * 0.17);
    float e = 0.12;
    float n0 = vnoise2(q);
    vec2 ng = vec2(vnoise2(q + vec2(e, 0.0)) - n0, vnoise2(q + vec2(0.0, e)) - n0) / e;
    grad += ng * 0.07 * rough;
    vec2 q2 = p * 4.1 - vec2(t * 0.31, t * 0.27);
    float m0 = vnoise2(q2);
    vec2 mg = vec2(vnoise2(q2 + vec2(e, 0.0)) - m0, vnoise2(q2 + vec2(0.0, e)) - m0) / e;
    grad += mg * 0.03 * rough;
    return normalize(vec3(-grad.x, 1.0, -grad.y));
}

// Nether portali: derinlikli, surekli akan plazma (dunya konumuna bagli, her boyut/konumda calisir)
vec3 portalColor(vec3 wp, vec3 Nw, vec3 Vw) {
    bool alongX = abs(Nw.x) > 0.5;
    vec2 puv = alongX ? vec2(wp.z, wp.y) : vec2(wp.x, wp.y);
    vec2 vdir = alongX ? vec2(Vw.z, Vw.y) : vec2(Vw.x, Vw.y);
    float t = frameTimeCounter;
    vec3 col = vec3(0.0);
    for (int l = 0; l < 4; l++) {
        float depth = 0.14 * float(l);
        vec2 p = (puv - vdir * depth) * 1.1;
        float tl = t * (0.25 + 0.06 * float(l));
        vec2 q = p + vec2(0.0, -tl * 0.6);
        float a = fbm2(q * 1.3 + vec2(tl * 0.2, 0.0), 4);
        float b = fbm2(q * 2.1 + a * 2.4 + vec2(-tl * 0.3, tl * 0.15), 4);
        float v = smoothstep(0.30, 0.78, b);
        vec3 deep = vec3(0.06, 0.00, 0.20);
        vec3 mid  = vec3(0.45, 0.03, 0.80);
        vec3 hi   = vec3(0.95, 0.35, 1.00);
        vec3 c1 = mix(deep, mid, v);
        c1 = mix(c1, hi, pow(v, 5.0) * 0.8);
        col += c1 * (1.0 - 0.2 * float(l));
    }
    return col * 0.42;
}

float causticsLite(vec3 wp) { return 0.0; }
#endif

// ============================================================================
void main() {
    vec2 lm = lightmapUV();

#if defined(PASS_TERRAIN) || defined(PASS_ENTITY) || defined(PASS_HAND)
    // ------------------------------------------------------------------ G-buffer
    vec4 tex = texture(gtexture, texcoord);
    if (tex.a < 0.1) discard;
    int id = idV;
    vec3 wp = playerPosV + cameraPosition;

  #ifdef PASS_TERRAIN
    if (id == ID_ENDPORTAL) {
        // End portali: derinlikli kozmik bosluk
        vec3 Vw = normalize(-playerPosV);
        vec3 col = vec3(0.0);
        for (int l = 0; l < 6; l++) {
            float depth = 0.25 + float(l) * 0.55;
            vec2 uv = wp.xz - Vw.xz / max(abs(Vw.y), 0.06) * depth;
            vec2 g = uv * (2.2 + float(l) * 0.9);
            vec2 cell = floor(g);
            float h = hash12(cell + float(l) * 17.0);
            vec2 jp = hash22(cell + 3.0) * 0.6 + 0.2;
            float d = length(fract(g) - jp);
            float star = (h > 0.86) ? smoothstep(0.17, 0.0, d) : 0.0;
            vec3 tint = mix(vec3(0.20, 0.85, 0.75), vec3(0.55, 0.30, 1.00), hash12(cell + 9.0));
            float neb = fbm2(uv * 0.9 + float(l) * 4.0 + vec2(frameTimeCounter * 0.02, 0.0), 4);
            col += tint * (star * 3.2 + pow(neb, 3.0) * 0.55) / (1.0 + 0.22 * float(l));
        }
        col += vec3(0.01, 0.03, 0.04);
        writePassthrough(col * 1.6, 1.0, vec2(1.0));
        return;
    }
  #endif

    vec3 albedo = srgbToLinear(tex.rgb * vcolor.rgb);
  #ifdef PASS_ENTITY
    albedo = mix(albedo, srgbToLinear(entityColor.rgb), entityColor.a);
  #endif
    float ao = 1.0;
  #ifdef PASS_TERRAIN
    ao = vcolor.a;
  #endif

    Mat m = blockMaterial(id, albedo);
    vec4 spec = texture(specular, texcoord);
    bool hasSpec = textureSize(specular, 0).x > 1;
    if (hasSpec) {
        Mat lab = m;
        if (decodeLabPBR(spec, lab)) {
            float tableEmis = m.emis;
            m = lab;
            m.emis = max(lab.emis, tableEmis);
        }
    }

  #if defined(PASS_TERRAIN) && defined(END_STONE_GLINT)
    if (id == ID_ENDSTONE) {
        // Kozmik toz: dokuya sabit mikro kristaller, bakis acisina gore yanip soner (renkli: mor/turkuaz)
        vec3 Vs = normalize(-playerPosV);
        vec3 cell = floor(wp * 16.0);
        float tw = hash13(cell + 11.0);
        vec3 axis = normalize(vec3(hash13(cell + 2.7) - 0.5, hash13(cell + 8.1) - 0.2, hash13(cell + 5.3) - 0.5));
        float glint = step(0.975, tw) * pow(saturate(dot(Vs, axis)), 18.0) * (0.6 + 0.4 * sin(frameTimeCounter * 1.7 + tw * 300.0));
        albedo = mix(albedo, albedo * mix(vec3(0.9, 0.6, 1.2), vec3(0.6, 1.1, 1.1), hash13(cell + 3.3)), 0.35 * step(0.975, tw));
        m.emis += glint * 0.30;
    }
  #endif

  #if defined(PASS_TERRAIN) && defined(SNOW_SPARKLE)
    if (id == ID_SNOW) {
        // Kar parildamasi: dokuya sabit kristaller, bakis acisina bagli yanip soner. Yalnizca acik havada, gunduz.
        vec3 Vs = normalize(-playerPosV);
        vec3 cell = floor(wp * 16.0);
        float tw = hash13(cell);
        vec3 axis = normalize(vec3(hash13(cell + 1.7) - 0.5, 0.6, hash13(cell + 4.3) - 0.5));
        float glint = step(0.965, tw) * pow(saturate(dot(Vs, axis)), 22.0);
        float dayK = saturate(sin(sunAngle * TAU) * 2.0) * (1.0 - rainStrength) * smoothstep(0.6, 0.95, lm.y);
        m.emis += glint * 0.45 * dayK;
    }
  #endif

    // Normal
    vec3 Nv = normalize(normalV);
    vec3 N = Nv;
    vec4 nm = texture(normals, texcoord);
    bool hasNM = textureSize(normals, 0).x > 1 && (nm.x + nm.y) > 0.01;
    bool tangentOK = length(tangentV.xyz) > 0.1;
    vec3 T = tangentOK ? normalize(tangentV.xyz) : vec3(1.0, 0.0, 0.0);
    vec3 B = cross(T, Nv) * tangentV.w;
    if (hasNM && tangentOK) {
        vec2 nxy = nm.xy * 2.0 - 1.0;
        float nz = sqrt(saturate(1.0 - dot(nxy, nxy)));
        N = normalize(T * nxy.x + B * nxy.y + Nv * nz);
        ao *= mix(1.0, nm.z, 0.85);
    }
  #if defined(PASS_TERRAIN) && NORMAL_GEN > 0
    else if (tangentOK && !isPlantId(id) && id != ID_LEAVES) {
  #ifdef ADAPTIVE_QUALITY
        float anK = 1.0 - smoothstep(40.0, 72.0, length(playerPosV));   // uzakta doku normali minify olur: hesaplama
        if (anK > 0.0) {
            vec3 nts = autoNormalTS();
            N = normalize(mix(Nv, T * nts.x + B * nts.y + Nv * nts.z, anK));
        }
  #else
        vec3 nts = autoNormalTS();
        N = normalize(T * nts.x + B * nts.y + Nv * nts.z);
  #endif
    }
  #endif

  #if defined(PASS_TERRAIN) && defined(WET_SURFACES)
    {
        float wet = wetness * smoothstep(0.55, 0.95, lm.y);
        if (wet > 0.01) {
            vec3 Nw = normalize(mat3(gbufferModelViewInverse) * N);
            float up = saturate(Nw.y);
            float dark = wet * (0.30 + 0.45 * m.porosity);
            albedo = pow(max(albedo, vec3(1e-4)), vec3(1.0 + 0.55 * dark));
            m.smoothness = mix(m.smoothness, 0.86, saturate(wet * (0.25 + 0.55 * up)));
            m.f0 = max(m.f0, 0.03);
            float pud = puddleMask(wp.xz) * pow(up, 4.0) * saturate((wet - 0.25) * 2.0);
            if (pud > 0.01) {
                albedo *= mix(1.0, 0.55, pud);
                m.smoothness = mix(m.smoothness, 1.0, pud);
                m.f0 = mix(m.f0, 0.02, pud);
                vec2 r = rippleNormal(wp.xz, frameTimeCounter) * (rainStrength * 0.45);
                vec3 Npud = normalize(vec3(r.x, 1.0, r.y));
                Nw = normalize(mix(Nw, Npud, pud));
                N = normalize(mat3(gbufferModelView) * Nw);
            }
        }
    }
  #endif

    outColor = vec4(albedo, 1.0);
    outN = vec4(octEncode(N), lm);
    outMat = vec4(m.smoothness, m.f0, m.emis, m.sss * 0.9);

#elif defined(PASS_WATER)
    // ------------------------------------------------------------------ Saydamlar
    int id = idV;
    vec3 wp = playerPosV + cameraPosition;
    vec3 Ngv = normalize(normalV);
    vec3 Ngw = normalize(mat3(gbufferModelViewInverse) * Ngv);
    vec3 Vw = normalize(-playerPosV);
    vec4 tex = texture(gtexture, texcoord);

    if (id == ID_PORTAL) {
        if (dot(Ngw, Vw) < 0.0) discard;   // levhanin uzak (arkaya bakan) yuzunu at: cift katman olmasin
        vec3 col = portalColor(wp, Ngw, Vw);
        outColor = vec4(col * 2.2, 0.95);       // portal kendi isigini yayar: opak ve parlak
        outWater = vec4(0.0);
        outN = vec4(octEncode(Ngv), lm);
        outMat = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    if (id == ID_WATER) {
        if (isEyeInWater == 1) discard;     // su alti: yuzey sis pass'inde islenir
        vec3 Nw = Ngw;
        if (Ngw.y > 0.5) Nw = waterNormalW(wp);
        vec3 Nv = normalize(mat3(gbufferModelView) * Nw);

        vec2 suv = gl_FragCoord.xy / vec2(viewWidth, viewHeight);
        float sd = texture(depthtex1, suv).r;
        vec3 vpS = viewPosFromDepth(suv, sd);
        vec3 vpF = playerToView(playerPosV);
        float thick = (sd >= 1.0) ? 80.0 : max(distance(vpS, vpF), 0.0);

        // Biyom tonundan turetilen derin su rengi (turkuaz-mavi taban)
        vec3 wc = max(srgbToLinear(vcolor.rgb), vec3(0.02));
        vec3 wn = wc / max(max(wc.r, wc.g), wc.b);
        vec3 base = vec3(0.02, 0.19, 0.30);
        vec3 deep = mix(base, base * (wn * 1.8 + 0.1), 0.5);

        vec3 lightIn = vAmbUp * 0.80 + vLightColor * (0.15 * max(vLightDir.y, 0.0));
        float skyK = saturate(lm.y * 1.4 + 0.08);
        vec3 scatter = deep * lightIn * skyK;

        // Kiyi kopugu
        float foamN = fbm2(wp.xz * 3.2 + frameTimeCounter * vec2(0.35, 0.22), 3);
        float foam = smoothstep(0.38, 0.0, thick) * smoothstep(0.25, 0.7, foamN);
        vec3 foamCol = vec3(0.85) * (vAmbUp * 0.6 + vLightColor * 0.4 * saturate(lm.y));
        scatter = mix(scatter, foamCol, foam);

        outColor = vec4(0.0);                       // colortex0 degismez (blend alfa=0)
        outWater = vec4(scatter, 1.0);
        outN = vec4(octEncode(Nv), lm);
        outMat = vec4(mix(0.97, 0.45, foam), 0.02, foam, 0.0);
        return;
    }

    // cam, buz, slime ve diger saydamlar
    vec4 base = tex * vcolor;
    vec3 albedo = srgbToLinear(base.rgb);
    float alpha = base.a;
    float sm = 0.30, sss = 0.0;
    if (isGlassId(id)) { sm = 0.95; }
    else if (id == ID_ICE) { sm = 0.90; sss = 0.15; }
    else if (id == ID_SLIME) { sm = 0.80; sss = 0.5; }
    vec3 col = forwardShade(albedo, Ngv, lm, 0.0, sss, sm);
    outColor = vec4(col, alpha);
    outWater = vec4(0.0);
    outN = vec4(octEncode(Ngv), lm);
    outMat = vec4(sm, 0.04, 0.0, 0.0);

#elif defined(PASS_TEXTURED) || defined(PASS_TEXTURED_LIT)
    // ------------------------------------------------------------------ Parcaciklar
    vec4 tex = texture(gtexture, texcoord) * vcolor;
    if (tex.a < 0.02) discard;
    vec3 albedo = srgbToLinear(tex.rgb);
    bool glow = (lm.x > 0.97 && lm.y > 0.97);
    vec2 local = (tileHalfV.x > 1e-5 && tileHalfV.y > 1e-5)
               ? (texcoord - tileMidV) / tileHalfV : vec2(0.0);
    vec3 Nv = normalize(vec3(local.x, -local.y, 0.9));
    vec3 col = forwardShade(albedo, Nv, lm, glow ? 0.40 : 0.0, 0.25, 0.0);
    writePassthrough(col, tex.a, lm);

#elif defined(PASS_WEATHER)
    // ------------------------------------------------------------------ Yagmur / kar
    vec4 tex = texture(gtexture, texcoord);
    if (tex.a < 0.05) discard;
    vec3 light = vAmbHor * 1.1 + vLightColor * 0.10;
    float lum = luma(srgbToLinear(tex.rgb));
    vec3 col = light * (0.55 + 0.9 * lum) * mix(vec3(1.0), vec3(0.85, 0.92, 1.0), 0.6);
    outColor = vec4(col, tex.a * 0.42);

#else
    // ------------------------------------------------------------------ Cizgiler
    vec4 c = vcolor;
    writePassthrough(srgbToLinear(c.rgb), c.a, lm);
#endif
}
#endif
