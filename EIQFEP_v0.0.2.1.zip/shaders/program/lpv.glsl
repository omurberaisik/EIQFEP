// =============================================================================
//  EIQFEP - LPV yayilim (compute). shadowcomp .. shadowcomp3: 4 adim/kare, ping-pong.
//  Cift gecis A->B, tek gecis B->A; 4 gecis sonunda sonuc daima lpvImgA'da.
// =============================================================================
#include "/lib/common.glsl"
#include "/lib/lpv.glsl"

#ifdef CSH
layout(local_size_x = 8, local_size_y = 8, local_size_z = 8) in;
const ivec3 workGroups = ivec3(LPV_X / 8, LPV_Y / 8, LPV_Z / 8);

#if LPV_ACTIVE
uniform image3D lpvImgA;
uniform image3D lpvImgB;
uniform image3D voxEmit;
uniform image3D voxOpac;
#if RT_ON && LPV_PASS == 0
uniform image3D rtGeo;     // rgb = albedo/ton, a = opaklik (ornekleyici: rtGeoTex)
uniform image3D rtBrick;   // 4x4x4 tugla doluluk bayragi (ornekleyici: rtBrickTex)
#endif
uniform int heldItemId;
uniform int heldItemId2;
uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;

#if (LPV_PASS % 2) == 0
  #define LPV_SRC lpvImgA
  #define LPV_DST lpvImgB
#else
  #define LPV_SRC lpvImgB
  #define LPV_DST lpvImgA
#endif

// Elde tasinan isik: renk item.properties kimliginden (blok kimlikleriyle ayni numaralar)
vec3 heldLight(int itemId, int vanillaLevel, out bool has) {
    vec4 e = blockLightEmitter(itemId);
    has = false;
    if (e.w > 0.0)               { has = true; return e.rgb * (e.w / 15.0) * 0.85; }
    if (vanillaLevel > 0)        { has = true; return vec3(1.00, 0.62, 0.30) * (float(vanillaLevel) / 15.0); }
    return vec3(0.0);
}
#endif

void main() {
#if LPV_ACTIVE
    ivec3 p = ivec3(gl_GlobalInvocationID);
    if (any(greaterThanEqual(p, LPV_DIMS))) return;

    vec4 op = imageLoad(voxOpac, p);
    vec4 em = imageLoad(voxEmit, p);
#if RT_ON && LPV_PASS == 0
    // Isin izleme verisi: voksel geometrisinin kalici kopyasi + her 4x4x4 blok icin bos/dolu bayragi.
    // (bos tuglalar izleme sirasinda tek adimda atlanir)
    imageStore(rtGeo, p, op);
    if (all(lessThan(p, ivec3(RT_BRICK_X, RT_BRICK_Y, RT_BRICK_Z)))) {
        ivec3 b0 = p * 4;
        float occ = 0.0;
        for (int z = 0; z < 4; z++)
            for (int y = 0; y < 4; y++)
                for (int x = 0; x < 4; x++)
                    occ = max(occ, step(0.045, imageLoad(voxOpac, b0 + ivec3(x, y, z)).a));
        imageStore(rtBrick, p, vec4(occ, 0.0, 0.0, 1.0));
    }
#endif
    bool solid = op.a > 0.97;
    bool emitter = em.a > 0.0;
    vec3 own = em.rgb * em.a;

#ifdef HAND_LIGHT
    // Oyuncunun goz konumundaki vokselin ustune el isigi ekle (pas 0'da yeterli: sonra yayilir)
    ivec3 hv = lpvWrap(ivec3(floor(cameraPosition + vec3(0.0, -0.25, 0.0))));
    if (all(equal(p, hv))) {
        bool a1, a2;
        vec3 h1 = heldLight(heldItemId, heldBlockLightValue, a1);
        vec3 h2 = heldLight(heldItemId2, heldBlockLightValue2, a2);
        vec3 h = max(h1, h2);
        if (a1 || a2) { own = max(own, h); emitter = true; }
    }
#endif

    const ivec3 dirs[6] = ivec3[6](ivec3(1, 0, 0), ivec3(-1, 0, 0), ivec3(0, 1, 0),
                                   ivec3(0, -1, 0), ivec3(0, 0, 1), ivec3(0, 0, -1));
    vec3 best = vec3(0.0);
    vec3 sum = vec3(0.0);
    float cnt = 0.0;
    for (int i = 0; i < 6; i++) {
        vec4 nl = imageLoad(LPV_SRC, lpvWrap(p + dirs[i]));
        if (nl.a > 0.5 && nl.a < 1.5) continue;          // opak dolgu degeri: yayilmaz
        best = max(best, nl.rgb);
        sum += nl.rgb;
        cnt += 1.0;
    }

    vec4 res;
    if (solid) {
        // Opak blok: kendi emisyonu + komsu havanin ortalamasi (yalnizca trilineer orneklem icin dolgu)
        vec3 fill = (cnt > 0.0) ? sum / cnt : vec3(0.0);
        res = vec4(max(own, fill * 0.80), emitter ? 2.0 : 1.0);
    } else {
        float Ib = max(best.r, max(best.g, best.b));
        vec3 prop = (Ib > LPV_STEP) ? best * ((Ib - LPV_STEP) / Ib) : vec3(0.0);
        if (op.a > 0.0) {
            // Saydam voksel (cam, su, yaprak): isigi suzmek yerine camin tonuna boyar, siddet korunur.
            // (Saf filtre sicak isigi mavi camdan gecirince soluk gri birakirdi; oyun icin boyama istenir.)
            float Ip = max(prop.r, max(prop.g, prop.b));
            vec3 tn = op.rgb / max(max(op.rgb.r, op.rgb.g), max(op.rgb.b, 1e-3));
            prop = mix(prop * op.rgb, tn * Ip, 0.80);
            // Dogrusal kayip (vanilla: su/yaprak ~1 ek seviye); tinted_glass (op > 0.6) ~7 seviye
            float Ip2 = max(Ip - op.a * 0.20 - (op.a > 0.6 ? op.a * 0.35 : 0.0), 0.0);
            prop *= Ip2 / max(Ip, 1e-4);
        }
        res = vec4(max(own, prop), emitter ? 2.0 : 0.0);
    }
    imageStore(LPV_DST, p, res);
#endif
}
#endif
