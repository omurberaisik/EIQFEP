// =============================================================================
//  EIQFEP - composite: yansimalar (ekran uzayi izleme + gokyuzu yedegi)
//  Su, cam, islak zemin, metal ve parlak yuzeyler. Dusuk seviyede yalnizca gokyuzu.
// =============================================================================
#include "/lib/common.glsl"
#include "/lib/sky.glsl"
#include "/lib/lighting.glsl"

#ifdef VSH
out vec2 texcoord;
flat out vec3 vSunColor;
flat out vec3 vMoonColor;
flat out vec3 vLightDir;
flat out vec3 vLightColor;
flat out vec3 vAmbUp;
flat out vec3 vAmbHor;
flat out vec3 vAmbGround;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    computeAtmoLight(vLightDir, vLightColor, vAmbUp, vAmbHor, vAmbGround);
#if EIQ_DIM == 0
    sunMoonColors(vSunColor, vMoonColor);
#else
    vSunColor = vec3(0.0); vMoonColor = vec3(0.0);
#endif
}
#endif

#ifdef FSH
in vec2 texcoord;
flat in vec3 vSunColor;
flat in vec3 vMoonColor;
flat in vec3 vLightDir;
flat in vec3 vLightColor;
flat in vec3 vAmbUp;
flat in vec3 vAmbHor;
flat in vec3 vAmbGround;
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
layout(location = 0) out vec4 outColor;

// Ekran uzayi izleme. Donus: xy = uv, z = guven (0 = iska)
vec3 traceScreen(vec3 vp, vec3 R, float jit) {
#if SSR_STEPS > 0
    float len = 0.30 + 0.004 * length(vp);
    vec3 p = vp + R * (len * jit);
    vec3 prev = p;
    for (int i = 0; i < SSR_STEPS; i++) {
        prev = p;
        p += R * len;
        len *= 1.20;
        vec3 s = projectView(p);
        if (s.x < 0.0 || s.x > 1.0 || s.y < 0.0 || s.y > 1.0 || s.z > 1.0) return vec3(0.0);
        float sd = texture(depthtex1, s.xy).r;
        if (sd >= 1.0) continue;
        float sz = viewPosFromDepth(s.xy, sd).z;
        float diff = sz - p.z;
        if (diff > 0.0 && diff < len * 2.4 + 0.25) {
            vec3 lo = prev;
            vec3 hi = p;
            for (int b = 0; b < 5; b++) {
                vec3 mid = 0.5 * (lo + hi);
                vec3 ms = projectView(mid);
                float mz = viewPosFromDepth(ms.xy, texture(depthtex1, ms.xy).r).z;
                if (mz - mid.z > 0.0) hi = mid; else lo = mid;
            }
            vec3 hs = projectView(hi);
            float edge = min(min(hs.x, 1.0 - hs.x), min(hs.y, 1.0 - hs.y));
            return vec3(hs.xy, smoothstep(0.0, 0.12, edge));
        }
    }
#endif
    return vec3(0.0);
}

void main() {
    vec3 color = texture(colortex0, texcoord).rgb;
    float depth = texture(depthtex0, texcoord).r;
    vec4 gm = texture(colortex2, texcoord);
    float sm = gm.r;
    if (depth >= 1.0 || gm.a > 0.99 || sm < 0.30 || isEyeInWater != 0) {
        outColor = vec4(color, 1.0);
        return;
    }

    vec4 g1 = texture(colortex1, texcoord);
    vec3 N = octDecode(g1.xy);
    vec2 lm = g1.zw;
    vec3 vp = viewPosFromDepth(texcoord, depth);
    vec3 V = normalize(vp);
    float NoV = saturate(dot(N, -V));

    float f0 = gm.g;
    vec3 F0 = (f0 >= 0.9) ? clamp(color / max(luma(color), 1e-3) * 0.85, 0.0, 1.0) : vec3(f0);
    vec3 F = F0 + (1.0 - F0) * pow(1.0 - NoV, 5.0);
    F = min(F, vec3(0.96));
    float roughness = sq(1.0 - sm);

    vec4 bn = blueNoise4(gl_FragCoord.xy);
    float n1 = bn.x;
    float n2 = bn.y;

    // Pürüzlülüğe göre yansima yonunu sapit (TAA ile birikir)
    vec3 R = reflect(V, N);
    vec2 d2 = vogel(int(n2 * 8.0), 8, n1) * roughness * 0.55;
    vec3 T = normalize(cross(N, abs(N.y) < 0.99 ? vec3(0, 1, 0) : vec3(1, 0, 0)));
    vec3 Bt = cross(N, T);
    R = normalize(R + T * d2.x + Bt * d2.y);
    if (dot(R, N) < 0.02) R = normalize(R + N * (0.02 - dot(R, N)));

    vec3 hit = traceScreen(vp, R, n1);
    vec3 Rw = normalize(mat3(gbufferModelViewInverse) * R);
    float skyVis = smoothstep(0.05, 0.85, lm.y);
#if EIQ_DIM == -1
    skyVis = 0.7;
#endif
#if EIQ_DIM == 1
    skyVis = 1.0;                      // End'de gokyuzu isigi seviyesi yok: acik bosluk kabul edilir
#endif
    vec3 skyCol = renderSkyReflection(Rw, vSunColor, vMoonColor) * skyVis;
    vec3 refl = skyCol;
#if RT_REFL_ON
    // Ekran uzayi kacirdiysa voksel isin izleme: ekran disi / perdelenmis cisimleri de yansitir.
    // (blok cozunurlugunde, ~64 blok menzil; menzil disinda gokyuzu)
    if (hit.z < 0.5) {
        g_LightDir = vLightDir; g_LightColor = vLightColor;
        g_AmbUp = vAmbUp; g_AmbHor = vAmbHor; g_AmbGround = vAmbGround;
        vec3 posRel = viewToPlayer(vp);
        vec3 Nw = normalize(mat3(gbufferModelViewInverse) * N);
        RtHit rh = rtTrace(posRel + Nw * 0.05, Rw, 0.0, 96.0, 160);
        if (rh.hit) {
            float skyProxy = pow(saturate(lm.y), 2.0) * 0.8 + (EIQ_DIM != 0 ? 0.8 : 0.0);
            vec3 hc = rtRadiance(rh, saturate(skyProxy)) * rh.trans;
            float edgeFade = 1.0 - smoothstep(60.0, 96.0, rh.t);       // menzil sonunda gokyuzune karis
            refl = mix(skyCol * luma(rh.trans), hc, edgeFade);
        } else {
            refl = skyCol * rh.trans;
        }
    }
#endif
    if (hit.z > 0.0) {
        vec3 hc = texture(colortex0, hit.xy).rgb;
        refl = mix(refl, hc, hit.z);
    }
    // Kaba yuzeylerde yansima zayiflar
    float w = smoothstep(0.30, 0.80, sm);
    vec3 outc = mix(color, refl, F * w);
    outColor = vec4(outc, 1.0);
}
#endif
