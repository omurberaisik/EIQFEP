// =============================================================================
//  EIQFEP - composite: su kirilmasi, kanal basina sogurma, kaustik, kopuk
//  colortex6 = su katmani (rgb sacilma rengi, a kapsama). Arka plan normale gore kaydirilir.
// =============================================================================
#include "/lib/common.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/water.glsl"

#ifdef VSH
out vec2 texcoord;
flat out vec3 vLightDir;
flat out vec3 vLightColor;
void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    vec3 u0, u1, u2;
    computeAtmoLight(vLightDir, vLightColor, u0, u1, u2);
}
#endif

#ifdef FSH
in vec2 texcoord;
flat in vec3 vLightDir;
flat in vec3 vLightColor;
uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex6;
layout(location = 0) out vec4 outColor;

void main() {
    vec3 color = texture(colortex0, texcoord).rgb;
    vec4 w = texture(colortex6, texcoord);
    if (w.a < 0.5 || isEyeInWater != 0) { outColor = vec4(color, 1.0); return; }

    float d0 = texture(depthtex0, texcoord).r;
    float d1 = texture(depthtex1, texcoord).r;
    vec3 vp0 = viewPosFromDepth(texcoord, d0);
    vec3 vp1 = viewPosFromDepth(texcoord, d1 >= 1.0 ? 0.9999 : d1);
    float thick = (d1 >= 1.0) ? 80.0 : distance(vp1, vp0);

    vec4 g1 = texture(colortex1, texcoord);
    float foam = texture(colortex2, texcoord).b;
    vec3 N = octDecode(g1.xy);

    // ---- kirilma: normalin duz su normalinden sapmasi kadar kaydir
    vec2 uv2 = texcoord;
#if SSR_STEPS > 0 || EIQ_LEVEL >= 2
    vec3 Nflat = normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));
    vec2 off = (N.xy - Nflat.xy) * 0.050 * min(thick, 4.0) / (1.0 + 0.05 * length(vp0));
    off.x *= viewHeight / viewWidth;
    uv2 = clamp(texcoord + off, vec2(0.002), vec2(0.998));
    float dd = texture(depthtex1, uv2).r;
    if (dd + 1e-5 < d0) uv2 = texcoord;           // on plandaki cisim: gecersiz ornek
#endif
    float d1b = texture(depthtex1, uv2).r;
    vec3 vp1b = viewPosFromDepth(uv2, d1b >= 1.0 ? 0.9999 : d1b);
    float thick2 = (d1b >= 1.0) ? 80.0 : max(distance(vp1b, vp0), 0.0);

    vec3 bg = texture(colortex0, uv2).rgb;

    // ---- kaustik: sudaki yuzeyleri gunesle canlandir
#if EIQ_LEVEL >= 3
    if (d1b < 1.0 && dot(vLightColor, vec3(1.0)) > 1e-3) {
        vec3 wp = viewToPlayer(vp1b) + cameraPosition;
        float sunK = saturate(luma(vLightColor) / (SUN_S * 0.55)) * saturate(vLightDir.y * 2.5);
        float fade = exp(-thick2 * 0.18);
        bg *= mix(1.0, causticFactor(wp, sunK), fade);
    }
#endif

    vec3 T = exp(-WATER_ABSORB * thick2) * (1.0 - foam);
    color = bg * T + w.rgb * (vec3(1.0) - T);
    outColor = vec4(color, 1.0);
}
#endif
