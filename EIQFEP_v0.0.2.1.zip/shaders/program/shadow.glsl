#define SHADOW_STAGE
#include "/lib/common.glsl"
#include "/lib/wind.glsl"
#include "/lib/lpv.glsl"

const float SHADOW_DISTORT = 0.85;
const float SHADOW_Z_SCALE = 0.2;
vec2 shadowDistortS(vec2 p) { return p / ((1.0 - SHADOW_DISTORT) + length(p) * SHADOW_DISTORT); }

#ifdef VSH
in vec4 mc_Entity;
in vec4 at_midBlock;
in vec2 mc_midTexCoord;
uniform sampler2D gtexture;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
out vec2 texcoord;
out vec4 vcolor;
flat out int idV;
void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vcolor = gl_Color;
    int id = int(mc_Entity.x + 0.5);
    idV = id;
    vec4 vpos = gl_ModelViewMatrix * gl_Vertex;
    vec3 playerPos = (shadowModelViewInverse * vpos).xyz;
#if LPV_ACTIVE
    // Blok ortalama rengi: dokunun orta noktasindan yuksek mip (ortalama), biyom tonu ile carpilir
    vec3 voxAlbedo = textureLod(gtexture, mc_midTexCoord, 3.0).rgb * gl_Color.rgb;
    lpvVoxelize(id, playerPos, at_midBlock.xyz, voxAlbedo);     // ruzgar oncesi (gercek blok konumu)
#endif
    playerPos = applyWind(playerPos, id, blockHeightFromMid(at_midBlock.y));
    gl_Position = gl_ProjectionMatrix * (shadowModelView * vec4(playerPos, 1.0));
    gl_Position.xy = shadowDistortS(gl_Position.xy);
    gl_Position.z *= SHADOW_Z_SCALE;
}
#endif

#ifdef FSH
in vec2 texcoord;
in vec4 vcolor;
flat in int idV;
uniform sampler2D gtexture;
layout(location = 0) out vec4 outColor;
void main() {
    vec4 c = texture(gtexture, texcoord) * vcolor;
    if (c.a < 0.1) discard;
    vec3 rgb = srgbToLinear(c.rgb);
    float a = c.a;
    if (idV == ID_WATER) { rgb = vec3(0.10, 0.36, 0.52); a = 0.50; }
    outColor = vec4(rgb, a);
}
#endif
