// =============================================================================
//  EIQFEP - composite2: TAA (seviye 3+) veya kenar duyarli yumusatma (seviye 1-2)
//  TAA: kamera hareketine gore yeniden projeksiyon + komsuluk kenetleme (varyans kirpma)
// =============================================================================
#include "/lib/common.glsl"

#ifdef VSH
out vec2 texcoord;
void main() { gl_Position = ftransform(); texcoord = gl_MultiTexCoord0.xy; }
#endif

#ifdef FSH
in vec2 texcoord;
uniform sampler2D colortex0;
uniform sampler2D colortex3;
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outHist;

// Karis agirliklandirmasi: HDR parlamalarinin TAA'yi bozmasini onler
vec3 toWork(vec3 c)   { return c / (1.0 + luma(c)); }
vec3 fromWork(vec3 c) { return c / max(1.0 - luma(c), 1e-3); }

// Catmull-Rom (5 ornek, dogrusal filtre hilesi): gecmis bulanikligini azaltir (Jimenez / Karis)
vec3 sampleHistoryCR(vec2 uv) {
    vec2 sz = vec2(viewWidth, viewHeight);
    vec2 pos = uv * sz;
    vec2 c = floor(pos - 0.5) + 0.5;
    vec2 f = pos - c;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 w12 = w1 + w2;
    vec2 t0 = (c - 1.0) / sz, t3 = (c + 2.0) / sz;
    vec2 t12 = (c + w2 / w12) / sz;
    vec3 r = vec3(0.0);
    r += texture(colortex3, vec2(t12.x, t0.y)).rgb  * (w12.x * w0.y);
    r += texture(colortex3, vec2(t0.x, t12.y)).rgb  * (w0.x * w12.y);
    r += texture(colortex3, vec2(t12.x, t12.y)).rgb * (w12.x * w12.y);
    r += texture(colortex3, vec2(t3.x, t12.y)).rgb  * (w3.x * w12.y);
    r += texture(colortex3, vec2(t12.x, t3.y)).rgb  * (w12.x * w3.y);
    float wsum = (w12.x * w0.y) + (w0.x * w12.y) + (w12.x * w12.y) + (w3.x * w12.y) + (w12.x * w3.y);
    return max(r / wsum, vec3(0.0));
}

#if USE_TAA
void main() {
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    vec3 cur = texture(colortex0, texcoord).rgb;
    if (any(isnan(cur)) || any(isinf(cur))) cur = vec3(0.0);        // NaN/Inf gecmise yayilmasin
    float depth = texture(depthtex1, texcoord).r;

    // Komsuluk istatistigi (3x3)
    vec3 m1 = vec3(0.0), m2 = vec3(0.0);
    vec3 cmin = vec3(1e9), cmax = vec3(-1e9);
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec3 c = toWork(texture(colortex0, texcoord + vec2(x, y) * px).rgb);
            m1 += c; m2 += c * c;
            cmin = min(cmin, c); cmax = max(cmax, c);
        }
    }
    m1 /= 9.0; m2 /= 9.0;
    vec3 sigma = sqrt(max(m2 - m1 * m1, vec3(0.0)));

    // Yeniden projeksiyon
    // Yeniden projeksiyon piksel merkezinden yapilir (jitter cikarilirsa statik sahne bulaniklasir)
    vec2 uvU = texcoord;
    vec2 prevUV;
    bool hand = depth < 0.56;
    if (hand) {
        prevUV = texcoord;
    } else if (depth >= 1.0) {
        vec3 vpS = viewPosFromDepth(uvU, 1.0);
        vec3 dirW = mat3(gbufferModelViewInverse) * normalize(vpS);
        vec3 pv = mat3(gbufferPreviousModelView) * dirW * 100.0;
        vec4 pc = gbufferPreviousProjection * vec4(pv, 1.0);
        prevUV = pc.xy / pc.w * 0.5 + 0.5;
    } else {
        vec3 vp = viewPosFromDepth(uvU, depth);
        vec3 world = viewToPlayer(vp) + cameraPosition;
        vec3 pPlayer = world - previousCameraPosition;
        vec3 pv = (gbufferPreviousModelView * vec4(pPlayer, 1.0)).xyz;
        vec4 pc = gbufferPreviousProjection * vec4(pv, 1.0);
        prevUV = pc.xy / pc.w * 0.5 + 0.5;
    }

    vec3 outC;
    float histValid = (prevUV.x > 0.0 && prevUV.x < 1.0 && prevUV.y > 0.0 && prevUV.y < 1.0) ? 1.0 : 0.0;
    if (histValid < 0.5) {
        outC = cur;
    } else {
#if TAA_CATMULL
        vec3 hist = toWork(sampleHistoryCR(prevUV));
#else
        vec3 hist = toWork(texture(colortex3, prevUV).rgb);
#endif
        if (any(isnan(hist))) hist = toWork(cur);
        // Komsuluk min/max kutusuna kirp (merkez piksel her zaman kutunun icinde: keskinlik korunur,
        // hayalet iz ise kutu disina cikan gecmisin merkeze cekilmesiyle bastirilir)
#if TAA_CLIP
        // Varyans kutusu (ort. +- 1.25 sigma) ile min/max kutusunun kesisimi: hayaleti daha sert keser, keskinligi korur
        vec3 lo = max(cmin, m1 - TAA_VAR_GAMMA * sigma);
        vec3 hi = min(cmax, m1 + TAA_VAR_GAMMA * sigma);
        lo = min(lo, m1); hi = max(hi, m1);
        vec3 center = 0.5 * (lo + hi);
        vec3 ext = max(0.5 * (hi - lo), vec3(1e-4));
        vec3 v = hist - center;
        vec3 a = abs(v / ext);
        float mx = max(a.x, max(a.y, a.z));
        if (mx > 1.0) hist = center + v / mx;
#endif

        // Hareket arttikca yeni kareye daha cok guven
        vec2 vel = (texcoord - prevUV) / px;
        float speed = length(vel);
        float alpha = mix(TAA_ALPHA_MIN, TAA_ALPHA_MAX, saturate(speed / 8.0));
        if (hand) alpha = max(alpha, 0.25);
        vec3 res = mix(hist, toWork(cur), alpha);
        outC = fromWork(res);
    }
    outColor = vec4(outC, 1.0);
    outHist = vec4(outC, 1.0);
}
#else
// Kenar duyarli yumusatma: gradyan yonune dik dogrultuda 5 ornek
float edgeLuma(vec2 uv) {
    vec3 c = texture(colortex0, uv).rgb;
    return sqrt(luma(c) / (1.0 + luma(c)) + 1e-4);
}
void main() {
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    vec3 cur = texture(colortex0, texcoord).rgb;
    float lC = edgeLuma(texcoord);
    float lN = edgeLuma(texcoord + vec2(0.0, px.y));
    float lS = edgeLuma(texcoord - vec2(0.0, px.y));
    float lE = edgeLuma(texcoord + vec2(px.x, 0.0));
    float lW = edgeLuma(texcoord - vec2(px.x, 0.0));
    float lmax = max(lC, max(max(lN, lS), max(lE, lW)));
    float lmin = min(lC, min(min(lN, lS), min(lE, lW)));
    float contrast = lmax - lmin;
    vec3 res = cur;
    if (contrast > max(0.045, lmax * 0.12)) {
        float gx = (lE - lW);
        float gy = (lN - lS);
        vec2 tang = normalize(vec2(-gy, gx) + vec2(1e-5));
        vec3 acc = cur * 3.0;
        acc += texture(colortex0, texcoord + tang * px * 0.5).rgb * 2.0;
        acc += texture(colortex0, texcoord - tang * px * 0.5).rgb * 2.0;
        acc += texture(colortex0, texcoord + tang * px * 1.5).rgb;
        acc += texture(colortex0, texcoord - tang * px * 1.5).rgb;
        float w = saturate((contrast - 0.045) * 6.0) * 0.85;
        res = mix(cur, acc / 9.0, w);
    }
    outColor = vec4(res, 1.0);
    outHist = vec4(res, 1.0);
}
#endif
#endif
