#version 330 compatibility
#define EIQ_DIM -1
#define FSH
/* RENDERTARGETS: 4 */
#include "/program/bloom.glsl"
