#version 330 compatibility
#define EIQ_DIM -1
#define FSH
#define PASS_TEXTURED_LIT
/* RENDERTARGETS: 0,1,2 */
#include "/program/gbuffers.glsl"
