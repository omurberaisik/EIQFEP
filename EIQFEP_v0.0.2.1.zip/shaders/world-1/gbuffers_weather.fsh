#version 330 compatibility
#define EIQ_DIM -1
#define FSH
#define PASS_WEATHER
/* RENDERTARGETS: 0 */
#include "/program/gbuffers.glsl"
