#version 330 compatibility
#define EIQ_DIM -1
#define VSH
#define PASS_WEATHER
#include "/program/gbuffers.glsl"
