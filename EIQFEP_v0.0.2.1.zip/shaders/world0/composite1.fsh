#version 330 compatibility
#define EIQ_DIM 0
#define FSH
/* RENDERTARGETS: 0 */
#include "/program/reflect.glsl"
