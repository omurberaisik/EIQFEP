#version 330 compatibility
#define EIQ_DIM 0
#define FSH
/* RENDERTARGETS: 4 */
#include "/program/bloom.glsl"
