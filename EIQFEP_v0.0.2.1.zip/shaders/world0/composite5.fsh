#version 330 compatibility
#define EIQ_DIM 0
#define FSH
/* RENDERTARGETS: 5 */
#include "/program/exposure.glsl"
