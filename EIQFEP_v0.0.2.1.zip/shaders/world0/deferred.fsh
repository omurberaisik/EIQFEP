#version 330 compatibility
#define EIQ_DIM 0
#define FSH
/* RENDERTARGETS: 0,7,8 */
#include "/program/deferred.glsl"
