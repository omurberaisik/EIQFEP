#version 330 compatibility
#define EIQ_DIM 0
#define VSH
#include "/program/deferred.glsl"
