#version 330 compatibility
#define EIQ_DIM 0
#define DH_WATER
#define VSH
#include "/program/dh.glsl"
