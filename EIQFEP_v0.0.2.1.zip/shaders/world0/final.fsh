#version 330 compatibility
#define EIQ_DIM 0
#define FSH
#include "/program/final.glsl"
