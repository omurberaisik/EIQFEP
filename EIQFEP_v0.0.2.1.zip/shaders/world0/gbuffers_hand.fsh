#version 330 compatibility
#define EIQ_DIM 0
#define FSH
#define PASS_HAND
/* RENDERTARGETS: 0,1,2 */
#include "/program/gbuffers.glsl"
