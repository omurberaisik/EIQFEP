#version 330 compatibility
#define EIQ_DIM 0
#define VSH
#define PASS_HAND
#include "/program/gbuffers.glsl"
