#version 330 compatibility
#define EIQ_DIM 0
#define VSH
#define PASS_TERRAIN
#include "/program/gbuffers.glsl"
