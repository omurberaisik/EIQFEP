#version 330 compatibility
#define EIQ_DIM 0
#define VSH
#define PASS_TEXTURED_LIT
#include "/program/gbuffers.glsl"
