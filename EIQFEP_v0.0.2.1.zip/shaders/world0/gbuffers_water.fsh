#version 330 compatibility
#define EIQ_DIM 0
#define FSH
#define PASS_WATER
/* RENDERTARGETS: 0,1,2,6 */
#include "/program/gbuffers.glsl"
