#version 330 compatibility
#define EIQ_DIM 0
#define FSH
#define PASS_WEATHER
/* RENDERTARGETS: 0 */
#include "/program/gbuffers.glsl"
