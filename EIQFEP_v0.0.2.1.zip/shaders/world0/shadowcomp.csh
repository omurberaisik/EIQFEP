#version 430 compatibility
#extension GL_ARB_shader_image_load_store : enable
#extension GL_EXT_shader_image_load_formatted : enable
#define EIQ_DIM 0
#define CSH
#define LPV_PASS 0
#include "/program/lpv.glsl"
