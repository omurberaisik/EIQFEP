#version 330 compatibility
#define EIQ_DIM 1
#define FSH
/* RENDERTARGETS: 0,3 */
#include "/program/taa.glsl"
