#version 330 compatibility
#define EIQ_DIM 1
#define FSH
/* RENDERTARGETS: 5 */
#include "/program/exposure.glsl"
