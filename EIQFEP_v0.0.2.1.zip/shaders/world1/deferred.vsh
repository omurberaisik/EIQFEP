#version 330 compatibility
#define EIQ_DIM 1
#define VSH
#include "/program/deferred.glsl"
