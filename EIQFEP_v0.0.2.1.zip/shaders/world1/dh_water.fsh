#version 330 compatibility
#define EIQ_DIM 1
#define DH_WATER
#define FSH
/* RENDERTARGETS: 0,1,2 */
#include "/program/dh.glsl"
