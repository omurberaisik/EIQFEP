#version 330 compatibility
#define EIQ_DIM 1
#define DH_WATER
#define VSH
#include "/program/dh.glsl"
