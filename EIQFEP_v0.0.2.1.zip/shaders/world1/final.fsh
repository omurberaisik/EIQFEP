#version 330 compatibility
#define EIQ_DIM 1
#define FSH
#include "/program/final.glsl"
