#version 330 compatibility
#extension GL_ARB_shader_image_load_store : enable
#extension GL_EXT_shader_image_load_formatted : enable
#define EIQ_DIM 1
#define FSH
#include "/program/shadow.glsl"
