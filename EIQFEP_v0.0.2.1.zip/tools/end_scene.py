import os as _os
OUTD=_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),'..','out'); _os.makedirs(OUTD,exist_ok=True)
import os,sys; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from rtharness import *
from PIL import Image
level=5   # test ray tracing kullanir: yalnizca seviye 5
yaw=float(sys.argv[2]) if len(sys.argv)>2 else 0.0
def scene(X,Y,Z):
    rgb=np.ones(X.shape+(3,),np.float32)*0.6; a=np.zeros(X.shape,np.float32)
    r=np.sqrt(X**2+Z**2)
    isl=(Y<=-3)&(Y>=-3-np.maximum(0,(38-r)*0.35))&(r<38); a[isl]=1; rgb[isl]=(0.86,0.82,0.58)
    for (px,pz,h) in ((10,6,14),(-9,12,18),(14,-10,10),(-14,-6,12)):
        p=(np.abs(X-px)<=1)&(np.abs(Z-pz)<=1)&(Y>=-3)&(Y<=-3+h); a[p]=1; rgb[p]=(0.10,0.06,0.16)
    return rgb,a,[]
geo,idx,_=build_scene(scene)
h=H(); ctx=h.ctx
g3=h.tex3(geo,4,'f1'); b3=h.tex3(bricks(geo),4,'f1'); l3=h.tex3(np.zeros(DIMS+(4,),np.float32),4,'f4')
dummy=ctx.texture((1,1),4,np.array([1,1,1,1],'f4').tobytes(),dtype='f4')
BODY='''#define EIQ_DIM 1
#define FSH
#define EIQ_DEFERRED
#include "/lib/sky.glsl"
#include "/lib/lighting.glsl"
#include "/lib/atmofx.glsl"
#include "/lib/color.glsl"
uniform vec3 camF; uniform vec3 camR; uniform vec3 camU; uniform float expo; uniform vec2 res;
in vec2 uv; out vec4 o;
void main(){
  vec2 p=(gl_FragCoord.xy/res*2.0-1.0)*vec2(res.x/res.y,1.0)*0.75;
  vec3 rd=normalize(camF+camR*p.x+camU*p.y);
  vec3 Ld,Lc,aU,aH,aG; computeAtmoLight(Ld,Lc,aU,aH,aG);
  g_LightDir=Ld; g_LightColor=Lc; g_AmbUp=aU; g_AmbHor=aH; g_AmbGround=aG;
  vec4 bn=blueNoise4(gl_FragCoord.xy);
  RtHit h=rtTrace(vec3(0.0),rd,0.0,200.0,400);
  vec3 col; float dist;
  if(!h.hit){ col=endSkyFull(rd,bn.z); dist=400.0; }
  else {
    vec3 N=h.N; vec3 pr=h.posRel; dist=h.t;
    vec3 sh=vec3(1.0);
    RtHit sx=rtTrace(pr+N*0.05,Ld,0.0,60.0,160); sh=sx.hit?vec3(0.0):vec3(1.0);
    rtGI(pr,N,1.0,bn);
    float gl=0.0;
    col=shadeSurface(h.albedo,N,-rd,pr,vec2(0.0,1.0),1.0,0.1,0.04,0.0,0.0,sh,0.0,vec3(1.0));
  }
  if(h.hit) col=endFog(col,rd,dist,bn.w,Ld,Lc);
#if MOTE_STEPS > 0
  col+=motes(rd,h.hit?min(dist,60.0):60.0,bn.x,false,0.16,vec4(0.0));
#endif
  col=tonemapEIQ(col*expo);
  o=vec4(col,1.0);
}'''
prog=ctx.program(vertex_shader=VS,fragment_shader=frag(BODY,level))
for n in ('shadowtex0','shadowtex1','shadowcolor0','noisetex','depthtex0','depthtex1'):
    if n in prog: prog[n]=3
dummy.use(3); g3.use(0);b3.use(1);l3.use(2)
for n,u in (('rtGeoTex',0),('rtBrickTex',1),('lpvTexA',2)):
    if n in prog: prog[n]=u
W,Hh=960,540
fbo=ctx.framebuffer(ctx.texture((W,Hh),4,dtype='f4')); fbo.use()
E=np.array([0.60,0.66,-0.45]); E/=np.linalg.norm(E)
prog['shadowLightPosition']=tuple(E*100); prog['gbufferModelViewInverse']=tuple(np.eye(4).T.flatten())
prog['cameraPosition']=tuple(BASE+np.array([0.5,0.5,0.5])+np.array([0,float(sys.argv[5]) if len(sys.argv)>5 else 0,0]))
prog['res']=(W,Hh); prog['expo']=float(sys.argv[3]) if len(sys.argv)>3 else 0.9; prog['frameTimeCounter']=30.0
if 'gbufferProjection' in prog: prog['gbufferProjection']=(1.3,0,0,0, 0,1.3,0,0, 0,0,-1,-1, 0,0,-0.2,0)
if 'viewHeight' in prog: prog['viewHeight']=float(Hh)
pit=float(sys.argv[4]) if len(sys.argv)>4 else -0.05
F=np.array([np.sin(yaw),pit,-np.cos(yaw)]);F/=np.linalg.norm(F);R=np.cross(F,[0,1,0]);R/=np.linalg.norm(R);U=np.cross(R,F)
prog['camF']=tuple(F);prog['camR']=tuple(R);prog['camU']=tuple(U)
vao=ctx.simple_vertex_array(prog,h.vbo,'p'); acc=np.zeros((Hh,W,4),np.float32); N=16
for f in range(N):
    if 'frameCounter' in prog: prog['frameCounter']=f
    fbo.clear(); vao.render(moderngl.TRIANGLE_STRIP)
    acc+=np.frombuffer(fbo.read(components=4,dtype='f4'),'f4').reshape(Hh,W,4)
img=(np.clip(acc[...,:3]/N,0,1)**(1/2.2)*255).astype(np.uint8)[::-1]
Image.fromarray(img).save(f'{OUTD}/endscene_L{level}_y{int(yaw*10)}.png'); print('ok')
