import os as _os
OUTD=_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),'..','out'); _os.makedirs(OUTD,exist_ok=True)
import os,sys; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from rtharness import *
from PIL import Image
W,Hh=640,360
yy,xx=np.mgrid[0:Hh,0:W]
depth=np.ones((Hh,W),np.float32)
# ground + trees (silhouettes)
depth[yy>270]=0.5
rng=np.random.default_rng(3)
for cx in range(20,W,38):
    h=rng.integers(80,170); w=rng.integers(8,18)
    depth[(abs(xx-cx)<w)&(yy>270-h)]=0.5
    r=rng.integers(25,45); depth[((xx-cx)**2+(yy-(270-h))**2)<r*r]=0.5
# cloud transmittance: gaps pattern
cl=np.ones((Hh,W,4),np.float32)
cl[...,3]=np.clip(0.35+0.65*(np.sin(xx*0.05)*np.sin(yy*0.07+1)>0.2),0,1)
BODY='''#define EIQ_DIM 0
#define FSH
#include "/lib/atmofx.glsl"
uniform vec3 Ld; uniform vec2 res; in vec2 uv; out vec4 o;
void main(){
  vec2 u=gl_FragCoord.xy/res;
  vec3 rd=normalize(vec3((u*2.0-1.0)*vec2(res.x/res.y,1.0)*0.6,-1.0));
  vec3 g=godRays(u,Ld,vec3(4.0,3.3,2.4),dot(rd,Ld),0.5)*0.25;
  float d=texture(depthtex0,u).r;
  vec3 base=(d<1.0)?vec3(0.02):vec3(0.5,0.65,0.9)*0.4*texture(colortex8,u).a+vec3(0.15);
  o=vec4(base+g,1.0);
}'''
h=H(); ctx=h.ctx
prog=ctx.program(vertex_shader=VS,fragment_shader=frag(BODY,5))
dt=ctx.texture((W,Hh),1,depth.tobytes(),dtype='f4'); ct=ctx.texture((W,Hh),4,cl.tobytes(),dtype='f4')
for t in (dt,ct): t.filter=(moderngl.LINEAR,moderngl.LINEAR); t.repeat_x=t.repeat_y=False
dt.use(0); ct.use(1); prog['depthtex0']=0; prog['colortex8']=1; prog['res']=(W,Hh)
if 'gbufferModelView' in prog: prog['gbufferModelView']=tuple(np.eye(4).T.flatten())
# projection for the same fov: x scale 1/(0.6*aspect)
a=W/Hh; P=np.array([[1/(0.6*a),0,0,0],[0,1/0.6,0,0],[0,0,-1.002,-0.2],[0,0,-1,0]],np.float32)
prog['gbufferProjection']=tuple(P.T.flatten())
L=np.array([0.25,0.18,-1.0]);L/=np.linalg.norm(L); prog['Ld']=tuple(L)
fbo=ctx.framebuffer(ctx.texture((W,Hh),4,dtype='f4')); fbo.use()
vao=ctx.simple_vertex_array(prog,h.vbo,'p'); vao.render(moderngl.TRIANGLE_STRIP)
d=np.frombuffer(fbo.read(components=4,dtype='f4'),'f4').reshape(Hh,W,4)[...,:3]
Image.fromarray((np.clip(d/(1+d),0,1)**(1/2.2)*255).astype(np.uint8)[::-1]).save(OUTD+'/godrays.png'); print('ok')
