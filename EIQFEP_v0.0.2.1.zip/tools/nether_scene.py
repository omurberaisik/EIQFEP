import os as _os
OUTD=_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),'..','out'); _os.makedirs(OUTD,exist_ok=True)
import os,sys; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from rtharness import *
from PIL import Image
# kullanim: nether_scene.py <seviye> <yaw> <expo> <pitch> <biyom: red|soul|warp|basalt> <ad>
level=int(sys.argv[1]) if len(sys.argv)>1 else 5
yaw=float(sys.argv[2]) if len(sys.argv)>2 else 0.0
expo=float(sys.argv[3]) if len(sys.argv)>3 else 1.4
pit=float(sys.argv[4]) if len(sys.argv)>4 else -0.05
bio=sys.argv[5] if len(sys.argv)>5 else 'red'
name=sys.argv[6] if len(sys.argv)>6 else 'a'
FOG={'red':(0.2,0.031,0.031),'soul':(0.106,0.278,0.271),'warp':(0.102,0.02,0.102),'basalt':(0.408,0.373,0.439)}[bio]
emit=[]
def sto(x,y,z): return tuple(int(v) for v in ((np.array([x,y,z])+BASE)%np.array(DIMS)))
def scene(X,Y,Z):
    rgb=np.ones(X.shape+(3,),np.float32)*0.5; a=np.zeros(X.shape,np.float32)
    rock=(0.42,0.17,0.15) if bio!='soul' else (0.30,0.24,0.20)
    ceil=(Y>=22)&(Y<26); a[ceil]=1; rgb[ceil]=rock
    walls=(np.abs(X)>=30)|(Z>=40); w=walls&(Y>=-8)&(Y<26); a[w]=1; rgb[w]=rock
    floor=(Y<=-4)&(Y>-8); a[floor]=1; rgb[floor]=rock
    # lav golu (Z>6)
    lava=(Y<=-3)&(Y>=-4)&(Z>6)&(np.abs(X)<30)&(Z<40); a[lava]=1; rgb[lava]=(0.95,0.42,0.10)
    # ledge + sutunlar
    led=(Y<=-3)&(Y>=-4)&(Z<=6); a[led]=1; rgb[led]=rock
    for (px,pz,h) in ((8,14,16),(-12,22,20),(16,28,12),(-4,10,9)):
        p=(np.abs(X-px)<=2)&(np.abs(Z-pz)<=2)&(Y>=-3)&(Y<=-3+h); a[p]=1; rgb[p]=rock
    # tavandan sarkan parlaktas
    for (gx,gz) in ((-6,18),(10,24),(0,32)):
        g=(np.abs(X-gx)<=2)&(np.abs(Z-gz)<=2)&(Y>=17)&(Y<22); a[g]=1; rgb[g]=(1.0,0.82,0.45)
        emit.append((sto(gx,19,gz),(1.0,0.84,0.42),15))
    # lav yuzeyi yayici (seyrek orneklenir)
    for x in range(-28,29,1):
        for z in range(8,40,1): emit.append((sto(x,-3,z),(1.0,0.42,0.10),15))
    return rgb,a,[]
geo,idx,_=build_scene(scene)
for p,c,l in emit: geo[p]=(255,215,110,255) if c[1]>0.7 else (240,110,25,255)
lpv=flood(geo,idx,emit)
h=H(); ctx=h.ctx
g3=h.tex3(geo,4,'f1'); b3=h.tex3(bricks(geo),4,'f1'); l3=h.tex3(lpv,4,'f4')
dummy=ctx.texture((1,1),4,np.array([1,1,1,1],'f4').tobytes(),dtype='f4')
BODY='''#define EIQ_DIM -1
#define FSH
#define EIQ_DEFERRED
#include "/lib/sky.glsl"
#include "/lib/lighting.glsl"
#include "/lib/netherfog.glsl"
#include "/lib/atmofx.glsl"
#include "/lib/color.glsl"
uniform vec3 camF; uniform vec3 camR; uniform vec3 camU; uniform float expo; uniform vec2 res;
in vec2 uv; out vec4 o;
void main(){
  vec2 p=(gl_FragCoord.xy/res*2.0-1.0)*vec2(res.x/res.y,1.0)*0.75;
  vec3 rd=normalize(camF+camR*p.x+camU*p.y);
  vec3 Ld,Lc,aU,aH,aG; computeAtmoLight(Ld,Lc,aU,aH,aG);
  g_LightDir=Ld; g_LightColor=Lc; g_AmbUp=aU; g_AmbHor=aH; g_AmbGround=aG;
  vec4 bn=blueNoise4(gl_FragCoord.xy);
  RtHit h=rtTrace(vec3(0.0),rd,0.0,200.0,400);
  vec3 col; float dist;
  if(!h.hit){ col=netherSkyFull(rd,bn.z); dist=400.0; }
  else {
    vec3 N=h.N; vec3 pr=h.posRel; dist=h.t;
    vec3 sh=vec3(1.0);
    if(dot(Lc,vec3(1.0))>1e-4){ RtHit sx=rtTrace(pr+N*0.05,Ld,0.0,60.0,160); sh=sx.hit?vec3(0.0):vec3(1.0);}
    rtGI(pr,N,1.0,bn);
    float em=0.0; vec3 alb=h.albedo;
    bool isE=rtMax3(h.emit)>0.0;
    col=shadeSurface(alb,N,-rd,pr,vec2(0.0,1.0),1.0,0.1,0.04,isE?1.0:0.0,0.0,sh,0.0,vec3(1.0));
  }
  col=netherFog(col,rd,dist,bn.w);
#if MOTE_STEPS > 0
  col+=motes(rd,h.hit?min(dist,48.0):48.0,bn.x,true,0.12,netherBiome());
#endif
  col=tonemapEIQ(col*expo);
  o=vec4(col,1.0);
}'''
prog=ctx.program(vertex_shader=VS,fragment_shader=frag(BODY,level))
for n in ('shadowtex0','shadowtex1','shadowcolor0','noisetex','depthtex0','depthtex1'):
    if n in prog: prog[n]=3
dummy.use(3); g3.use(0);b3.use(1);l3.use(2)
for n,u in (('rtGeoTex',0),('rtBrickTex',1),('lpvTexA',2)):
    if n in prog: prog[n]=u
W,Hh=960,540
fbo=ctx.framebuffer(ctx.texture((W,Hh),4,dtype='f4')); fbo.use()
E=np.array([0.45,0.40,-0.80]); E/=np.linalg.norm(E)
prog['shadowLightPosition']=tuple(E*100); prog['gbufferModelViewInverse']=tuple(np.eye(4).T.flatten())
prog['cameraPosition']=tuple(BASE+np.array([0.5,0.5,0.5])+np.array([0,2.0,0]))
prog['fogColor']=FOG
prog['res']=(W,Hh); prog['expo']=expo; prog['frameTimeCounter']=30.0
if 'gbufferProjection' in prog: prog['gbufferProjection']=(1.3,0,0,0, 0,1.3,0,0, 0,0,-1,-1, 0,0,-0.2,0)
if 'viewHeight' in prog: prog['viewHeight']=float(Hh)
F=np.array([np.sin(yaw),pit,-np.cos(yaw)]);F/=np.linalg.norm(F);R=np.cross(F,[0,1,0]);R/=np.linalg.norm(R);U=np.cross(R,F)
prog['camF']=tuple(F);prog['camR']=tuple(R);prog['camU']=tuple(U)
vao=ctx.simple_vertex_array(prog,h.vbo,'p'); acc=np.zeros((Hh,W,4),np.float32); N=16
for f in range(N):
    if 'frameCounter' in prog: prog['frameCounter']=f
    fbo.clear(); vao.render(moderngl.TRIANGLE_STRIP)
    acc+=np.frombuffer(fbo.read(components=4,dtype='f4'),'f4').reshape(Hh,W,4)
img=(np.clip(acc[...,:3]/N,0,1)**(1/2.2)*255).astype(np.uint8)[::-1]
Image.fromarray(img).save(f'{OUTD}/nether_{name}_L{level}.png'); print('ok')
