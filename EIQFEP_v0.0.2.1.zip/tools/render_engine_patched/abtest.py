import sys,subprocess,shutil,re,numpy as np
from PIL import Image
S='/tmp/claude-0/-home-claude/c7854418-8617-53bd-8bf5-f7205d524b72/scratchpad'
def variant(name,edits):
    d=f'{S}/pk_{name}'; shutil.rmtree(d,ignore_errors=True); shutil.copytree('/home/claude/work/pack',d)
    for f,a,b in edits:
        s=open(f'{d}/{f}').read(); assert a in s,(f,a); open(f'{d}/{f}','w').write(s.replace(a,b,1))
    out=subprocess.run(['python3','-I','/home/claude/work/profile.py','4','{}',d+'/',f'{S}/img_{name}.png'],capture_output=True,text=True).stdout
    a=np.asarray(Image.open(f'{S}/img_pre_4.png'),float); b=np.asarray(Image.open(f'{S}/img_{name}.png'),float)
    t={l.split()[0]:float(l.split()[1]) for l in out.splitlines()[1:]}
    print(name,'diff %.2f'%abs(a-b).mean(),'deferred',t['deferred'],'gbuf',t['gbuffers'],flush=True)
V={'noRtGate':[('program/deferred.glsl','float rtK = 1.0 - smoothstep(40.0, 64.0, length(posRel));','float rtK = 1.0;')],
   'noContactGate':[('lib/shadows.glsl','if (length(vp) > 32.0) return 1.0;','')],
   'noMegaGate':[('lib/lighting.glsl','&& dot(posRel, posRel) < 72.0 * 72.0','')],
   'noPcssSkip':[('lib/shadows.glsl','    if (shDist < 64.0)\n','')],
   'fullTaps':[('lib/shadows.glsl','int taps = shDist < 40.0 ? SHADOW_TAPS : max(SHADOW_TAPS / 2, 4);','int taps = SHADOW_TAPS;')],
   'noAOadapt':[('lib/ao.glsl','float farK = smoothstep(70.0, 130.0, -vp.z);','float farK = 0.0;'),('lib/ao.glsl','int nSteps = radiusPx < 14.0 ? max(GTAO_STEPS / 2, 3) : GTAO_STEPS;','int nSteps = GTAO_STEPS;')],
   'noNormFade':[('program/gbuffers.glsl','float anK = 1.0 - smoothstep(40.0, 72.0, length(playerPosV));','float anK = 1.0;')]}
for n in sys.argv[1].split(','): variant(n,V[n])
