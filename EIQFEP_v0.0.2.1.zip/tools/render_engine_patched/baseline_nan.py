import sys; sys.path.insert(0,"/home/claude/work")
from sweep_common import *
eng,h=make()
for lvl in (1,2,3,4,5):
    for scn in ('noon','night','dusk','rain'):
        r=run(eng,h,'/home/claude/work/pack/',{}, scn, level=lvl)
        print(lvl,scn,r,flush=True)
