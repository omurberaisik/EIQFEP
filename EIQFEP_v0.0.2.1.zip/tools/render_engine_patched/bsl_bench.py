import json, gc, time, numpy as np
from PIL import Image
import world as Wd, engine as E, video as V, opti_adapter as OA, opti_session as OS
B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); A = Wd.make_atlas()
x,z,_ = V.build_path(h,B); cams = V.camera_track(x,z,h,B)
views = {'arazi': cams[100], 'gokyuzu': dict(cams[180], pitch=0.50), 'su': cams[300]}
sky = dict(sunAngle=0.25)
eng = E.Engine(800,450,A)
pk0 = OA.OptiPack('/home/claude/bsl/shaders'); Wd.set_pack_ids(pk0.block_ids()); eng.upload_mesh(Wd.mesh(B,Sk,BL))
out = {}
for prof in ('MINIMUM','LOW','MEDIUM','HIGH','ULTRA'):
    pk = OA.OptiPack('/home/claude/bsl/shaders', profile=prof)
    t0 = time.time(); s = OS.OptiSession(eng, pk, prof); per = {}
    for vn,cam in views.items():
        for k in range(3): img = s.frame(cam,cam,sky,k)
        s.tm = {}; N=4
        for k in range(N): img = s.frame(cam,cam,sky,3+k)
        per[vn] = {k:v/N*1000 for k,v in s.tm.items()}; s.tm = None
        if vn == 'su': img.save(f'/tmp/bslprof_{prof}.png')
    keys = list(per['arazi'].keys()); avg = {k: float(np.mean([per[v].get(k,0) for v in views])) for k in keys}
    d = pk.directives()
    out[prof] = dict(avg=avg, total=sum(avg.values()), shadow=d['shadow']['resolution'], dist=d['shadow']['distance'],
                     chain=s.deferred + s.composite, on=[m for m in ('SHADOW','AO','TAA','FXAA','LIGHT_SHAFT','REFLECTION','CLOUDS','BLOOM','SHADOW_COLOR','SHADOW_FILTER','WATER_CAUSTICS','SSS') if m in pk.defs])
    print(f'{prof:8s} total {out[prof]["total"]:.0f} ms  shadow {out[prof]["shadow"]} dist {out[prof]["dist"]}  ({time.time()-t0:.0f}s incl. compile)', flush=True)
    s.release(); gc.collect()
json.dump(out, open('/tmp/bslbench.json','w'), indent=1); print('done', flush=True)
