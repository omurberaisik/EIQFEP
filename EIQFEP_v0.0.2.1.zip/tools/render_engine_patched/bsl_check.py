import os, re, subprocess, sys, collections
import opti_adapter as OA, engine as E
GL='/home/claude/tools/npmt/node_modules/glslang-validator-prebuilt-predownloaded/bin/glslangValidator.linux'
profile = sys.argv[1] if len(sys.argv)>1 and sys.argv[1] != '-' else None
P = OA.OptiPack('/home/claude/bsl/shaders', profile=profile)
print('profile:', profile, '| tokens:', P.tokens[:6], '...')
print('macros on:', [m for m in ('SHADOW','AO','TAA','FXAA','LIGHT_SHAFT','MULTICOLORED_BLOCKLIGHT','ADVANCED_MATERIALS','REFLECTION','CLOUDS','DOF','MOTION_BLUR','BLOOM','LENS_FLARE','SHADOW_COLOR','SHADOW_FILTER','WATER_CAUSTICS','SSS','EMISSIVE','STARS','VOXY','DISTANT_HORIZONS') if m in P.defs])
d = P.directives(); print('directives:', d['shadow'], 'sunPathRotation', d['sunPathRotation'], '| mip', sorted(d['mipmap']), '| noclear', sorted(d['noclear']), '| problems', d['problems'][:2], '| hw', d['hw'])
print('deferred chain :', [(n, P.drawbuffers(n)) for n in P.chain('deferred')])
print('composite chain:', [(n, P.drawbuffers(n)) for n in P.chain('composite')])
print('gbuffers_terrain', P.drawbuffers('gbuffers_terrain'), 'water', P.drawbuffers('gbuffers_water'), 'skybasic', P.drawbuffers('gbuffers_skybasic'), 'skytextured', P.drawbuffers('gbuffers_skytextured'), 'clouds', P.drawbuffers('gbuffers_clouds'))
print('custom textures:', P.custom_textures())
ids = P.block_ids(); print('block ids sample:', {k: ids.get(k) for k in ('grass_block','dirt','stone','sand','oak_log','oak_leaves','oak_planks','glass','water','glowstone','lava','short_grass','poppy','netherrack')})
cu = P.custom_uniforms(dict(sunAngle=0.25, blindness=0.0, frameCounter=3, **{'cameraPosition.y':70.0, 'biome':1}))
print('custom uniforms @noon:', {k: round(v,3) for k,v in cu.items() if k in ('timeAngle','shadowFade','timeBrightness','blindFactor','framemod8','isCold')})
# compile every non-DH/voxy program through the transformer + glslang
fails = collections.Counter(); ok = 0; msgs = {}
for f in sorted(os.listdir(f'{P.root}/{P.dimdir}')):
    if not f.endswith(('.fsh','.vsh')) or f.startswith(('dh_','voxy')): continue
    name, ext = f[:-4], f[-3:]
    src = P.source(name, ext); core = OA.to_core(src, ext, E.VS_PRELUDE)
    tmp = f'/tmp/bsl_{name}.{ "vert" if ext=="vsh" else "frag"}'; open(tmp,'w').write(core)
    r = subprocess.run([GL, tmp], capture_output=True, text=True); out = (r.stdout + r.stderr).strip()
    if r.returncode != 0:
        errs = [l for l in out.split('\n') if 'ERROR' in l and 'compilation terminated' not in l]
        key = re.sub(r'^ERROR: [^:]+:\d+: ', '', errs[0]) if errs else out[:80]
        fails[key[:90]] += 1; msgs.setdefault(key[:90], f)
    else: ok += 1
print(f'\nCOMPILE: ok {ok}  fail {sum(fails.values())}')
for k, c in fails.most_common(12): print(f'  {c:3d}x  {k}   (e.g. {msgs[k]})')
