import numpy as np
from PIL import Image
import world as Wd, engine as E, opti_adapter as OA, opti_session as OS
pk = OA.OptiPack('/home/claude/bsl/shaders'); Wd.set_pack_ids(pk.block_ids())
B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); M = Wd.mesh(B,Sk,BL); A = Wd.make_atlas()
eng = E.Engine(480,270,A); eng.upload_mesh(M)
cam = dict(pos=(86.0,float(h[86,6])+14.0,6.0), yaw=0.35, pitch=-0.12, fov=70); sky = dict(sunAngle=0.19)
s = OS.OptiSession(eng, pk, 'bsl'); s.debug = {}
s.frame(cam, cam, sky, 0)
def img(a, gain=1.0): return Image.fromarray((np.clip(a*gain,0,1)**(1/2.2)*255).astype(np.uint8))
tiles = []
for k,v in s.debug.items():
    a = v; print(f'{k:16s} mean rgb = {a.mean((0,1)).round(3)}  max {a.max():.2f}  nan {int(np.isnan(a).sum())}')
    tiles.append(img(a))
W,H = tiles[0].size; n = len(tiles)
sheet = Image.new('RGB',(W*2+4,(H+4)*((n+1)//2)),'white')
for i,t in enumerate(tiles): sheet.paste(t,((i%2)*(W+4),(i//2)*(H+4)))
sheet.save('/tmp/bsl_debug.png'); print('tiles:', list(s.debug.keys()))
