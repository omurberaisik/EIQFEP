import time, numpy as np
import world as Wd, engine as E, opti_adapter as OA, opti_session as OS
pk = OA.OptiPack('/home/claude/bsl/shaders')
Wd.set_pack_ids(pk.block_ids()); print('ids in mesh:', dict(Wd.PACK_ID))
B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); M = Wd.mesh(B,Sk,BL); A = Wd.make_atlas()
eng = E.Engine(480,270,A); eng.upload_mesh(M)
cam = dict(pos=(86.0,float(h[86,6])+14.0,6.0), yaw=0.35, pitch=-0.12, fov=70); sky = dict(sunAngle=0.19)
s = OS.OptiSession(eng, pk, 'bsl')
print('buffers', s.nbuf, '| mip', sorted(s.mip), '| deferred', s.deferred, '| composite', s.composite)
t = time.time()
try:
    for k in range(3): img = s.frame(cam, cam, sky, k)
    print(f'ok {(time.time()-t)/3:.2f}s/frame  mean {np.asarray(img,float).mean():.0f}'); img.save('/tmp/bsl_smoke.png')
except Exception as e:
    print('FAIL', str(e)[:1800])
for l in eng.compile_log: print('COMPILE LOG', l[0], l[2][:1500])
