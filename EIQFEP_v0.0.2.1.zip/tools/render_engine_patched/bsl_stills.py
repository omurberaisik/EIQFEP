import os, time, numpy as np
import world as Wd, engine as E, opti_adapter as OA, opti_session as OS, session2 as S2
ORIG_IDS = {Wd.WATER: 8, Wd.LEAVES: 10, Wd.TALL: 11, Wd.FLOWER: 11, Wd.GLASS: 20, Wd.GLOW: 50, Wd.LAVA: 40}
B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); A = Wd.make_atlas()
eng = E.Engine(960,540,A)
cy = float(h[86,6])+14.0
SC = {'noon':(dict(pos=(86.0,cy,6.0),yaw=0.35,pitch=-0.12,fov=70),dict(sunAngle=0.19)),
      'water':(dict(pos=(100.0,66.0,56.0),yaw=0.10,pitch=-0.07,fov=70),dict(sunAngle=0.36)),
      'sunset':(dict(pos=(86.0,cy,6.0),yaw=-1.15,pitch=-0.02,fov=70),dict(sunAngle=0.455)),
      'night':(dict(pos=(86.0,cy,6.0),yaw=0.35,pitch=-0.12,fov=70),dict(sunAngle=0.80,fog=(0.02,0.03,0.07)))}
pk = OA.OptiPack('/home/claude/bsl/shaders')
Wd.set_pack_ids(pk.block_ids()); eng.upload_mesh(Wd.mesh(B,Sk,BL))
for n,(cam,sky) in SC.items():
    fn = f'/tmp/b_{n}_bsl.png'
    if os.path.exists(fn): continue
    s = OS.OptiSession(eng, pk, 'bsl'+n); t = time.time()
    for k in range(14): img = s.frame(cam,cam,sky,k)
    img.save(fn); print('bsl', n, f'{(time.time()-t)/14:.2f}s/frame', flush=True); s.release()
Wd.PACK_ID.clear(); Wd.PACK_ID.update(ORIG_IDS); eng.upload_mesh(Wd.mesh(B,Sk,BL))
eng.faithful = True
for n,(cam,sky) in SC.items():
    fn = f'/tmp/b_{n}_eiq.png'
    if os.path.exists(fn): continue
    img,ex = S2.render_static(eng,'/home/claude/sp_off/shaders',cam,sky,frames=18,opts={'EIQ_LEVEL':3},tag='e'+n); img.save(fn); print('eiq', n, flush=True)
print('done', flush=True)
