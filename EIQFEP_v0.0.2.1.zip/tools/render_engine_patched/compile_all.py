import sys,os,glob
sys.path.insert(0,'/home/claude/work/eng')
import world as Wd, engine as E
A=Wd.make_atlas(); eng=E.Engine(64,64,A); E.ROOT='/home/claude/work/pack/'
bad=0; n=0
for lvl in (1,3,5):
  for dim,wd in ((0,'world0'),(-1,'world-1'),(1,'world1')):
    names=sorted({os.path.basename(f).rsplit('.',1)[0] for f in glob.glob(f'pack/{wd}/*.fsh')})
    for nm in names:
        n+=1
        try: eng.program(nm,dim,{'EIQ_LEVEL':lvl})
        except Exception as e:
            bad+=1; print('FAIL',lvl,wd,nm,str(e)[:300].replace('\n',' '))
    for f in sorted(glob.glob(f'pack/{wd}/*.csh')):
        if lvl<3: continue
        n+=1
        try: eng.compute(os.path.basename(f)[:-4],dim,{'EIQ_LEVEL':lvl})
        except Exception as e: bad+=1; print('FAIL csh',lvl,wd,f,str(e)[:300].replace('\n',' '))
print('programs',n,'failures',bad)
