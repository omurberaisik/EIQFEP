import sys,re,shutil,subprocess,os,json
S='/tmp/claude-0/-home-claude/c7854418-8617-53bd-8bf5-f7205d524b72/scratchpad'
V={'base':{},'noAO':{'AO_MODE':0},'noContact':{'CONTACT_STEPS':0},'noPCSS':{'SHADOW_PCSS':0},'taps8':{'SHADOW_TAPS':8},
   'normgen0':{'NORMAL_GEN':0},'noSSR':{'SSR_STEPS':0},'noVL':{'VL_STEPS':0},'cloud6':{'CLOUD_STEPS':6,'CLOUD_LSTEPS':1},
   'noGod':{'GODRAY_STEPS':0},'bloom3':{'BLOOM_LODS':3}}
names=sys.argv[1].split(',')
for n in names:
    d=f'{S}/pk_{n}'; shutil.rmtree(d,ignore_errors=True); shutil.copytree('/home/claude/work/pack',d)
    p=d+'/lib/settings.glsl'; s=open(p).read()
    def seg(m):
        t=m.group(0)
        for k,v in V[n].items(): t=re.sub(rf'(#define {k} )\S+',rf'\g<1>{v}',t)
        return t
    s=re.sub(r'#elif EIQ_LEVEL == 4.*?(?=#elif|#else)',seg,s,flags=re.S)
    open(p,'w').write(s)
    out=subprocess.run(['python3','-I','/home/claude/work/profile.py','4','{}',d+'/'],capture_output=True,text=True).stdout
    t={l.split()[0]:float(l.split()[1]) for l in out.splitlines()[1:]}
    tot=float(out.split('total')[1].split('ms')[0])
    print(f"{n:10s} total {tot:5.0f} nonshadow {tot-t.get('shadowmap',0)-t.get('shadow',0):5.0f} deferred {t.get('deferred',0):4.0f} gbuf {t.get('gbuffers',0):4.0f} c2 {t.get('composite2',0):3.0f} final {t.get('final',0):3.0f} water {t.get('water',0):3.0f}",flush=True)
