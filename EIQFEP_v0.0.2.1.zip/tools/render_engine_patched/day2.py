import sys; sys.path.insert(0,"/home/claude/work")
from sweep_common import *
from PIL import Image
import math
eng,h=make(); cy=float(h[86,6])+14.0
base=dict(pos=(86.0,cy,6.0),yaw=-1.15,pitch=0.05,fov=70)
def fogfor(sa):
    elev=math.sin(2*math.pi*sa)   # sunAngle 0 sunrise, .25 noon, .5 sunset
    f=min(max(elev*1.6+0.45,0.03),1.0)
    return (0.75*f,0.85*f,1.0*f)
tiles=[];prev=None
for i in range(0,49,2):
    sa=i/48
    s=S2.Session(eng,'/home/claude/work/pack/',{'EIQ_LEVEL':4},0,'d2')
    sky=dict(sunAngle=sa,fog=fogfor(sa))
    for k in range(5): img=s.frame(base,base,sky,k)
    rep=s.nan_report(); s.release(); a=np.asarray(img,float)/255; L=a.mean()
    flag='  !! jump' if prev is not None and abs(L-prev)>0.05 else ''
    print(f'sun={sa:.3f} fog={np.round(fogfor(sa),2)} nan={rep} mean={L:.3f} sky={np.round(a[:40].mean((0,1)),3)}{flag}',flush=True)
    prev=L
    if (i//2)%2==0: tiles.append(img.resize((320,180)))
W,Hh=320,180; cols=6; rows=(len(tiles)+cols-1)//cols
sh=Image.new('RGB',(W*cols,Hh*rows))
for j,t in enumerate(tiles): sh.paste(t,((j%cols)*W,(j//cols)*Hh))
sh.save('/home/claude/work/out/day_sheet.png')
