import sys; sys.path.insert(0,'/home/claude/work/eng')
import numpy as np, world as Wd, engine as E, session2 as S2
B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); A = Wd.make_atlas()
eng = E.Engine(480,270,A); eng.upload_mesh(Wd.mesh(B,Sk,BL))
cy=float(h[86,6])+14.0
cam=dict(pos=(86.0,cy,6.0),yaw=0.35,pitch=-0.12,fov=70); sky=dict(sunAngle=0.80,fog=(0.02,0.03,0.07))
lvl=int(sys.argv[1])
s=S2.Session(eng,'/home/claude/work/pack/',{'EIQ_LEVEL':lvl},0,'d')
for k in range(8): s.frame(cam,cam,sky,k)
d=s.lpv_dims
for n,dt,c in (('voxEmit','u1',4),('voxOpac','u1',4),('lpvImgA','f2',4)):
    a=np.frombuffer(s.vol[n].read(),dt).reshape(d[2],d[1],d[0],4).astype(float)
    print(n,'max',a.max(axis=(0,1,2)),'nz',(a[...,3]>0).sum(), 'flag2',(a[...,3]>1.5).sum() if n=='lpvImgA' else '')
if 'rtGeo' in s.vol:
    a=np.frombuffer(s.vol['rtBrick'].read(),'u1').reshape(-1,4); print('brick occ',(a[:,0]>0).sum(),'of',len(a))
    a=np.frombuffer(s.vol['rtGeo'].read(),'u1').reshape(-1,4); print('rtGeo solid',(a[:,3]>200).sum())
