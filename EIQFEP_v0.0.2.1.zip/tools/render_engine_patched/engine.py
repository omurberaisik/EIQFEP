"""Mini Iris emulation: runs the real EIQFEP shader sources through Mesa llvmpipe."""
import re, time, math
import numpy as np
import moderngl
from PIL import Image
import world as W
import iris_port as IP

import os
ROOT = os.environ.get("EIQ_ROOT", "/home/claude/sp/shaders")
SAMPLERS = ['colortex0', 'colortex1', 'colortex2', 'colortex3', 'colortex4', 'colortex5', 'colortex6', 'colortex7', 'colortex8',
            'depthtex0', 'depthtex1', 'shadowtex0', 'shadowtex1', 'shadowcolor0',
            'gtexture', 'normals', 'specular', 'noisetex']

FMT_DEFS = ''.join(f'#define {n} {i}\n' for i, n in enumerate(
    ['R11F_G11F_B10F', 'RGBA16', 'RGBA8', 'RGBA16F', 'RGBA32F', 'R8', 'RG16F']))
VS_PRELUDE = '''
uniform mat4 iris_P; uniform mat4 iris_MV; uniform mat3 iris_NM; uniform mat4 iris_TM[2];
in vec4 iris_Vertex; in vec4 iris_Color; in vec3 iris_Normal; in vec4 iris_UV0; in vec4 iris_UV1;
#define gl_Vertex iris_Vertex
#define gl_Color iris_Color
#define gl_Normal iris_Normal
#define gl_MultiTexCoord0 iris_UV0
#define gl_MultiTexCoord1 iris_UV1
#define gl_ModelViewMatrix iris_MV
#define gl_ProjectionMatrix iris_P
#define gl_NormalMatrix iris_NM
#define gl_TextureMatrix iris_TM
#define ftransform() (iris_P * iris_MV * iris_Vertex)
'''
FMT_DEFS += '#define IS_IRIS\n#define MC_GL_VERSION 450\n'
LAYOUT = '4f 4f 3f 4f 4f 4f 2f 4f 4f'
ATTRS = ('iris_Vertex', 'iris_Color', 'iris_Normal', 'iris_UV0', 'iris_UV1',
         'mc_Entity', 'mc_midTexCoord', 'at_tangent', 'at_midBlock')


IMG_RE = re.compile(r'uniform\s+image3D\s+(\w+)\s*;')
IMG_FMT = {'lpvImgA': 'rgba16f', 'lpvImgB': 'rgba16f'}
IMG_UNIT = {n: i for i, n in enumerate(['voxEmit', 'voxOpac', 'lpvImgA', 'lpvImgB', 'rtGeo', 'rtBrick'])}


def img_sub(m):
    n = m.group(1)
    return f'layout({IMG_FMT.get(n, "rgba8")}, binding={IMG_UNIT[n]}) uniform image3D {n};'


def expand(path):
    out = []
    for ln in open(path, encoding='utf-8').read().split('\n'):
        m = re.match(r'\s*#include\s+"([^"]+)"', ln)
        out.append(expand(ROOT + m.group(1)) if m else ln)
    return '\n'.join(out)


def patch_opts(src, opts):
    for k, v in (opts or {}).items():
        if v is None:
            src = re.sub(rf'(?m)^#define {k}\b.*$', '', src); continue
        if v == 'ON':
            src = re.sub(rf'(?m)^//#define {k}\b', f'#define {k}', src); continue
        src = re.sub(rf'(?m)^#define {k} [^\n/]*', f'#define {k} {v} ', src, count=1)
    return src


def mat_look(yaw, pitch):
    f = np.array([math.sin(yaw) * math.cos(pitch), math.sin(pitch), math.cos(yaw) * math.cos(pitch)])
    s = np.cross(f, [0, 1, 0]); s /= np.linalg.norm(s)
    u = np.cross(s, f)
    M = np.eye(4); M[0, :3] = s; M[1, :3] = u; M[2, :3] = -f
    return M


def mat_persp(fov_deg, aspect, near, far):
    f = 1 / math.tan(math.radians(fov_deg) / 2)
    P = np.zeros((4, 4))
    P[0, 0] = f / aspect; P[1, 1] = f
    P[2, 2] = (far + near) / (near - far); P[2, 3] = 2 * far * near / (near - far); P[3, 2] = -1
    return P


def mat_T(v):
    M = np.eye(4); M[:3, 3] = v; return M


def sun_dir(sun_angle, tilt_deg=-25.0):
    th = 2 * math.pi * sun_angle
    d = np.array([math.cos(th), math.sin(th), 0.0])
    p = math.radians(tilt_deg)
    return np.array([d[0], d[1] * math.cos(p), d[1] * math.sin(p)])


QUAD_FS_VS = '''#version 330 core
in vec2 p; out vec2 uv; void main(){ uv=p; gl_Position=vec4(p*2.0-1.0,0.0,1.0);}'''
COPY_DEPTH_FS = '''#version 330 core
uniform sampler2D src; in vec2 uv; void main(){ gl_FragDepth = texture(src, uv).r; }'''

VAN_VS = '''#version 330 core
uniform mat4 iris_P; uniform mat4 iris_MV;
in vec4 iris_Vertex; in vec4 iris_Color; in vec3 iris_Normal; in vec4 iris_UV0; in vec4 iris_UV1; in vec4 mc_Entity;
out vec2 uv; out vec2 lm; out vec4 col; out vec3 nrm; out float dist; flat out int vid;
void main(){ vec4 vp = iris_MV*iris_Vertex; gl_Position = iris_P*vp; uv=iris_UV0.xy; lm=(iris_UV1.xy-8.0)/240.0;
  col=iris_Color; nrm=iris_Normal; dist=length(vp.xyz); vid=int(mc_Entity.x+0.5);}'''
VAN_FS = '''#version 330 core
uniform sampler2D gtexture; uniform float dayf; uniform vec3 fogCol; uniform vec3 skyTint; uniform float fogStart; uniform float fogEnd;
in vec2 uv; in vec2 lm; in vec4 col; in vec3 nrm; in float dist; flat in int vid; out vec4 o;
float curve(float l){ return l/(4.0-3.0*l); }
void main(){
  vec4 t = texture(gtexture, uv);
  if (t.a < 0.1 && vid != 8 && vid != 20) discard;
  float sky = curve(lm.y)*dayf; float blk = curve(lm.x);
  vec3 L = max(vec3(sky)*skyTint, blk*vec3(1.0,0.80,0.55));
  L = clamp(L + 0.035, 0.0, 1.0);
  float shade = nrm.y>0.5 ? 1.0 : (nrm.y<-0.5 ? 0.5 : (abs(nrm.x)>0.5 ? 0.6 : 0.8));
  float ao = col.a;
  if (vid==50 || vid==40) { L = vec3(1.0); shade = 1.0; ao = 1.0; }
  vec3 c = t.rgb*col.rgb*L*shade*ao;
  float a = t.a;
  if (vid==8) { a = 0.70; c = col.rgb*L*shade*0.95; }
  float f = smoothstep(fogStart, fogEnd, dist);
  c = mix(c, fogCol, f);
  o = vec4(c, a);
}'''
VAN_SKY_FS = '''#version 330 core
uniform mat4 invP; uniform mat3 invR; uniform vec3 sunDir; uniform float dayf; uniform vec3 camPos; uniform vec3 fogCol; uniform vec3 skyTint;
in vec2 uv; out vec4 o;
float h12(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
void main(){
  vec4 v = invP*vec4(uv*2.0-1.0, 1.0, 1.0); vec3 rd = normalize(invR*normalize(v.xyz/v.w));
  vec3 hor = vec3(0.75,0.85,1.0), zen = vec3(0.47,0.65,1.0);
  vec3 col = mix(hor, zen, pow(clamp(rd.y,0.0,1.0), 0.6)) * mix(vec3(0.03,0.03,0.07)*3.0, vec3(1.0), dayf) * mix(vec3(1.0), skyTint, 0.0);
  if (rd.y < 0.0) col = mix(col, fogCol, smoothstep(0.0,-0.08,rd.y));
  float night = 1.0 - smoothstep(0.25, 0.6, dayf);
  if (night > 0.0 && rd.y > 0.0) {
    vec3 g = floor(rd*180.0); float s = fract(sin(dot(g, vec3(12.9898,78.233,37.719)))*43758.5453);
    if (s > 0.9965) col += vec3(0.9)*night;
  }
  vec3 sx = normalize(cross(sunDir, vec3(0,0,1))); vec3 sy = cross(sunDir, sx);
  if (dot(rd,sunDir) > 0.0 && abs(dot(rd,sx)) < 0.13 && abs(dot(rd,sy)) < 0.13) col = vec3(1.0,1.0,0.85);
  vec3 md = -sunDir; vec3 mx = normalize(cross(md, vec3(0,0,1))); vec3 my = cross(md, mx);
  if (dot(rd,md) > 0.0 && abs(dot(rd,mx)) < 0.10 && abs(dot(rd,my)) < 0.10) col = vec3(0.86,0.88,0.95);
  if (rd.y > 0.01) {
    float t = (192.0-camPos.y)/rd.y; vec2 hit = camPos.xz + rd.xz*t; vec2 cell = floor(hit/12.0);
    float occ = h12(cell) + 0.35*h12(floor(cell/4.0)) - 0.12;
    if (occ > 0.78 && t < 1200.0) col = mix(col, vec3(0.97)*mix(0.35,1.0,dayf), 0.85*(1.0-smoothstep(500.0,1200.0,t)));
  }
  o = vec4(col, 1.0);
}'''


class Engine:
    def __init__(self, w, h, atlas):
        self.ctx = moderngl.create_standalone_context(backend='egl')
        self.w, self.h = w, h
        ctx = self.ctx
        self.gtex = ctx.texture(atlas.shape[1::-1], 4, np.ascontiguousarray(atlas[::1]).tobytes())
        self.gtex.filter = (moderngl.NEAREST, moderngl.NEAREST)
        self.dummy = ctx.texture((1, 1), 4, bytes([0, 0, 0, 0]))
        self.dummy.filter = (moderngl.NEAREST, moderngl.NEAREST)
        self.quad_vbo = ctx.buffer(np.array([0, 0, 1, 0, 0, 1, 1, 1], 'f4').tobytes())
        self.copy_prog = ctx.program(vertex_shader=QUAD_FS_VS, fragment_shader=COPY_DEPTH_FS)
        self.copy_vao = ctx.vertex_array(self.copy_prog, [(self.quad_vbo, '2f', 'p')])
        self.cache = {}
        self.mesh = {}
        self.vans = {}
        self.compile_log = []
        self.faithful = True          # True: Iris 26.3 behaviours (iris_port.py); False: original guesses

    # -------------------------------------------------------------- resources
    def upload_mesh(self, M):
        for k, (V, I) in M.items():
            if len(I) == 0:   # degenerate placeholder quad (renders nothing)
                V = np.zeros((4, W.NF), np.float32); V[:, 3] = 1; V[:, 6] = 1; I = np.array([0, 1, 2, 0, 2, 3], np.uint32)
            self.mesh[k] = (self.ctx.buffer(V.tobytes()), self.ctx.buffer(I.tobytes()), len(I))

    def tex(self, size, dtype='f2', mip=False, comps=4):
        bpc = {'f1': 1, 'f2': 2, 'f4': 4}.get(dtype, 1)
        t = self.ctx.texture(size, comps, data=bytes(size[0] * size[1] * comps * bpc), dtype=dtype)   # zero-init (GL leaves it undefined)
        t.filter = ((moderngl.LINEAR_MIPMAP_LINEAR if mip else moderngl.LINEAR), moderngl.LINEAR)
        t.repeat_x = t.repeat_y = False
        return t

    def depth_tex(self, size, linear=False):
        d = self.ctx.depth_texture(size)
        d.compare_func = ''
        f = moderngl.LINEAR if linear else moderngl.NEAREST
        d.filter = (f, f)
        d.repeat_x = d.repeat_y = False
        return d

    def copy_depth(self, src, dst):
        ctx = self.ctx
        fbo = ctx.framebuffer(depth_attachment=dst)
        fbo.use(); ctx.depth_func = '1'; ctx.enable(moderngl.DEPTH_TEST)
        src.use(0); self.copy_prog['src'].value = 0
        self.copy_vao.render(moderngl.TRIANGLE_STRIP)
        ctx.depth_func = '<'
        fbo.release()

    # ---------------------------------------------------------------- programs
    def program(self, name, dim=0, opts=None):
        key = (name, dim, tuple(sorted((opts or {}).items())))
        if key in self.cache: return self.cache[key]
        wdir = {0: 'world0', 1: 'world1', -1: 'world-1'}[dim]
        out = {}
        for stage in ('vsh', 'fsh'):
            src = patch_opts(expand(f'{ROOT}/{wdir}/{name}.{stage}'), opts)
            pre = FMT_DEFS + (VS_PRELUDE if stage == 'vsh' else '')
            src = IMG_RE.sub(img_sub, src)
            exts = ''.join(l + '\n' for l in src.split('\n') if l.startswith('#extension'))
            src = '\n'.join(l for l in src.split('\n') if not l.startswith('#extension'))
            ver = '430' if 'image3D' in src else '330'
            src = src.replace('#version 330 compatibility', f'#version {ver} core\n' + exts + pre, 1)
            out[stage] = src
        sk = (out['vsh'], out['fsh'])
        sc = self.__dict__.setdefault('srccache', {})
        if sk in sc:
            prog = sc[sk]
        else:
            try:
                prog = self.ctx.program(vertex_shader=out['vsh'], fragment_shader=out['fsh'])
            except Exception as e:
                self.compile_log.append((name, dim, str(e)[:900]))
                raise
            sc[sk] = prog
        m = re.search(r'RENDERTARGETS:\s*([0-9,\s]+)', out['fsh'])
        targets = [int(x) for x in m.group(1).replace(' ', '').split(',')] if m else [0]
        self.cache[key] = (prog, targets)
        return self.cache[key]

    def compute(self, name, dim=0, opts=None):
        key = ('csh', name, dim, tuple(sorted((opts or {}).items())))
        if key in self.cache: return self.cache[key]
        wdir = {0: 'world0', 1: 'world1', -1: 'world-1'}[dim]
        src = patch_opts(expand(f'{ROOT}/{wdir}/{name}.csh'), opts)
        src = IMG_RE.sub(img_sub, src)
        exts = ''.join(l + '\n' for l in src.split('\n') if l.startswith('#extension'))
        src = '\n'.join(l for l in src.split('\n') if not l.startswith('#extension'))
        src = src.replace('#version 430 compatibility', '#version 430\n' + exts + FMT_DEFS, 1)
        sc = self.__dict__.setdefault('srccache', {})
        if src in sc:
            prog = sc[src]
        else:
            try:
                prog = self.ctx.compute_shader(src)
            except Exception as e:
                self.compile_log.append((name, dim, str(e)[:900])); raise
            sc[src] = prog
        self.cache[key] = prog
        return prog

    def set_uniforms(self, prog, U):
        for name in prog:
            if name in U:
                v = U[name]; m = prog[name]
                if isinstance(v, np.ndarray) and v.ndim >= 2:
                    if v.ndim == 3: v = v[:m.array_length]
                    try:
                        m.write(np.ascontiguousarray(np.swapaxes(v, -1, -2)).astype('f4').tobytes())
                    except Exception as e:
                        raise RuntimeError(f'uniform {name} dim={m.dimension} len={m.array_length} shape={v.shape}: {e}')
                elif isinstance(v, (tuple, list)): m.value = tuple(v)
                else: m.value = v

    def bind_samplers(self, prog, bound):
        for i, s in enumerate(SAMPLERS):
            if s in prog:
                prog[s].value = i
                bound[s].use(i)
        self.bind_volumes(prog)

    VOL_IMAGES = ['voxEmit', 'voxOpac', 'lpvImgA', 'lpvImgB', 'rtGeo', 'rtBrick']
    VOL_SAMPLERS = {'lpvTexA': 'lpvImgA', 'lpvTexB': 'lpvImgB', 'rtGeoTex': 'rtGeo', 'rtBrickTex': 'rtBrick',
                    'voxEmitTex': 'voxEmit', 'voxOpacTex': 'voxOpac'}

    def bind_volumes(self, prog):
        vol = getattr(self, 'vol', None)
        if not vol: return
        for i, n in enumerate(self.VOL_IMAGES):
            if n in prog and n in vol:
                vol[n].bind_to_image(i, read=True, write=True); prog[n].value = i
        for j, (sn, n) in enumerate(self.VOL_SAMPLERS.items()):
            if sn in prog and n in vol:
                vol[n].use(20 + j); prog[sn].value = 20 + j

    # ---------------------------------------------------------- uniform factory
    def make_uniforms(self, cam, sky, frame, shadow=None, prev=None):
        w, h = self.w, self.h
        pos = np.array(cam['pos'], float)
        V = mat_look(cam['yaw'], cam['pitch'])
        P = mat_persp(cam.get('fov', 70), w / h, 0.05, 512.0)
        phi = (shadow or {}).get('phi', sky.get('phi', -25.0))
        sd = IP.sun_dir_world(sky['sunAngle'], phi) if self.faithful else sun_dir(sky['sunAngle'])
        R3 = V[:3, :3]
        pprev = np.array(prev['pos'], float) if prev else pos
        Vp = mat_look(prev['yaw'], prev['pitch']) if prev else V
        U = dict(
            frameTimeCounter=sky.get('time', 1000.0) + frame / 30.0, frameCounter=frame,
            frameTime=1 / 30.0, viewWidth=float(w), viewHeight=float(h), near=0.05, far=(192.0 if self.faithful else 512.0),
            rainStrength=sky.get('rain', 0.0), wetness=sky.get('wet', 0.0), sunAngle=sky['sunAngle'],
            isEyeInWater=sky.get('eyeWater', 0), moonPhase=sky.get('moon', 0), nightVision=sky.get('nightVision', 0.0), blindness=sky.get('blind', 0.0),
            centerDepthSmooth=sky.get("focus", 0.9975), thunderStrength=sky.get('thunder', 0.0), worldDay=sky.get('day', 3), temperature=0.8, rainfall=0.4,
            eyeBrightnessSmooth=(0, int(sky.get('eyeSky', 240))),
            cameraPosition=tuple(pos), previousCameraPosition=tuple(pprev),
            sunPosition=tuple(R3 @ sd * 100), moonPosition=tuple(R3 @ -sd * 100),
            upPosition=tuple(R3 @ np.array([0, 1, 0]) * 100),
            shadowLightPosition=tuple(R3 @ (sd if sky['sunAngle'] < 0.5 else -sd) * 100),
            fogColor=tuple(sky.get('fog', (0.75, 0.85, 1.0))),
            gbufferModelView=V, gbufferModelViewInverse=np.linalg.inv(V),
            gbufferProjection=P, gbufferProjectionInverse=np.linalg.inv(P),
            gbufferPreviousModelView=Vp, gbufferPreviousProjection=P,
            entityColor=(0, 0, 0, 0), blockEntityId=-1, heldBlockLightValue=0,
        )
        U['iris_MV'] = V @ mat_T(-pos); U['iris_P'] = P; U['iris_NM'] = R3.copy()
        U['iris_TM'] = np.stack([np.eye(4), np.diag([1 / 256., 1 / 256., 1, 1])])
        if shadow is not None and self.faithful:
            t = sky['sunAngle']; day = t < 0.5
            shadow_angle = t if day else (t + 0.5) % 1.0              # ShadowRenderer.getShadowAngle(): sun by day, moon by night
            SMV = IP.shadow_model_view(shadow_angle, phi, shadow.get('interval', 2.0), tuple(pos))
            SP = IP.shadow_ortho(shadow['dist'], shadow.get('near', IP.SHADOW_NEAR), shadow.get('far', IP.SHADOW_FAR))
            U['shadowModelView'] = SMV; U['shadowModelViewInverse'] = np.linalg.inv(SMV); U['shadowProjection'] = SP
            U['_shadow_MV'] = SMV @ mat_T(-pos); U['_shadow_P'] = SP
        elif shadow is not None:
            sdist = shadow['dist']
            L = sd if sky['sunAngle'] < 0.5 else -sd
            fwd = -L
            up = np.array([0, 1, 0.0]) if abs(L[1]) < 0.95 else np.array([1, 0, 0.0])
            s = np.cross(fwd, up); s /= np.linalg.norm(s); u = np.cross(s, fwd)
            Rm = np.eye(4); Rm[0, :3] = s; Rm[1, :3] = u; Rm[2, :3] = -fwd
            q = Rm[:3, :3] @ pos                      # Iris-style interval snapping (shadowIntervalSize = 2)
            I_ = 2.0; dxy = q[:2] - np.round(q[:2] / I_) * I_
            SMV = mat_T([dxy[0], dxy[1], -100]) @ Rm
            n_, f_ = 0.05, 256.0
            SP = np.diag([1 / sdist, 1 / sdist, -2 / (f_ - n_), 1.0]); SP[2, 3] = -(f_ + n_) / (f_ - n_)
            U['shadowModelView'] = SMV; U['shadowModelViewInverse'] = np.linalg.inv(SMV); U['shadowProjection'] = SP
            U['_shadow_MV'] = SMV @ mat_T(-pos); U['_shadow_P'] = SP
        return U, sd

    # ---------------------------------------------------------------- the pack
    def render_pack(self, cam, sky, frames=12, opts=None, dim=0, lm_sky_override=None, log=None):
        ctx = self.ctx; w, h = self.w, self.h
        opts = dict(opts or {})
        level = opts.get('EIQ_LEVEL', 3)
        # derive SHADOW_RES / distance from settings by compiling a probe: replicate table
        sres = {1: 1024, 2: 1536, 3: 2048, 4: 3072, 5: 4096}[level]
        sdist = float(opts.get('SHADOW_DISTANCE', 128))
        P = lambda n: self.program(n, dim, opts)
        # buffers
        main = [self.tex((w, h), 'f2', mip=(i == 4)) for i in range(6)]
        alt = [self.tex((w, h), 'f2', mip=(i == 4)) for i in range(6)]
        depth_main = self.depth_tex((w, h)); dc0 = self.depth_tex((w, h)); dc1 = self.depth_tex((w, h))
        out_tex = ctx.texture((w, h), 4); out_fbo = ctx.framebuffer([out_tex])
        sh0 = self.depth_tex((sres, sres)); sh1 = self.depth_tex((sres, sres))
        shc = ctx.texture((sres, sres), 4); shc.filter = (moderngl.LINEAR, moderngl.LINEAR)
        bound = {s: self.dummy for s in SAMPLERS}
        bound['gtexture'] = self.gtex
        U0, sd = self.make_uniforms(cam, sky, 0, shadow={'dist': sdist})
        mesh_vaos = {}

        def vao_for(prog, key):
            vb, ib, n = self.mesh[key]
            return ctx.vertex_array(prog, [(vb, LAYOUT, *ATTRS)], index_buffer=ib, skip_errors=True), n

        # ---- shadow pass (static)
        sprog, _ = P('shadow')
        Us = dict(U0); Us['iris_MV'] = U0['_shadow_MV']; Us['iris_P'] = U0['_shadow_P']
        sfbo = ctx.framebuffer([shc], depth_attachment=sh0)
        sfbo.use(); ctx.enable(moderngl.DEPTH_TEST); ctx.disable(moderngl.BLEND)
        ctx.clear(1, 1, 1, 0, depth=1.0)
        self.set_uniforms(sprog, Us); self.bind_samplers(sprog, bound)
        v, n = vao_for(sprog, 'opaque'); v.render(moderngl.TRIANGLES, vertices=n)
        self.copy_depth(sh0, sh1)
        sfbo.use(); ctx.enable(moderngl.DEPTH_TEST)
        v, n = vao_for(sprog, 'trans'); v.render(moderngl.TRIANGLES, vertices=n)
        bound['shadowtex0'] = sh0; bound['shadowtex1'] = sh1; bound['shadowcolor0'] = shc

        t0 = time.time()
        fog = sky.get('fog', (0.75, 0.85, 1.0))
        for frame in range(frames):
            U, _ = self.make_uniforms(cam, sky, frame, shadow={'dist': sdist})
            if lm_sky_override is not None: U['_lm_sky'] = lm_sky_override

            def fs_pass(name, last=False):
                prog, targets = P(name)
                for i in range(6): bound[f'colortex{i}'] = main[i]
                self.set_uniforms(prog, U)
                U_q = {'iris_MV': np.eye(4), 'iris_NM': np.eye(3), 'iris_TM': np.stack([np.eye(4), np.eye(4)]),
                       'iris_P': np.array([[2, 0, 0, -1], [0, 2, 0, -1], [0, 0, 1, 0], [0, 0, 0, 1.0]])}
                self.set_uniforms(prog, U_q)
                self.bind_samplers(prog, bound)
                if last: fbo = out_fbo
                else: fbo = ctx.framebuffer([alt[t] for t in targets])
                fbo.use(); ctx.disable(moderngl.DEPTH_TEST); ctx.disable(moderngl.BLEND)
                qb = ctx.buffer(np.array([[0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1]] * 0, 'f4').tobytes()) if False else None
                vao = self.fs_vao(prog)
                vao.render(moderngl.TRIANGLE_STRIP)
                if not last:
                    fbo.release()
                    for t in targets: main[t], alt[t] = alt[t], main[t]

            # clear gbuffers
            for i, c in ((0, (fog[0], fog[1], fog[2], 1)), (1, (0, 0, 0, 0)), (2, (0, 0, 0, 0))):
                f = ctx.framebuffer([main[i]]); f.clear(*c); f.release()
            gfbo = ctx.framebuffer([main[0], main[1], main[2]], depth_attachment=depth_main)
            gfbo.use(); ctx.clear(depth=1.0)
            ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'; ctx.disable(moderngl.BLEND)
            gp, _ = P('gbuffers_terrain')
            self.set_uniforms(gp, U); self.bind_samplers(gp, bound)
            v, n = vao_for(gp, 'opaque'); v.render(moderngl.TRIANGLES, vertices=n)
            self.copy_depth(depth_main, dc1); self.copy_depth(depth_main, dc0)
            bound['depthtex0'] = dc0; bound['depthtex1'] = dc1
            fs_pass('deferred')
            # translucents: pass A (colour 0, blended) / pass B (normals+material, no blend)
            wp, _ = P('gbuffers_water')
            self.set_uniforms(wp, U); self.bind_samplers(wp, bound)
            wfbo = ctx.framebuffer([main[0], main[1], main[2]], depth_attachment=depth_main)
            wfbo.use(); ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'
            wfbo.color_mask = ((True,) * 4, (False,) * 4, (False,) * 4)
            ctx.enable(moderngl.BLEND); ctx.blend_func = moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA
            v, n = vao_for(wp, 'trans'); v.render(moderngl.TRIANGLES, vertices=n)
            ctx.disable(moderngl.BLEND)
            wfbo.color_mask = ((False,) * 4, (True,) * 4, (True,) * 4)
            wfbo.depth_mask = False; ctx.depth_func = '<='
            v.render(moderngl.TRIANGLES, vertices=n)
            wfbo.depth_mask = True; wfbo.color_mask = ((True,) * 4,) * 3; ctx.depth_func = '<'
            self.copy_depth(depth_main, dc0)
            bound['depthtex0'] = dc0
            for nme in ('composite', 'composite1', 'composite2', 'composite3'):
                fs_pass(nme)
                if nme == 'composite3': main[4].build_mipmaps()
            fs_pass('composite4')
            fs_pass('final', last=True)
        ctx.finish()
        dt = (time.time() - t0) / frames
        img = Image.frombytes('RGBA', (w, h), out_fbo.read(components=4)).transpose(Image.FLIP_TOP_BOTTOM).convert('RGB')
        exposure = np.frombuffer(self._read_main(main[5]), 'f2')[:1].astype(float)[0]
        for t in main + alt + [depth_main, dc0, dc1, sh0, sh1, shc, out_tex]: t.release()
        return img, dt, exposure

    def _read_main(self, tex):
        return tex.read()

    def fs_vao(self, prog):
        key = ('fsvao', id(prog))
        if key not in self.vans:
            vb = self.ctx.buffer(np.array([[0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1][:0]] * 0, 'f4').tobytes()) if False else None
            data = []
            for (x, y) in ((0, 0), (1, 0), (0, 1), (1, 1)):
                row = np.zeros(33, 'f4'); row[0] = x; row[1] = y; row[3] = 1; row[11] = x; row[12] = y; row[14] = 1
                data.append(row)
            vb = self.ctx.buffer(np.stack(data).tobytes())
            self.vans[key] = self.ctx.vertex_array(prog, [(vb, LAYOUT, *ATTRS)], skip_errors=True)
        return self.vans[key]

    # ------------------------------------------------------------------ vanilla
    def render_vanilla(self, cam, sky):
        ctx = self.ctx; w, h = self.w, self.h
        if 'van' not in self.vans:
            self.vans['van'] = ctx.program(vertex_shader=VAN_VS, fragment_shader=VAN_FS)
            self.vans['vsky'] = ctx.program(vertex_shader=QUAD_FS_VS, fragment_shader=VAN_SKY_FS)
            self.vans['vskyvao'] = ctx.vertex_array(self.vans['vsky'], [(self.quad_vbo, '2f', 'p')])
        prog, sprog = self.vans['van'], self.vans['vsky']
        U, sd = self.make_uniforms(cam, sky, 0)
        dayf = float(np.clip(sd[1] * 2.2 + 0.55, 0.18, 1.0))
        night = dayf < 0.5
        skyTint = (0.78, 0.82, 1.0) if night else (1.0, 1.0, 1.0)
        fogc = np.array((0.75, 0.85, 1.0)) * (dayf if not night else 0.12)
        fogc = tuple(float(x) for x in (fogc if dayf > 0.5 else np.array([0.02, 0.025, 0.06]) * (dayf / 0.18)))
        tex = ctx.texture((w, h), 4); dep = ctx.depth_renderbuffer((w, h))
        fbo = ctx.framebuffer([tex], depth_attachment=dep)
        fbo.use(); ctx.clear(*fogc, 1.0, depth=1.0)
        ctx.disable(moderngl.DEPTH_TEST); ctx.disable(moderngl.BLEND)
        V = U['gbufferModelView']; P = U['gbufferProjection']
        sprog['invP'].write(np.linalg.inv(P).T.astype('f4').tobytes())
        sprog['invR'].write(np.linalg.inv(V[:3, :3]).T.astype('f4').tobytes())
        for k_, v_ in (('sunDir', tuple(sd)), ('dayf', dayf), ('camPos', tuple(cam['pos'])), ('fogCol', fogc), ('skyTint', skyTint)):
            if k_ in sprog: sprog[k_].value = v_
        self.vans['vskyvao'].render(moderngl.TRIANGLE_STRIP)
        ctx.enable(moderngl.DEPTH_TEST)
        self.set_uniforms(prog, U)
        for k_, v_ in (('dayf', dayf), ('fogCol', fogc), ('skyTint', skyTint), ('fogStart', 110.0), ('fogEnd', 190.0)):
            if k_ in prog: prog[k_].value = v_
        self.gtex.use(0); prog['gtexture'].value = 0
        for key, blend in (('opaque', False), ('trans', True)):
            vb, ib, n = self.mesh[key]
            vao = ctx.vertex_array(prog, [(vb, LAYOUT, *ATTRS)], index_buffer=ib, skip_errors=True)
            if blend: ctx.enable(moderngl.BLEND); ctx.blend_func = moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA
            vao.render(moderngl.TRIANGLES, vertices=n)
        ctx.disable(moderngl.BLEND)
        img = Image.frombytes('RGBA', (w, h), fbo.read(components=4)).transpose(Image.FLIP_TOP_BOTTOM).convert('RGB')
        tex.release(); dep.release(); fbo.release()
        return img
