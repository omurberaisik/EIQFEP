import sys
from PIL import Image
tag=sys.argv[1]; names=sys.argv[2].split(','); cols=int(sys.argv[3]) if len(sys.argv)>3 else 2
im=[Image.open(f'out/{tag}_{n}.png') for n in names]
W,H=im[0].size; rows=(len(im)+cols-1)//cols
s=Image.new('RGB',(W*cols,H*rows))
for i,m in enumerate(im): s.paste(m,((i%cols)*W,(i//cols)*H))
s.save(f'out/{tag}_grid.png')
