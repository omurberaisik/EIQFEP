"""Behaviours ported (re-implemented, not copied) from Iris 26.3 (LGPL-3.0), commit 671a5c8.
Every function names the Iris source it mirrors, so the emulation can be audited.

Iris paths are relative to common/src/main/java/net/irisshaders/iris/ .
"""
import math, os, re
import numpy as np

# ---- shadows/ShadowMatrices.java ------------------------------------------------------------
SHADOW_NEAR = -100.05
SHADOW_FAR = 156.0
# ---- shaderpack/properties/PackShadowDirectives.java defaults ------------------------------
DEFAULT_SHADOW = dict(resolution=1024, distance=160.0, intervalSize=2.0, near=SHADOW_NEAR, far=SHADOW_FAR)
# ---- shaderpack/properties/PackDirectives.java ---------------------------------------------
DEFAULT_SUN_PATH_ROTATION = 0.0
# ---- targets/ClearPassCreator.java ---------------------------------------------------------
def default_clear_color(buffer, fog_rgb):
    if buffer == 0: return (fog_rgb[0], fog_rgb[1], fog_rgb[2], 1.0)   # fog colour, alpha 1
    if buffer == 1: return (1.0, 1.0, 1.0, 1.0)                        # solid white
    return (0.0, 0.0, 0.0, 0.0)
# ---- targets/RenderTarget.java: colortex* are LINEAR + CLAMP_TO_EDGE (non-integer formats) ---
# ---- shadows/ShadowRenderer.java: shadowtex*/shadowcolor* are LINEAR unless <name>Nearest ------
# ---- pathways/HandRenderer.java: DEPTH = 0.125 (MC_HAND_DEPTH) --------------------------------
MC_HAND_DEPTH = 0.125


# ---- gl/shader/StandardMacros.java ---------------------------------------------------------------
def standard_defines(mc_version=12100, gl_version=450):
    return {'IS_IRIS': '', 'MC_VERSION': str(mc_version), 'MC_GL_VERSION': str(gl_version),
            'MC_HAND_DEPTH': repr(MC_HAND_DEPTH), 'MC_NORMAL_MAP': '', 'MC_SPECULAR_MAP': '',
            'MC_RENDER_QUALITY': '1.0', 'MC_SHADOW_QUALITY': '1.0', 'MAX_COLOR_BUFFERS': '16'}


# ---- shaderpack/parsing/DispatchingDirectiveHolder.java: Integer.parseInt / Float.parseFloat -------
_FLOAT_RE = re.compile(r'^[+-]?(NaN|Infinity|(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?[fFdD]?)$')
_INT_RE = re.compile(r'^[+-]?\d+$')

def java_parse_float(s):
    t = s.strip()
    if not _FLOAT_RE.match(t): raise ValueError(f'NumberFormatException: "{s}"')
    return float(re.sub(r'[fFdD]$', '', t).replace('NaN', 'nan').replace('Infinity', 'inf'))

def java_parse_int(s):
    t = s.strip()
    if not _INT_RE.match(t): raise ValueError(f'NumberFormatException: "{s}"')
    return int(t)


# ---- shaderpack/parsing/ConstDirectiveParser.java -----------------------------------------------
_TYPES = ('int', 'float', 'vec2', 'ivec3', 'vec4', 'bool')

def find_directive_in_line(line):
    if 'const' not in line or '=' not in line or ';' not in line: return None
    line = line.strip()
    if not line.startswith('const'): return None
    line = line[len('const'):]
    if not line[:1].isspace(): return None
    line = line.strip()
    typ = next((t for t in ('int', 'float', 'vec2', 'ivec3', 'vec4', 'bool') if line.startswith(t)), None)
    if typ is None: return None
    line = line[len(typ):]
    if not line[:1].isspace(): return None
    eq = line.find('=')
    if eq == -1: return None
    key = line[:eq].strip()
    if not key or not all(c.isalnum() or c == '_' for c in key): return None
    rest = line[eq + 1:]
    sc = rest.find(';')
    if sc == -1: return None
    return typ, key, rest[:sc].strip()

def find_directives(source):
    out = []
    for ln in re.split(r'\r\n|\n|\r', source):
        d = find_directive_in_line(ln)
        if d: out.append(d)
    return out


# ---- shaderpack/preprocessor/JcppProcessor.java: (mini) preprocessor sufficient for packs ------------
def preprocess(text, defines, defs_out=None, expand_text=True):
    defs = dict(defines); out = []; stack = []   # stack of (active, taken, parent_active)
    def active(): return all(s[0] for s in stack)
    def expand(expr):
        for _ in range(12):
            new = re.sub(r'\b([A-Za-z_]\w*)\b', lambda m: defs[m.group(1)] if m.group(1) in defs and m.group(1) != 'defined' else m.group(1), expr)
            if new == expr: break
            expr = new
        return expr
    def evalc(expr):
        expr = re.sub(r'defined\s*\(\s*(\w+)\s*\)|defined\s+(\w+)', lambda m: '1' if (m.group(1) or m.group(2)) in defs else '0', expr)
        expr = expand(expr)
        expr = re.sub(r'\b[A-Za-z_]\w*\b', '0', expr)                   # unknown identifiers are 0
        expr = expr.replace('&&', ' and ').replace('||', ' or ')
        expr = re.sub(r'!(?!=)', ' not ', expr)
        expr = re.sub(r'(\d+\.\d*|\.\d+)[fF]?', lambda m: m.group(1), expr)
        try: return bool(eval(expr, {}, {}))
        except Exception: return False
    for ln in text.split('\n'):
        s = ln.strip()
        if s.startswith('#'):
            d = s[1:].strip(); m = re.match(r'(\w+)\s*(.*)', d)
            kw, arg = (m.group(1), m.group(2)) if m else ('', '')
            arg = re.sub(r'//.*$', '', arg).strip()
            if kw == 'ifdef': c = arg.split()[0] in defs if arg else False; stack.append((c, c)); continue
            if kw == 'ifndef': c = arg.split()[0] not in defs if arg else True; stack.append((c, c)); continue
            if kw == 'if': c = evalc(arg) if active() else False; stack.append((c, c)); continue
            if kw == 'elif':
                a, taken = stack.pop(); c = (not taken) and evalc(arg); stack.append((c, taken or c)); continue
            if kw == 'else':
                a, taken = stack.pop(); stack.append((not taken, True)); continue
            if kw == 'endif':
                stack.pop(); continue
            if not active(): continue
            if kw == 'define':
                mm = re.match(r'(\w+)(\([^)]*\))?\s*(.*)', arg)
                if mm and not mm.group(2): defs[mm.group(1)] = mm.group(3).strip()
                continue
            if kw == 'undef': defs.pop(arg.strip(), None); continue
            continue
        if active(): out.append(ln)
    text2 = '\n'.join(out)
    if defs_out is not None: defs_out.clear(); defs_out.update(defs)
    return expand_macros(text2, defs) if expand_text else text2

def expand_macros(text, defs):
    names = {k: v for k, v in defs.items() if v != '' and re.match(r'^\w+$', k)}
    def sub(m): return names.get(m.group(1), m.group(1))
    for _ in range(10):
        new = re.sub(r'\b([A-Za-z_]\w*)\b', sub, text)
        if new == text: break
        text = new
    return text


def expand_includes(root, path):
    out = []
    for ln in open(path, encoding='utf-8').read().split('\n'):
        m = re.match(r'\s*#include\s+"([^"]+)"', ln)
        out.append(expand_includes(root, root + m.group(1)) if m else ln)
    return '\n'.join(out)


def pack_directives(root, level_opts=None, dim='world0', program='deferred', log=None):
    """What Iris would read from the pack: preprocess (macros first!), then ConstDirectiveParser, then
    Float.parseFloat/Integer.parseInt; a parse failure is logged and the directive IGNORED (default stays)."""
    src = expand_includes(root, f'{root}/{dim}/{program}.fsh')
    # option overrides behave like user-chosen option values (they replace "#define NAME value" lines)
    for k, v in (level_opts or {}).items():
        if v is None: src = re.sub(rf'(?m)^#define {k}\b.*$', '', src)
        else: src = re.sub(rf'(?m)^#define {k} [^\n/]*', f'#define {k} {v} ', src, count=1)
    pre = preprocess(src, standard_defines())
    return parse_directives(pre)


def parse_directives(pre):
    sh = dict(DEFAULT_SHADOW); sun_rot = DEFAULT_SUN_PATH_ROTATION
    nearest = dict(shadowtex0=False, shadowtex1=False, shadowcolor0=False)
    problems = []
    for typ, key, val in find_directives(pre):
        try:
            if key == 'shadowMapResolution' and typ == 'int': sh['resolution'] = java_parse_int(val)
            elif key == 'shadowDistance' and typ == 'float': sh['distance'] = java_parse_float(val)
            elif key == 'shadowIntervalSize' and typ == 'float': sh['intervalSize'] = java_parse_float(val)
            elif key == 'sunPathRotation' and typ == 'float': sun_rot = java_parse_float(val)
            elif key in ('shadowtex0Nearest', 'shadowtex1Nearest', 'shadowcolor0Nearest') and typ == 'bool':
                nearest[key.replace('Nearest', '')] = (val == 'true')
            elif key == 'shadowtexNearest' and typ == 'bool':
                nearest['shadowtex0'] = nearest['shadowtex1'] = (val == 'true')
        except ValueError as e:
            problems.append(f'Failed to process const {typ} {key} = {val}  ->  {e}  (directive ignored, default kept)')
    return dict(shadow=sh, sunPathRotation=sun_rot, nearest=nearest, problems=problems)


# ---- uniforms/CelestialUniforms.java ------------------------------------------------------------
def sun_dir_world(sun_angle, sun_path_rotation):
    """celestial = Ry(-90)·Rz(sunPathRotation)·Rx(a)  applied to (0,1,0), a = 360*sunAngle - 90 (degrees)."""
    a = math.radians(360.0 * sun_angle - 90.0); phi = math.radians(sun_path_rotation)
    v = np.array([0.0, math.cos(a), math.sin(a)])                                   # Rx(a)(0,1,0)
    v = np.array([v[0] * math.cos(phi) - v[1] * math.sin(phi), v[0] * math.sin(phi) + v[1] * math.cos(phi), v[2]])  # Rz(phi)
    c, s = math.cos(math.radians(-90)), math.sin(math.radians(-90))                  # Ry(-90) (JOML: x' = x c + z s ; z' = -x s + z c)
    return np.array([v[0] * c + v[2] * s, v[1], -v[0] * s + v[2] * c])


# ---- shadows/ShadowMatrices.java ----------------------------------------------------------------
def _rx(d): c, s = math.cos(math.radians(d)), math.sin(math.radians(d)); return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1.0]])
def _rz(d): c, s = math.cos(math.radians(d)), math.sin(math.radians(d)); return np.array([[c, -s, 0, 0], [s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1.0]])
def _t(v): m = np.eye(4); m[:3, 3] = v; return m

def java_float_rem(a, b): return math.fmod(a, b)          # Java % on floats keeps the dividend's sign

def shadow_model_view(shadow_angle, sun_path_rotation, interval, cam):
    sky = shadow_angle + 0.75 if shadow_angle < 0.25 else shadow_angle - 0.25
    m = _rx(90.0) @ _rz(sky * -360.0) @ _rx(sun_path_rotation)
    if abs(interval) != 0.0:
        off = [java_float_rem(float(c), interval) - interval / 2.0 for c in cam]
        m = m @ _t(off)                                     # translate AFTER the rotations (post-multiply)
    return m

def shadow_ortho(half_plane, near=SHADOW_NEAR, far=SHADOW_FAR):
    """JOML setOrthoSymmetric(2h, 2h, near, far), OpenGL depth range."""
    p = np.eye(4); p[0, 0] = 1 / half_plane; p[1, 1] = 1 / half_plane
    p[2, 2] = -2.0 / (far - near); p[2, 3] = -(far + near) / (far - near)
    return p


def selftest(root=None):
    ok = True
    def chk(name, cond, detail=''):
        nonlocal ok; ok &= bool(cond); print(('PASS ' if cond else 'FAIL ') + name + (f'   {detail}' if detail else ''))
    # 1) Java number parsing
    for s, good in (('128', True), ('128.0', True), ('1e2', True), ('float(128)', False), ('SHADOW_DISTANCE', False), (' 160.0 ', True)):
        try: java_parse_float(s); r = True
        except ValueError: r = False
        chk(f'Float.parseFloat("{s.strip()}") -> {"ok" if good else "NumberFormatException"}', r == good)
    # 2) ConstDirectiveParser
    chk('directive: "const float shadowDistance = float(128);"', find_directive_in_line('const float shadowDistance = float(128);  // x') == ('float', 'shadowDistance', 'float(128)'))
    chk('directive: indented / spaced', find_directive_in_line('   const   int   shadowMapResolution = 2048;') == ('int', 'shadowMapResolution', '2048'))
    chk('not a directive: float x = 1;', find_directive_in_line('float x = 1.0;') is None)
    # 3) shadow-view +Z (toward the light) must equal the celestial direction for the same angle.
    #    Day uses the sun angle, night the moon angle (= sun angle + 0.5 in vanilla); same function either way.
    worst = 0.0
    for phi in (-25.0, 0.0, 30.0):
        for t in np.linspace(0.0, 0.999, 41):
            M = shadow_model_view(float(t), phi, 0.0, (0, 0, 0))
            worst = max(worst, 1 - float(np.dot(M[2, :3], sun_dir_world(float(t), phi))))
    chk('shadow-view +Z == celestial direction (3 tilts x 41 angles, day+night)', worst < 1e-9, f'worst 1-cos = {worst:.2e}')
    # 4) projection numbers from Iris's own unit test (ShadowMatrices.Tests: hpl=32 / near .05 far 256)
    P = shadow_ortho(32.0, 0.05, 256.0)
    chk('ortho hpl=32 matches Iris test (0.03125, -0.0078140264, -1.00039065)', abs(P[0, 0] - 0.03125) < 1e-7 and abs(P[2, 2] + 0.007814026437699795) < 1e-7 and abs(P[2, 3] + 1.000390648841858) < 1e-6)
    # 5) pack checks (optional)
    if root:
        d = pack_directives(root, {'EIQ_LEVEL': 3})
        print('   pack directives ->', {k: v for k, v in d.items() if k != 'problems'})
        for p in d['problems']: print('   IRIS WOULD LOG:', p)
    print('ALL PASS' if ok else 'SOME FAILED'); return ok

if __name__ == '__main__':
    import sys
    selftest(sys.argv[1] if len(sys.argv) > 1 else None)
