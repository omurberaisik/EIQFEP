import sys, numpy as np
from PIL import Image
tag=sys.argv[1]
def hsv_s(a):
    mx=a.max(-1); mn=a.min(-1); return np.where(mx>0,(mx-mn)/np.maximum(mx,1e-6),0)
for n in sys.argv[2].split(','):
    a=np.asarray(Image.open(f'out/{tag}_{n}.png'),float)/255
    sky=a[:90,:]; gnd=a[-120:,:]
    L=a@[0.2126,0.7152,0.0722]
    print(f'{n:9s} skyRGB={np.round(sky.reshape(-1,3).mean(0),3)} skySat={hsv_s(sky).mean():.3f} allSat={hsv_s(a).mean():.3f} '
          f'p5={np.percentile(L,5):.3f} p50={np.percentile(L,50):.3f} p95={np.percentile(L,95):.3f} gndL={L[-120:].mean():.3f}')
