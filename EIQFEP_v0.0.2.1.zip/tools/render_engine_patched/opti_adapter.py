"""OptiFine/Iris-style pack loader: properties, profiles, enabled programs, DRAWBUFFERS, custom uniforms,
block ids and the GLSL 120 -> 330 core source transformation (what Iris' TransformPatcher does).
"""
import os, re, math
import numpy as np
import iris_port as IP

RENDER_STAGES = ['NONE', 'SKY', 'SUNSET', 'CUSTOM_SKY', 'SUN', 'MOON', 'STARS', 'VOID', 'TERRAIN_SOLID',
                 'TERRAIN_CUTOUT_MIPPED', 'TERRAIN_CUTOUT', 'ENTITIES', 'BLOCK_ENTITIES', 'DESTROY', 'OUTLINE', 'DEBUG',
                 'HAND_SOLID', 'TERRAIN_TRANSLUCENT', 'TRIPWIRE', 'PARTICLES', 'CLOUDS', 'RAIN_SNOW', 'WORLD_BORDER',
                 'HAND_TRANSLUCENT']       # pipeline/WorldRenderingPhase.java (ordinal = macro value)
FORMAT_NAMES = ['R11F_G11F_B10F', 'RGBA16', 'RGBA8', 'RGBA16F', 'RGBA32F', 'R8', 'RG16F', 'RGB8', 'RGB16F', 'RGB10_A2', 'RGB16', 'R16F', 'R32F']


def rd(path):
    return open(path, encoding='utf-8', errors='replace').read().replace('\r\n', '\n').replace('\r', '\n')


# --------------------------------------------------------------------------- properties
def parse_properties(text, defs=None):
    """Java .properties with '\\' continuation, '#' comments and Iris' #if/#else preprocessing (no macro expansion)."""
    lines, cur = [], ''
    for ln in text.split('\n'):
        if ln.rstrip().endswith('\\'): cur += ln.rstrip()[:-1] + ' '; continue
        lines.append(cur + ln); cur = ''
    txt = '\n'.join(lines)
    txt = IP.preprocess(txt, defs or {}, expand_text=False)
    props = {}
    for ln in txt.split('\n'):
        s = ln.strip()
        if not s or s.startswith('#'): continue
        if '=' not in s: continue
        k, v = s.split('=', 1); props[k.strip()] = v.strip()
    return props


def resolve_profile(props, name, seen=None):
    seen = seen or set(); out = []
    if name in seen: return out
    seen.add(name)
    for tok in props.get(f'profile.{name}', '').split():
        if tok.startswith('profile.'): out += resolve_profile(props, tok[len('profile.'):], seen)
        else: out.append(tok)
    return out


def apply_overrides(text, tokens):
    """tokens: 'NAME' (on), '!NAME' (off), 'NAME=value' (set).  Mirrors how Iris applies option values."""
    for t in tokens:
        if '=' in t:
            k, v = t.split('=', 1)
            text = re.sub(rf'(?m)^(\s*)#define {re.escape(k)}\b[^\n/]*', rf'\g<1>#define {k} {v} ', text, count=1)
            text = re.sub(rf'(?m)^(\s*const\s+(?:int|float|bool)\s+{re.escape(k)}\s*=\s*)[^;]+;', rf'\g<1>{v};', text, count=1)
        elif t.startswith('!'):
            k = t[1:]
            text = re.sub(rf'(?m)^(\s*)#define {re.escape(k)}\b([^\n]*)', rf'\g<1>//#define {k}\g<2>', text, count=1)
        else:
            text = re.sub(rf'(?m)^(\s*)//\s*#define {re.escape(t)}\b([^\n]*)', rf'\g<1>#define {t}\g<2>', text, count=1)
    return text


# ----------------------------------------------------------------- custom uniform expressions
_TOK = re.compile(r'\s*(\d+\.\d*|\.\d+|\d+|[A-Za-z_][A-Za-z0-9_.]*|&&|\|\||==|!=|<=|>=|[()+\-*/%<>!,])')

class Expr:
    def __init__(self, text, env):
        self.t = [m.group(1) for m in _TOK.finditer(text)]; self.i = 0; self.env = env
    def peek(self): return self.t[self.i] if self.i < len(self.t) else None
    def eat(self): v = self.peek(); self.i += 1; return v
    def parse(self): v = self.oror(); return v
    def oror(self):
        v = self.andand()
        while self.peek() == '||': self.eat(); r = self.andand(); v = 1.0 if (v or r) else 0.0
        return v
    def andand(self):
        v = self.eq()
        while self.peek() == '&&': self.eat(); r = self.eq(); v = 1.0 if (v and r) else 0.0
        return v
    def eq(self):
        v = self.cmp()
        while self.peek() in ('==', '!='):
            o = self.eat(); r = self.cmp(); v = 1.0 if ((v == r) == (o == '==')) else 0.0
        return v
    def cmp(self):
        v = self.add()
        while self.peek() in ('<', '>', '<=', '>='):
            o = self.eat(); r = self.add()
            v = 1.0 if {'<': v < r, '>': v > r, '<=': v <= r, '>=': v >= r}[o] else 0.0
        return v
    def add(self):
        v = self.mul()
        while self.peek() in ('+', '-'):
            o = self.eat(); r = self.mul(); v = v + r if o == '+' else v - r
        return v
    def mul(self):
        v = self.un()
        while self.peek() in ('*', '/', '%'):
            o = self.eat(); r = self.un()
            v = v * r if o == '*' else (v / r if r else 0.0) if o == '/' else (math.fmod(v, r) if r else 0.0)
        return v
    def un(self):
        if self.peek() == '-': self.eat(); return -self.un()
        if self.peek() == '!': self.eat(); return 0.0 if self.un() else 1.0
        return self.prim()
    def prim(self):
        t = self.eat()
        if t is None: return 0.0
        if t == '(': v = self.oror(); self.eat(); return v
        if re.match(r'^[\d.]', t): return float(t)
        if self.peek() == '(':
            self.eat(); args = []
            if self.peek() != ')':
                while True:
                    args.append(self.oror())
                    if self.peek() == ',': self.eat(); continue
                    break
            self.eat(); return self.call(t, args)
        return float(self.env.get(t, -1.0 if t.startswith('BIOME_') else 0.0))
    def call(self, f, a):
        F = {'frac': lambda x: x - math.floor(x), 'clamp': lambda x, lo, hi: min(max(x, lo), hi), 'abs': abs, 'max': max, 'min': min,
             'sin': math.sin, 'cos': math.cos, 'floor': math.floor, 'ceil': math.ceil, 'sqrt': lambda x: math.sqrt(max(x, 0)),
             'pow': lambda x, y: abs(x) ** y, 'exp': math.exp, 'if': lambda c, x, y: x if c else y,
             'smooth': lambda i, v, up=0, dn=0: v, 'in': lambda x, *l: 1.0 if x in l else 0.0, 'round': round, 'sign': lambda x: (x > 0) - (x < 0)}
        if f == 'if' and len(a) == 3: return a[1] if a[0] else a[2]
        if f == 'if' and len(a) >= 3 and len(a) % 2 == 1:      # if(c1, v1, c2, v2, ..., else)
            for i in range(0, len(a) - 1, 2):
                if a[i]: return a[i + 1]
            return a[-1]
        try: return float(F[f](*a))
        except Exception: return 0.0


# ------------------------------------------------------------------------------- the pack
class OptiPack:
    def __init__(self, shaders_root, profile=None, overrides=None, dim=0, mc_version=12111):
        self.root = shaders_root; self.dim = dim; self.dimdir = {0: 'world0', 1: 'world1', -1: 'world-1'}[dim]
        self.mc_version = mc_version
        self._raw_props = rd(f'{shaders_root}/shaders.properties')
        p0 = parse_properties(self._raw_props, self._std_defs())
        self.tokens = []
        if profile: self.tokens += resolve_profile(p0, profile)
        self.tokens += list(overrides or [])
        self._src_cache = {}
        self.defs = self.macro_state()
        self.props = parse_properties(self._raw_props, {**self._std_defs(), **self.defs})
        self._directives = None

    def _std_defs(self):
        d = IP.standard_defines(self.mc_version)
        for i, n in enumerate(RENDER_STAGES): d[f'MC_RENDER_STAGE_{n}'] = str(i)
        d['MC_GL_VENDOR_OTHER'] = ''; d['MC_GL_RENDERER_MESA'] = ''; d['MC_OS_LINUX'] = ''
        for i, n in enumerate(FORMAT_NAMES): d[n] = str(i)
        return d

    # --- sources
    def _expand(self, path):
        out = []
        txt = rd(path)
        if path.endswith('settings.glsl'): txt = apply_overrides(txt, self.tokens)
        for ln in txt.split('\n'):
            m = re.match(r'\s*#include\s+"([^"]+)"', ln)
            if m:
                inc = m.group(1)
                target = self.root + inc if inc.startswith('/') else os.path.normpath(os.path.join(os.path.dirname(path), inc))
                out.append(self._expand(target))
            else: out.append(ln)
        return '\n'.join(out)

    def source(self, name, stage):
        k = (name, stage)
        if k not in self._src_cache:
            p = f'{self.root}/{self.dimdir}/{name}.{stage}'
            self._src_cache[k] = self._expand(p) if os.path.exists(p) else None
        return self._src_cache[k]

    def macro_state(self):
        d = {}
        src = self._expand(f'{self.root}/{self.dimdir}/composite.fsh')
        IP.preprocess(src, self._std_defs(), defs_out=d)
        return d

    def preprocessed(self, name, stage='fsh'):
        return IP.preprocess(self.source(name, stage), self._std_defs())

    # --- program table
    def enabled(self, name):
        for key in (f'program.{self.dimdir}/{name}.enabled', f'program.{name}.enabled'):
            if key in self.props:
                expr = self.props[key]
                e = re.sub(r'\b([A-Za-z_]\w*)\b', lambda m: '1' if (m.group(1) in self.defs) else '0', expr)
                e = e.replace('&&', ' and ').replace('||', ' or '); e = re.sub(r'!(?!=)', ' not ', e)
                try: return bool(eval(e, {}, {}))
                except Exception: return True
        return True

    def drawbuffers(self, name):
        pre = self.preprocessed(name, 'fsh')
        ms = re.findall(r'/\*\s*DRAWBUFFERS:\s*([0-9A-Fa-f]*)\s*\*/', pre)      # Iris: lastIndexOf
        return [int(c, 16) for c in ms[-1]] if ms else [0]

    def chain(self, prefix):
        names = [prefix] + [f'{prefix}{i}' for i in range(1, 16)]
        return [n for n in names if self.source(n, 'fsh') is not None and self.enabled(n)]

    def alpha_test(self, name, default=None):
        v = self.props.get(f'alphaTest.{name}')
        if v is None: return default
        v = v.split()
        if v[0].lower() == 'off': return None
        try: return (v[0].upper(), float(v[1]))
        except Exception: return default

    # --- const directives (union over every fragment program, like Iris' ProgramSet)
    def directives(self):
        if self._directives: return self._directives
        files = sorted(f[:-4] for f in os.listdir(f'{self.root}/{self.dimdir}') if f.endswith('.fsh'))
        found = []
        for n in files:
            try: found += IP.find_directives(IP.preprocess(self.source(n, 'fsh'), self._std_defs()))
            except Exception: pass
        sh = dict(IP.DEFAULT_SHADOW); sun = IP.DEFAULT_SUN_PATH_ROTATION; mip = set(); noclear = set(); problems = []; hw = {}
        for typ, key, val in found:
            try:
                if key == 'shadowMapResolution': sh['resolution'] = IP.java_parse_int(val)
                elif key == 'shadowDistance': sh['distance'] = IP.java_parse_float(val)
                elif key == 'shadowIntervalSize': sh['intervalSize'] = IP.java_parse_float(val)
                elif key == 'sunPathRotation': sun = IP.java_parse_float(val)
                elif re.match(r'colortex\d+MipmapEnabled', key) and val == 'true': mip.add(int(re.findall(r'\d+', key)[0]))
                elif re.match(r'colortex\d+Clear$', key) and val == 'false': noclear.add(int(re.findall(r'\d+', key)[0]))
                elif key.startswith('shadowHardwareFiltering'): hw[key] = (val == 'true')
            except ValueError as e:
                problems.append(f'const {typ} {key} = {val} -> {e}')
        self._directives = dict(shadow=sh, sunPathRotation=sun, mipmap=mip, noclear=noclear, problems=problems, hw=hw)
        return self._directives

    # --- block ids
    def block_ids(self):
        txt = parse_properties(rd(f'{self.root}/block.properties'), {**self._std_defs(), **self.defs})
        table = {}
        for k, v in txt.items():
            m = re.match(r'block\.(\d+)$', k)
            if not m: continue
            for tok in v.split():
                name = tok.split(':')
                nm = name[1] if len(name) > 1 and name[0] == 'minecraft' else name[0]
                table.setdefault(nm, int(m.group(1)))        # first entry wins
        return table

    # --- textures declared in properties
    def custom_textures(self):
        out = []
        for k, v in self.props.items():
            m = re.match(r'texture\.(?:(\w+)\.)?(\w+)$', k)
            if m and not k.startswith('texture.world'): out.append((m.group(1), m.group(2), v.split()[0]))
        return out

    # --- custom uniforms
    def custom_uniforms(self, state):
        env = dict(state); lines = []
        raw = parse_properties(self._raw_props, {**self._std_defs(), **self.defs})
        # properties are order dependent; re-read raw order
        order = []
        for ln in re.sub(r'\\\n', ' ', self._raw_props).split('\n'):
            pass
        txt = IP.preprocess(re.sub(r'\\\s*\n', ' ', self._raw_props), {**self._std_defs(), **self.defs}, expand_text=False)
        out = {}
        for ln in txt.split('\n'):
            m = re.match(r'\s*(variable|uniform)\.(float|int|bool|vec2|vec3|vec4)\.(\w+)\s*=\s*(.+)$', ln)
            if not m: continue
            kind, typ, name, ex = m.groups()
            try: v = Expr(ex, env).parse()
            except Exception: v = 0.0
            env[name] = v
            if kind == 'uniform': out[name] = v
        return out


# ----------------------------------------------------- fixed-function alpha test (Iris AlphaTest / ShaderKey)
def _main_end(s):
    m = re.search(r'void\s+main\s*\(\s*(?:void)?\s*\)\s*\{', s)
    if not m: return None
    i, depth, n = m.end(), 1, len(s)
    while i < n and depth:
        c = s[i]
        if s.startswith('//', i):
            j = s.find('\n', i); i = n if j == -1 else j; continue
        if s.startswith('/*', i):
            j = s.find('*/', i + 2); i = n if j == -1 else j + 2; continue
        depth += (c == '{') - (c == '}'); i += 1
    return i - 1            # index of main's closing brace

def inject_alpha(s, op, ref):
    end = _main_end(s)
    if end is None or op in (None, 'ALWAYS'): return s
    cond = {'GREATER': f'!(iris_out0.a > {ref})', 'GEQUAL': f'!(iris_out0.a >= {ref})', 'LESS': f'!(iris_out0.a < {ref})',
            'LEQUAL': f'!(iris_out0.a <= {ref})', 'EQUAL': f'!(iris_out0.a == {ref})', 'NOTEQUAL': f'!(iris_out0.a != {ref})', 'NEVER': 'true'}[op]
    return s[:end] + f'\n    if ({cond}) discard;\n' + s[end:]


# ------------------------------------------------------- GLSL 1.20 -> 3.30 core (Iris TransformPatcher analogue)
FS_PRELUDE = 'vec4 shadow2D(sampler2DShadow s, vec3 c) { return vec4(texture(s, c)); }\n'

def to_core(src, stage, prelude_vs='', alpha=None):
    s = src
    s = re.sub(r'(?m)^[ \t]*#extension[^\n]*$', '', s)
    s = re.sub(r'(?m)^[ \t]*//[ \t]*#include[^\n]*$', '', s)       # Mesa's glcpp trips over commented-out includes
    s, n = re.subn(r'(?m)^[ \t]*#version[^\n]*$', '#version 330 core\n' + ''.join(f'#define {nm} {i}\n' for i, nm in enumerate(FORMAT_NAMES)), s, count=1)
    if n == 0: s = '#version 330 core\n' + s
    # reserved / renamed identifiers
    if re.search(r'uniform\s+sampler2D\s+tex\s*;', s): s = re.sub(r'\btex\b', 'gtexture', s)
    s = re.sub(r'\b(texture|gcolor)\b(?!\s*\()', 'gtexture', s)
    s = s.replace('texture2DGradARB(', 'textureGrad(').replace('texture2DGrad(', 'textureGrad(').replace('texture2DLodARB(', 'textureLod(').replace('texture2DLod(', 'textureLod(').replace('texture2DProj(', 'textureProj(').replace('texture2D(', 'texture(')
    if stage == 'vsh':
        s = re.sub(r'\bvarying\b', 'out', s); s = re.sub(r'\battribute\b', 'in', s)
        s = s.replace('#version 330 core\n', '#version 330 core\n' + prelude_vs, 1)
    else:
        s = re.sub(r'\bvarying\b', 'in', s)
        idx = sorted({int(i) for i in re.findall(r'gl_FragData\[(\d+)\]', s)})
        s = re.sub(r'gl_FragData\[(\d+)\]', r'iris_out\1', s)
        if 'gl_FragColor' in s: s = s.replace('gl_FragColor', 'iris_out0'); idx = sorted(set(idx) | {0})
        decl = ''.join(f'layout(location = {i}) out vec4 iris_out{i};\n' for i in idx)
        s = s.replace('#version 330 core\n', '#version 330 core\n' + FS_PRELUDE + decl, 1) if False else re.sub(r'(#version 330 core\n(?:#define [A-Z0-9_]+ \d+\n)*)', lambda m: m.group(1) + FS_PRELUDE + decl, s, count=1)
    if stage == 'fsh' and alpha: s = inject_alpha(s, alpha[0], alpha[1])
    return s
