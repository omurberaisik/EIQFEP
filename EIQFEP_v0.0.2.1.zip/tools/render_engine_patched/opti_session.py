"""Runs an OptiFine-style pack (BSL) in the mini engine: sky -> terrain -> deferred* -> water -> composite* -> final."""
import os, re, time, math
import numpy as np, moderngl
from PIL import Image
import engine as E
import iris_port as IP
import opti_adapter as OA
from engine import LAYOUT, ATTRS
FPS = 24


class OptiSession:
    def __init__(self, eng, pack, tag='x', alias_lighttex=True):
        self.eng = eng; self.pk = pack; ctx = eng.ctx; w, h = eng.w, eng.h
        self.d = pack.directives()
        self.sres = int(self.d['shadow']['resolution']); self.sdist = float(self.d['shadow']['distance'])
        self.shadow_params = dict(dist=self.sdist, interval=self.d['shadow']['intervalSize'], near=self.d['shadow']['near'],
                                  far=self.d['shadow']['far'], phi=self.d['sunPathRotation'])
        # which programs run, and which buffers they touch
        self.deferred = pack.chain('deferred'); self.composite = pack.chain('composite')
        used = {0, 1, 2}
        for n in self.deferred + self.composite + ['gbuffers_terrain', 'gbuffers_water', 'gbuffers_skybasic', 'final']:
            used |= set(pack.drawbuffers(n))
            for m in re.findall(r'uniform\s+sampler2D\s+colortex(\d+)', pack.preprocessed(n, 'fsh')): used.add(int(m))
        self.nbuf = max(used) + 1
        self.mip = set(self.d['mipmap'])
        self.main = [eng.tex((w, h), 'f2', mip=(i in self.mip)) for i in range(self.nbuf)]
        self.alt = [eng.tex((w, h), 'f2', mip=(i in self.mip)) for i in range(self.nbuf)]
        self.dirty = set(range(self.nbuf))
        self.depth = eng.depth_tex((w, h)); self.dc0 = eng.depth_tex((w, h)); self.dc1 = eng.depth_tex((w, h))
        self.out_tex = ctx.texture((w, h), 4); self.out_fbo = ctx.framebuffer([self.out_tex])
        sr = self.sres
        self.sh0 = eng.depth_tex((sr, sr), linear=True); self.sh1 = eng.depth_tex((sr, sr), linear=True)
        self.shc = ctx.texture((sr, sr), 4); self.shc.filter = (moderngl.LINEAR, moderngl.LINEAR)
        self.sfbo = ctx.framebuffer([self.shc], depth_attachment=self.sh0)
        self.dummy3d = ctx.texture3d((1, 1, 1), 4, bytes(4))
        self.dummy_depth = eng.depth_tex((4, 4))
        # custom textures (shaders.properties: texture.noise=..., texture.composite.colortex7=...)
        self.custom = {}
        for stage, samp, path in pack.custom_textures():
            im = Image.open(f'{pack.root}/{path}').convert('RGBA')
            t = ctx.texture(im.size, 4, np.asarray(im).tobytes()); t.filter = (moderngl.LINEAR, moderngl.LINEAR); t.repeat_x = t.repeat_y = True
            self.custom[(stage, samp)] = t
        yy, xx = np.mgrid[0:32, 0:32]; cx = (xx - 15.5) / 15.5; cy = (yy - 15.5) / 15.5
        d = np.maximum(abs(cx), abs(cy)); sun = np.zeros((32, 32, 4)); sun[..., :3] = (255, 252, 225)
        sun[..., 3] = 255 * np.clip(1 - (d / 0.98) ** 8, 0, 1)
        r = np.hypot(cx, cy); rng = np.random.RandomState(5); moon = np.zeros((32, 32, 4)); moon[..., :3] = (232, 236, 248)
        moon[..., :3] -= (rng.rand(32, 32, 1) < 0.10) * 35; moon[..., 3] = 255 * np.clip((0.86 - r) / 0.06, 0, 1)
        self.sky_tex = {}
        for nm, a in (('sun', sun), ('moon', moon)):
            tx = ctx.texture((32, 32), 4, np.clip(a, 0, 255).astype(np.uint8).tobytes()); tx.filter = (moderngl.LINEAR, moderngl.LINEAR); self.sky_tex[nm] = tx
        self._gtex_override = None
        self.progs = {}; self.vaos = {}; self.tm = None; self._last = 0.0
        self.sky_vbo = None
        self.problems = list(self.d['problems'])

    # -------------------------------------------------------------------- programs
    DEFAULT_ALPHA = {'gbuffers_terrain': ('GREATER', 0.5), 'gbuffers_water': ('GREATER', 0.0001)}   # Iris ShaderKey defaults (Sodium path)

    def program(self, name, alpha='auto'):
        key = (name, alpha)
        if key not in self.progs:
            if alpha == 'auto': alpha = self.pk.alpha_test(name, self.DEFAULT_ALPHA.get(name))
            vs = OA.to_core(self.pk.source(name, 'vsh'), 'vsh', E.VS_PRELUDE)
            fs = OA.to_core(self.pk.source(name, 'fsh'), 'fsh', alpha=alpha)
            try: prog = self.eng.ctx.program(vertex_shader=vs, fragment_shader=fs)
            except Exception as e:
                self.eng.compile_log.append((name, 0, str(e)[:700])); raise
            self.progs[key] = (prog, self.pk.drawbuffers(name))
        return self.progs[key]

    def vao(self, prog, key):
        k = (id(prog), key)
        if k not in self.vaos:
            vb, ib, n = self.eng.mesh[key]
            self.vaos[k] = (self.eng.ctx.vertex_array(prog, [(vb, LAYOUT, *ATTRS)], index_buffer=ib, skip_errors=True), n)
        return self.vaos[k]

    def bind(self, prog, stage_name, bound_extra=None):
        u = 0
        for name in list(prog):
            m = prog[name]
            if not hasattr(m, 'value') or m.__class__.__name__ != 'Uniform': continue
            tex = None
            mm = re.match(r'colortex(\d+)$', name); ga = re.match(r'gaux(\d)$', name)
            if mm:
                i = int(mm.group(1))
                tex = self.custom.get(('composite', name)) if (stage_name.startswith('composite') and ('composite', name) in self.custom) else (self.main[i] if i < self.nbuf else self.eng.dummy)
            elif ga: i = 3 + int(ga.group(1)); tex = self.main[i] if i < self.nbuf else self.eng.dummy
            elif name == 'depthtex0': tex = self.dc0
            elif name in ('depthtex1', 'depthtex2'): tex = self.dc1
            elif name == 'shadowtex0': tex = self.sh0
            elif name == 'shadowtex1': tex = self.sh1
            elif name == 'shadowcolor0': tex = self.shc
            elif name in ('gtexture',): tex = self._gtex_override or self.eng.gtex
            elif name == 'noisetex': tex = self.custom.get((None, 'noise'), self.eng.dummy)
            elif name in ('normals', 'specular', 'shadowcolor1'): tex = self.eng.dummy
            elif name.startswith('lighttex'): tex = self.dummy3d
            elif name.startswith(('dhDepth', 'vxDepth')): tex = self.dummy_depth
            if tex is None: continue
            tex.use(u); m.value = u; u += 1

    def dump(self, name, t=0):
        if not getattr(self, 'debug', None) is not None: return
        a = np.frombuffer(self.main[t].read(), 'f2').reshape(self.eng.h, self.eng.w, 4).astype(np.float32)[::-1, :, :3]
        self.debug[name] = a

    def tick(self, name):
        if self.tm is None: return
        self.eng.ctx.finish(); now = time.perf_counter()
        self.tm[name] = self.tm.get(name, 0.0) + now - self._last; self._last = now

    def extras(self, U, cam, sky, fnum, sd):
        w, h = self.eng.w, self.eng.h
        t = sky['sunAngle']; sy = float(sd[1])
        dayf = float(np.clip(sy * 2.2 + 0.55, 0.18, 1.0))
        cu = self.pk.custom_uniforms({'sunAngle': t, 'blindness': 0.0, 'frameCounter': fnum, 'cameraPosition.x': cam['pos'][0],
                                      'cameraPosition.y': cam['pos'][1], 'cameraPosition.z': cam['pos'][2], 'biome': 1, 'rainStrength': sky.get('rain', 0.0)})
        e = dict(cu)
        e.update(worldTime=int((t * 24000) % 24000), worldDay=0, aspectRatio=w / h, centerDepthSmooth=0.5, screenBrightness=1.0,
                 eyeBrightness=(0, 240), heightLimit=384, bedrockLevel=-64, cloudHeight=192.0, relativeEyePosition=(0.0, 0.0, 0.0),
                 cameraPositionFract=tuple(np.array(cam['pos']) - np.floor(np.array(cam['pos']))), atlasSize=(128, 128), entityId=0,
                 darknessLightFactor=0.0, endFlashIntensity=0.0, endFlashPosition=(0.0, 0.0, 0.0), isRightHanded=1, heldItemId=0,
                 heldItemId2=0, heldBlockLightValue2=0, hideGUI=0, playerMood=0.0,
                 skyColor=tuple(np.array((0.47, 0.65, 1.0)) * dayf), fogColor=tuple(np.array((0.75, 0.85, 1.0)) * (dayf if dayf > 0.5 else 0.12)),
                 frameTimeCounter=1000.0 + fnum / FPS, framemod8=float(fnum % 8), framemod2=float(fnum % 2), renderStage=0,
                 isDesert=0.0, isValley=0.0, isCold=cu.get('isCold', 0.0))
        for k, v in e.items(): U.setdefault(k, v)
        U.update({k: v for k, v in cu.items()})
        U['frameTimeCounter'] = 1000.0 + fnum / FPS
        return dayf

    def fs_pass(self, name, U, last=False):
        eng = self.eng; ctx = eng.ctx
        prog, targets = self.program(name)
        for t in sorted(self.mip):
            if t in self.dirty and t < self.nbuf: self.main[t].build_mipmaps(); self.dirty.discard(t)
        eng.set_uniforms(prog, U)
        eng.set_uniforms(prog, {'iris_MV': np.eye(4), 'iris_NM': np.eye(3), 'iris_TM': np.stack([np.eye(4), np.eye(4)]),
                                'iris_P': np.array([[2, 0, 0, -1], [0, 2, 0, -1], [0, 0, 1, 0], [0, 0, 0, 1.0]])})
        self.bind(prog, name)
        fbo = self.out_fbo if last else ctx.framebuffer([self.alt[t] for t in targets])
        fbo.use(); ctx.disable(moderngl.DEPTH_TEST); ctx.disable(moderngl.BLEND)
        eng.fs_vao(prog).render(moderngl.TRIANGLE_STRIP)
        if not last:
            fbo.release()
            for t in targets: self.main[t], self.alt[t] = self.alt[t], self.main[t]; self.dirty.add(t)

    def frame(self, cam, prev, sky, fnum):
        eng = self.eng; ctx = eng.ctx; w, h = eng.w, eng.h
        U, sd = eng.make_uniforms(cam, sky, fnum, shadow=self.shadow_params, prev=prev)
        U['frameTime'] = 1.0 / FPS
        self.extras(U, cam, sky, fnum, sd)
        if self.tm is not None: ctx.finish(); self._last = time.perf_counter()
        # ---- shadow
        sprog, _ = self.program('shadow', ('GREATER', 0.5))          # cutout shadows
        sprog_t, _ = self.program('shadow', ('GREATER', 0.1))        # translucent shadows
        Us = dict(U); Us['iris_MV'] = U['_shadow_MV']; Us['iris_P'] = U['_shadow_P']
        for t in (self.sh0, self.sh1): t.compare_func = ''           # sampler2D access while copying
        self.sfbo.use(); ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'; ctx.disable(moderngl.BLEND)
        ctx.clear(1, 1, 1, 0, depth=1.0)
        eng.set_uniforms(sprog, Us); self.bind(sprog, 'shadow')
        v, n = self.vao(sprog, 'opaque'); v.render(moderngl.TRIANGLES, vertices=n)
        eng.copy_depth(self.sh0, self.sh1)
        self.sfbo.use(); ctx.enable(moderngl.DEPTH_TEST)
        eng.set_uniforms(sprog_t, Us); self.bind(sprog_t, 'shadow')
        v, n = self.vao(sprog_t, 'trans'); v.render(moderngl.TRIANGLES, vertices=n)
        for t in (self.sh0, self.sh1): t.compare_func = '<='        # BSL samples them as sampler2DShadow (hardware filtering)
        self.tick('shadow')
        # ---- clear buffers
        fog = tuple(U['fogColor'])
        for i in range(self.nbuf):
            if i in self.d['noclear']: continue
            f = ctx.framebuffer([self.main[i]]); f.clear(*IP.default_clear_color(i, fog)); f.release(); self.dirty.add(i)
        # ---- sky (gbuffers_skybasic): full-screen triangle strip at depth 1.0
        sp, st = self.program('gbuffers_skybasic')
        if self.sky_vbo is None:
            rows = []
            for (x, y) in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
                r = np.zeros(33, 'f4'); r[0:4] = (x, y, 1.0, 1.0); r[4:8] = (0.5, 0.7, 1.0, 1.0); rows.append(r)
            self.sky_vbo = ctx.buffer(np.stack(rows).tobytes())
        Usky = dict(U); Usky.update({'iris_MV': np.eye(4), 'iris_P': np.eye(4), 'renderStage': 1})
        eng.set_uniforms(sp, Usky); self.bind(sp, 'gbuffers_skybasic')
        sfb = ctx.framebuffer([self.main[t] for t in st]); sfb.use(); ctx.disable(moderngl.DEPTH_TEST); ctx.disable(moderngl.BLEND)
        ctx.vertex_array(sp, [(self.sky_vbo, LAYOUT, *ATTRS)], skip_errors=True).render(moderngl.TRIANGLE_STRIP); sfb.release()
        for t in st: self.dirty.add(t)
        if self.pk.source('gbuffers_skytextured', 'fsh') is not None:
            tp, tt = self.program('gbuffers_skytextured', None)
            V = U['gbufferModelView']; P = U['gbufferProjection']
            tfb = ctx.framebuffer([self.main[x] for x in tt]); tfb.use(); ctx.disable(moderngl.DEPTH_TEST)
            ctx.enable(moderngl.BLEND); ctx.blend_func = moderngl.SRC_ALPHA, moderngl.ONE
            for nm, dirv, half, stage in (('sun', sd, 15.0, 4), ('moon', -sd, 20.0, 5)):
                if dirv[1] < -0.2: continue
                dv = np.array(dirv, float); ax = np.cross(dv, [0, 1, 0]); ax = ax / np.linalg.norm(ax) if np.linalg.norm(ax) > 1e-6 else np.array([1.0, 0, 0]); ay = np.cross(ax, dv)
                c = dv * 100.0; rows = []
                for (sx, sy, u, v) in ((-1, -1, 0, 1), (1, -1, 1, 1), (-1, 1, 0, 0), (1, 1, 1, 0)):
                    r = np.zeros(33, 'f4'); r[0:3] = c + ax * sx * half + ay * sy * half; r[3] = 1; r[4:8] = (1, 1, 1, 1); r[11:15] = (u, v, 0, 1); rows.append(r)
                vb = ctx.buffer(np.stack(rows).tobytes())
                Us2 = dict(U); Us2.update({'iris_MV': V, 'iris_P': P, 'iris_NM': V[:3, :3], 'renderStage': stage})
                eng.set_uniforms(tp, Us2); self._gtex_override = self.sky_tex[nm]; self.bind(tp, 'gbuffers_skytextured')
                ctx.vertex_array(tp, [(vb, LAYOUT, *ATTRS)], skip_errors=True).render(moderngl.TRIANGLE_STRIP); vb.release()
            self._gtex_override = None; ctx.disable(moderngl.BLEND); tfb.release()
            for x in tt: self.dirty.add(x)
        self.tick('sky'); self.dump('after_sky')
        # ---- terrain
        gp, gt = self.program('gbuffers_terrain')
        gfbo = ctx.framebuffer([self.main[t] for t in gt], depth_attachment=self.depth)
        dfb = ctx.framebuffer(depth_attachment=self.depth); dfb.clear(depth=1.0); dfb.release()   # depth only (ctx.clear would also wipe the colour attachments)
        gfbo.use()
        ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'; ctx.disable(moderngl.BLEND)
        Ut = dict(U); Ut['renderStage'] = 8
        eng.set_uniforms(gp, Ut); self.bind(gp, 'gbuffers_terrain')
        v, n = self.vao(gp, 'opaque'); v.render(moderngl.TRIANGLES, vertices=n)
        eng.copy_depth(self.depth, self.dc1); eng.copy_depth(self.depth, self.dc0)
        for t in gt: self.dirty.add(t)
        self.tick('terrain'); self.dump('after_terrain'); self.dump('terrain_buf1', 1) if self.nbuf > 1 else None
        for nme in self.deferred: self.fs_pass(nme, U); self.tick(nme); self.dump('after_' + nme)
        # ---- translucents: every attachment blended (no blend.* overrides in BSL)
        wp, wt = self.program('gbuffers_water')
        Uw = dict(U); Uw['renderStage'] = 17
        eng.set_uniforms(wp, Uw); self.bind(wp, 'gbuffers_water')
        wfbo = ctx.framebuffer([self.main[t] for t in wt], depth_attachment=self.depth)
        wfbo.use(); ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'
        ctx.enable(moderngl.BLEND); ctx.blend_func = moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA, moderngl.ONE, moderngl.ONE_MINUS_SRC_ALPHA
        v, n = self.vao(wp, 'trans'); v.render(moderngl.TRIANGLES, vertices=n)
        ctx.disable(moderngl.BLEND)
        for t in wt: self.dirty.add(t)
        eng.copy_depth(self.depth, self.dc0)
        self.tick('water')
        for nme in self.composite: self.fs_pass(nme, U); self.tick(nme)
        self.fs_pass('final', U, last=True); self.tick('final')
        for f in (gfbo, wfbo): f.release()
        return Image.frombytes('RGBA', (w, h), self.out_fbo.read(components=4)).transpose(Image.FLIP_TOP_BOTTOM).convert('RGB')

    def release(self):
        for t in self.main + self.alt + [self.depth, self.dc0, self.dc1, self.sh0, self.sh1, self.shc, self.out_tex]: t.release()
        self.vaos.clear(); self.progs.clear()
