import sys; sys.path.insert(0,"/home/claude/work")
from sweep_common import *
import traceback
level=int(sys.argv[1]); scn=sys.argv[2]; dim=int(sys.argv[3]) if len(sys.argv)>3 else 0
eng,h=make()
vars_=[];default={}
for l in open('/home/claude/work/pack/lib/settings.glsl'):
    m=re.match(r'#define (\w+)(?: ([^/\n]+?))? *(//\[([^\]]*)\])?\s*$',l)
    if not m or m.group(1) in ('EIQ_SETTINGS','EIQ_LEVEL'): continue
    n,dv,_,lst=m.groups()
    if lst:
        for v in lst.split():
            if v!=dv.strip(): vars_.append((f'{n}={v}',{n:v}))
    elif not dv: vars_.append((f'-{n}',{n:None}))
import os
flt=re.compile(os.environ.get('FLT','.'))
vars_=[v for v in vars_ if flt.search(v[0])]
start=int(sys.argv[4]) if len(sys.argv)>4 else 0
vars_=vars_[start:start+(int(sys.argv[5]) if len(sys.argv)>5 else 999)]
print('variants',len(vars_),flush=True)
root='/home/claude/work/pack/'
b=run(eng,h,root,{},scn,dim,4,level); print('BASE',b,flush=True)
bad=0
for name,o in vars_:
    t=time.time()
    try:
        r=run(eng,h,root,o,scn,dim,4,level)
    except Exception as e:
        print('FAIL',name,str(e)[:300].replace('\n',' '),flush=True); bad+=1; continue
    fl=[]
    if r['nan'] and any(a or b for a,b in r['nan'].values()): fl.append('NAN')
    if r['mean']<0.02: fl.append('BLACK')
    if r['mean']>0.9: fl.append('WHITE')
    if b['mean']>0 and abs(r['mean']-b['mean'])/b['mean']>0.35: fl.append('DIFF')
    if fl: bad+=1
    print(f"{'!!' if fl else 'ok'} {name} mean={r['mean']:.3f} std={r['std']:.3f} {fl} {time.time()-t:.0f}s",flush=True)
print('DONE bad=',bad)
