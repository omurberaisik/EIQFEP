import sys; sys.path.insert(0,"/home/claude/work")
from sweep_common import *
eng,h=make(); root='/home/claude/work/pack/'
cases=[('MB',{'MOTION_BLUR':'ON'}),('MB2',{'MOTION_BLUR':'ON','MOTION_BLUR_STRENGTH':'2.0'}),
 ('RD',{'RAIN_DROPS':'ON'}),('LF',{'LENS_FLARE':'ON'}),('DOF',{'DOF':'ON'}),('DOF2',{'DOF':'ON','DOF_STRENGTH':'2.0'}),
 ('ALL',{'MOTION_BLUR':'ON','RAIN_DROPS':'ON','LENS_FLARE':'ON','DOF':'ON','FILM_GRAIN':'1.5','CHROMA_ABERR':'2.0','VIGNETTE':'0.45'})]
from PIL import Image
for scn in ('noon','rain'):
  b=run(eng,h,root,{},scn,0,4,5)
  for n,o in cases:
    r=run(eng,h,root,o,scn,0,4,5)
    nanbad=r['nan'] and any(a or b_ for a,b_ in r['nan'].values())
    print(scn,n,round(r['mean'],3),round(r['std'],3),'NAN' if nanbad else 'ok',flush=True)
