import sys,json,time; sys.path.insert(0,"/home/claude/work")
import numpy as np
sys.path.insert(0,'/home/claude/work/eng')
import world as Wd, engine as E, session2 as S2
level=int(sys.argv[1]); extra=json.loads(sys.argv[2]) if len(sys.argv)>2 else {}
root=sys.argv[3] if len(sys.argv)>3 else '/home/claude/work/pack/'
B,h,SEA=Wd.build_world(); Sk,BL=Wd.propagate(B); A=Wd.make_atlas()
eng=E.Engine(640,360,A); eng.upload_mesh(Wd.mesh(B,Sk,BL))
cy=float(h[86,6])+14.0
cam=dict(pos=(86.0,cy,6.0),yaw=0.35,pitch=-0.12,fov=70); sky=dict(sunAngle=0.19)
s=S2.Session(eng,root,{'EIQ_LEVEL':level,**extra},0,'pf')
for k in range(3): s.frame(cam,cam,sky,k)        # warm up (compile)
s.tm={}; s._last=time.perf_counter(); N=6
for k in range(3,3+N): img=s.frame(cam,cam,sky,k)
if len(sys.argv)>4: img.save(sys.argv[4])
tot=sum(s.tm.values())
print('L',level,extra,'total %.0f ms/frame'%(tot/N*1000))
for n,t in sorted(s.tm.items(),key=lambda x:-x[1]): print('  %-12s %6.0f ms %4.1f%%'%(n,t/N*1000,100*t/tot))
