import sys, os, time
sys.path.insert(0,'/home/claude/work/eng')
import numpy as np
import world as Wd, engine as E, session2 as S2
root = sys.argv[1]; tag = sys.argv[2]; level = int(sys.argv[3]) if len(sys.argv)>3 else 3
scenes = sys.argv[4].split(',') if len(sys.argv)>4 else ['noon','water','sunset','night']
B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); A = Wd.make_atlas()
eng = E.Engine(960,540,A)
cy = float(h[86,6])+14.0
SC = {'noon':(dict(pos=(86.0,cy,6.0),yaw=0.35,pitch=-0.12,fov=70),dict(sunAngle=0.19)),
      'water':(dict(pos=(100.0,66.0,56.0),yaw=0.10,pitch=-0.07,fov=70),dict(sunAngle=0.36)),
      'sunset':(dict(pos=(86.0,cy,6.0),yaw=-1.15,pitch=-0.02,fov=70),dict(sunAngle=0.455)),
      'dusk':(dict(pos=(86.0,cy,6.0),yaw=-1.15,pitch=0.04,fov=70),dict(sunAngle=0.487)),
      'sunrise':(dict(pos=(86.0,cy,6.0),yaw=-1.15+3.14159,pitch=0.04,fov=70),dict(sunAngle=0.016)),
      'overcast':(dict(pos=(86.0,cy,6.0),yaw=0.35,pitch=-0.12,fov=70),dict(sunAngle=0.19,rain=1.0,wet=1.0,fog=(0.55,0.6,0.65))),
      'night':(dict(pos=(86.0,cy,6.0),yaw=0.35,pitch=-0.12,fov=70),dict(sunAngle=0.80,fog=(0.02,0.03,0.07)))}
eng.upload_mesh(Wd.mesh(B,Sk,BL))
for n in scenes:
    cam,sky = SC[n]; t=time.time()
    try:
        img,ex = S2.render_static(eng,root+'/',cam,sky,frames=14,opts={'EIQ_LEVEL':level, **(__import__('json').loads(__import__('os').environ.get('EXTRA','{}')))},tag=tag+n)
    except Exception as e:
        import traceback; traceback.print_exc(); continue
    img.save(f'out/{tag}_{n}.png'); a=np.asarray(img,float)/255
    print(n,f'{time.time()-t:.1f}s exp={ex:.3f} mean={a.mean():.3f} p99={np.percentile(a,99):.3f} clip={(a.max(2)>0.99).mean():.3f}',flush=True)
