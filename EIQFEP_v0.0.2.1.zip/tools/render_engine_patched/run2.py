import sys, time
sys.path.insert(0,'/home/claude/work/eng')
import numpy as np
import world as Wd, engine as E, session2 as S2
root=sys.argv[1]; tag=sys.argv[2]; level=int(sys.argv[3]); scenes=sys.argv[4].split(',')
B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); A = Wd.make_atlas()
eng = E.Engine(960,540,A)
cy = float(h[86,6])+14.0
P=(86.0,cy,6.0)
SC = {
 'end_sky':  (1, dict(pos=P,yaw=0.0,pitch=0.62,fov=75), dict(sunAngle=0.25,fog=(0.08,0.05,0.10),eyeSky=0), 'dark'),
 'end_land': (1, dict(pos=P,yaw=0.0,pitch=0.08,fov=75), dict(sunAngle=0.25,fog=(0.08,0.05,0.10),eyeSky=0), 'dark'),
 'neth_red': (-1,dict(pos=P,yaw=0.0,pitch=0.15,fov=75), dict(sunAngle=0.25,fog=(0.20,0.03,0.03),eyeSky=0), 'dark'),
 'neth_sky': (-1,dict(pos=(86.0,cy+60,6.0),yaw=0.0,pitch=0.45,fov=75), dict(sunAngle=0.25,fog=(0.20,0.03,0.03),eyeSky=0), 'dark'),
 'neth_warp':(-1,dict(pos=P,yaw=0.35,pitch=-0.10,fov=70), dict(sunAngle=0.25,fog=(0.08,0.04,0.16),eyeSky=0), 'dark'),
}
cur=None
for n in scenes:
    dim,cam,sky,mode=SC[n]
    M = Wd.mesh(B, np.zeros_like(Sk) if mode=='dark' else Sk, BL)
    eng.upload_mesh(M); t=time.time()
    try:
        img,ex = S2.render_static(eng,root+'/',cam,sky,frames=14,opts={'EIQ_LEVEL':level, **(__import__('json').loads(sys.argv[5]) if len(sys.argv)>5 else {})},tag=tag+n,dim=dim)
    except Exception as e:
        import traceback; traceback.print_exc(); print(eng.compile_log[-2:]); continue
    img.save(f'out/{tag}_{n}.png'); a=np.asarray(img,float)/255
    print(n,f'{time.time()-t:.1f}s exp={ex:.3f} mean={a.mean():.3f} p99={np.percentile(a,99):.3f}',flush=True)
