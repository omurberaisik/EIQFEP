"""Generic pack session: discovers composite chain / render targets from the pack files."""
import os, re, time, numpy as np, moderngl
from PIL import Image
import engine as E
import iris_port as IP
from engine import SAMPLERS, LAYOUT, ATTRS
FPS = 24
NBUF = 9

class Session:
    def __init__(self, eng, root, opts=None, dim=0, tag='x'):
        self.eng = eng; self.root = root; self.dim = dim
        self.opts = dict(opts or {}); self.opts['_v'] = tag
        ctx = eng.ctx; w, h = eng.w, eng.h
        level = self.opts.get('EIQ_LEVEL', 3)
        wd_ = {0: 'world0', 1: 'world1', -1: 'world-1'}[dim]
        self.dirs = None
        nearest = dict(shadowtex0=False, shadowtex1=False, shadowcolor0=False)
        if eng.faithful:
            # What Iris would read: macros expanded first, then ConstDirectiveParser + Float/Integer.parseXxx.
            user = {k: v for k, v in self.opts.items() if not k.startswith('_')}
            self.dirs = IP.pack_directives(root, user, wd_)
            sh = self.dirs['shadow']; nearest = self.dirs['nearest']
            self.sres = int(sh['resolution']); self.sdist = float(sh['distance'])
            self.shadow_params = dict(dist=self.sdist, interval=sh['intervalSize'], near=sh['near'], far=sh['far'],
                                      phi=self.dirs['sunPathRotation'])
            self.problems = self.dirs['problems']
        else:
            self.sres = {1: 1024, 2: 1536, 3: 2048, 4: 3072, 5: 4096}[level]
            self.sdist = float(self.opts.get('SHADOW_DISTANCE', 128))
            self.shadow_params = {'dist': self.sdist}; self.problems = []
        self.main = [eng.tex((w, h), 'f2', mip=(i == 4)) for i in range(NBUF)]
        self.alt = [eng.tex((w, h), 'f2', mip=(i == 4)) for i in range(NBUF)]
        self.depth = eng.depth_tex((w, h)); self.dc0 = eng.depth_tex((w, h)); self.dc1 = eng.depth_tex((w, h))
        self.out_tex = ctx.texture((w, h), 4); self.out_fbo = ctx.framebuffer([self.out_tex])
        sr = self.sres
        lin = eng.faithful                                   # Iris: shadow samplers are LINEAR unless <name>Nearest = true
        self.sh0 = eng.depth_tex((sr, sr), linear=lin and not nearest['shadowtex0'])
        self.sh1 = eng.depth_tex((sr, sr), linear=lin and not nearest['shadowtex1'])
        self.shc = ctx.texture((sr, sr), 4); fl = moderngl.NEAREST if (nearest['shadowcolor0'] and lin) else moderngl.LINEAR
        self.shc.filter = (fl, fl)
        self.sfbo = ctx.framebuffer([self.shc], depth_attachment=self.sh0)
        self.bound = {s: eng.dummy for s in SAMPLERS}; self.bound['gtexture'] = eng.gtex
        self.vaos = {}; self.tm = None; self._last = 0.0
        self.vol = None
        if level >= 3 and self.opts.get('LPV_ENABLED', 1) is not None:
            dims = {3: (64, 48, 64), 4: (96, 48, 96), 5: (128, 64, 128)}[level]
            self.lpv_dims = dims
            mk = lambda d, dt: eng.ctx.texture3d(d, 4, dtype=dt)
            self.vol = {'voxEmit': mk(dims, 'f1'), 'voxOpac': mk(dims, 'f1'), 'lpvImgA': mk(dims, 'f2'), 'lpvImgB': mk(dims, 'f2')}
            if level >= 4 and self.opts.get('RAYTRACING', 1) is not None:
                self.vol['rtGeo'] = mk(dims, 'f1'); self.vol['rtBrick'] = mk((dims[0] // 4, dims[1] // 4, dims[2] // 4), 'f1')
            for k, v in self.vol.items():
                v.filter = (moderngl.NEAREST, moderngl.NEAREST); v.repeat_x = v.repeat_y = v.repeat_z = False
                v.write(bytes(v.width * v.height * v.depth * 4 * (2 if k.startswith('lpv') else 1)))
            eng.vol = self.vol
        else:
            eng.vol = None
        wd = {0: 'world0', 1: 'world1', -1: 'world-1'}[dim]
        names = ['composite'] + [f'composite{i}' for i in range(1, 10)]
        self.chain = [n for n in names if os.path.exists(f'{root}/{wd}/{n}.fsh')]

    def P(self, n):
        E.ROOT = self.root
        return self.eng.program(n, self.dim, self.opts)

    def tick(self, name):
        if self.tm is None: return
        self.eng.ctx.finish(); now = time.perf_counter()
        self.tm[name] = self.tm.get(name, 0.0) + now - self._last; self._last = now

    def vao(self, prog, key):
        k = (id(prog), key)
        if k not in self.vaos:
            vb, ib, n = self.eng.mesh[key]
            self.vaos[k] = (self.eng.ctx.vertex_array(prog, [(vb, LAYOUT, *ATTRS)], index_buffer=ib, skip_errors=True), n)
        return self.vaos[k]

    def fs_pass(self, name, U, last=False):
        eng = self.eng; ctx = eng.ctx
        prog, targets = self.P(name)
        for i in range(NBUF): self.bound[f'colortex{i}'] = self.main[i]
        eng.set_uniforms(prog, U)
        eng.set_uniforms(prog, {'iris_MV': np.eye(4), 'iris_NM': np.eye(3), 'iris_TM': np.stack([np.eye(4), np.eye(4)]),
                                'iris_P': np.array([[2, 0, 0, -1], [0, 2, 0, -1], [0, 0, 1, 0], [0, 0, 0, 1.0]])})
        eng.bind_samplers(prog, self.bound)
        fbo = self.out_fbo if last else ctx.framebuffer([self.alt[t] for t in targets])
        fbo.use(); ctx.disable(moderngl.DEPTH_TEST); ctx.disable(moderngl.BLEND)
        eng.fs_vao(prog).render(moderngl.TRIANGLE_STRIP)
        if not last:
            fbo.release()
            for t in targets: self.main[t], self.alt[t] = self.alt[t], self.main[t]
        return targets

    def frame(self, cam, prev, sky, fnum):
        eng = self.eng; ctx = eng.ctx; w, h = eng.w, eng.h
        U, sd = eng.make_uniforms(cam, sky, fnum, shadow=self.shadow_params, prev=prev)
        U['frameTime'] = 1.0 / FPS; U['frameTimeCounter'] = 1000.0 + fnum / FPS
        bound = self.bound
        if self.tm is not None: ctx.finish(); self._last = time.perf_counter()
        sprog, _ = self.P('shadow')
        Us = dict(U); Us['iris_MV'] = U['_shadow_MV']; Us['iris_P'] = U['_shadow_P']
        if self.vol:
            for k in ('voxEmit', 'voxOpac'):
                v = self.vol[k]; v.write(bytes(v.width * v.height * v.depth * 4))
            ctx.memory_barrier()
        self.sfbo.use(); ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'; ctx.disable(moderngl.BLEND)
        ctx.clear(1, 1, 1, 0, depth=1.0)
        eng.set_uniforms(sprog, Us); eng.bind_samplers(sprog, bound)
        v, n = self.vao(sprog, 'opaque'); v.render(moderngl.TRIANGLES, vertices=n)
        eng.copy_depth(self.sh0, self.sh1)
        self.sfbo.use(); ctx.enable(moderngl.DEPTH_TEST)
        v, n = self.vao(sprog, 'trans'); v.render(moderngl.TRIANGLES, vertices=n)
        self.tick('shadowmap')
        bound['shadowtex0'] = self.sh0; bound['shadowtex1'] = self.sh1; bound['shadowcolor0'] = self.shc
        if self.vol:
            ctx.memory_barrier()
            E.ROOT = self.root
            for cn in (() if os.environ.get('EIQ_NOCOMP') else ('shadowcomp', 'shadowcomp1', 'shadowcomp2', 'shadowcomp3')):
                try: cp = eng.compute(cn, self.dim, self.opts)
                except FileNotFoundError: continue
                eng.set_uniforms(cp, U); eng.bind_volumes(cp)
                gx, gy, gz = self.lpv_dims
                cp.run((gx + 7) // 8, (gy + 7) // 8, (gz + 7) // 8)
                ctx.memory_barrier()
        self.tick('shadow')
        fog = sky.get('fog', (0.75, 0.85, 1.0))
        for i in (0, 1, 2, 6):
            c = IP.default_clear_color(i, fog) if eng.faithful else ((fog[0], fog[1], fog[2], 1) if i == 0 else (0, 0, 0, 0))
            f = ctx.framebuffer([self.main[i]]); f.clear(*c); f.release()
        gp, gt = self.P('gbuffers_terrain')
        gfbo = ctx.framebuffer([self.main[t] for t in gt], depth_attachment=self.depth)
        dfb = ctx.framebuffer(depth_attachment=self.depth); dfb.clear(depth=1.0); dfb.release()   # depth only (ctx.clear would also wipe the colour attachments)
        gfbo.use()
        ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'; ctx.disable(moderngl.BLEND)
        eng.set_uniforms(gp, U); eng.bind_samplers(gp, bound)
        v, n = self.vao(gp, 'opaque'); v.render(moderngl.TRIANGLES, vertices=n)
        eng.copy_depth(self.depth, self.dc1); eng.copy_depth(self.depth, self.dc0)
        bound['depthtex0'] = self.dc0; bound['depthtex1'] = self.dc1
        self.tick('gbuffers')
        self.fs_pass('deferred', U); self.tick('deferred')
        wp, wt = self.P('gbuffers_water')
        eng.set_uniforms(wp, U); eng.bind_samplers(wp, bound)
        wfbo = ctx.framebuffer([self.main[t] for t in wt], depth_attachment=self.depth)
        wfbo.use(); ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'
        blended = [t not in (1, 2) for t in wt]          # shaders.properties: blend off on colortex1/2
        wfbo.color_mask = tuple((b,) * 4 for b in blended)
        ctx.enable(moderngl.BLEND); ctx.blend_func = moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA
        v, n = self.vao(wp, 'trans'); v.render(moderngl.TRIANGLES, vertices=n)
        ctx.disable(moderngl.BLEND)
        wfbo.color_mask = tuple((not b,) * 4 for b in blended); wfbo.depth_mask = False; ctx.depth_func = '<='
        v.render(moderngl.TRIANGLES, vertices=n)
        wfbo.depth_mask = True; wfbo.color_mask = tuple((True,) * 4 for _ in wt); ctx.depth_func = '<'
        eng.copy_depth(self.depth, self.dc0); bound['depthtex0'] = self.dc0
        self.tick('water')
        for nme in self.chain:
            tg = self.fs_pass(nme, U)
            if tg == [4]: self.main[4].build_mipmaps()
            self.tick(nme)
        self.fs_pass('final', U, last=True); self.tick('final')
        for f in (gfbo, wfbo): f.release()
        return Image.frombytes('RGBA', (w, h), self.out_fbo.read(components=4)).transpose(Image.FLIP_TOP_BOTTOM).convert('RGB')

    def nan_report(self):
        rep = {}
        for i, tx in enumerate(self.main):
            a = np.frombuffer(tx.read(), 'f2').astype('f4')
            n, f = int(np.isnan(a).sum()), int(np.isinf(a).sum())
            if n or f: rep[f'colortex{i}'] = (n, f)
        return rep

    def exposure(self):
        return float(np.frombuffer(self.main[5].read(), 'f2')[0])

    def release(self):
        for t in list((self.vol or {}).values()) + self.main + self.alt + [self.depth, self.dc0, self.dc1, self.sh0, self.sh1, self.shc, self.out_tex]:
            t.release()
        for f in (self.sfbo, self.out_fbo): f.release()
        for v, _ in self.vaos.values():
            try: v.release()
            except Exception: pass
        self.vaos.clear()
        import gc; gc.collect()

def render_static(eng, root, cam, sky, frames=18, opts=None, tag='s', dim=0):
    s = Session(eng, root, opts, dim, tag)
    for k in range(frames): img = s.frame(cam, cam, sky, k)
    ex = s.exposure(); s.release()
    return img, ex
