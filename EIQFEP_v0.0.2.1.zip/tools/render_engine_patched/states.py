import sys; sys.path.insert(0,"/home/claude/work")
from sweep_common import *
eng,h=make(); root='/home/claude/work/pack/'
cy=float(h[86,6])+14.0; P=(86.0,cy,6.0)
cam=dict(pos=P,yaw=0.35,pitch=-0.12,fov=70)
st={'water':dict(eyeWater=1),'lava':dict(eyeWater=2),'blind':dict(blind=1.0),'nv':dict(nightVision=1.0,sunAngle=0.8),
 'thunder':dict(rain=1.0,thunder=1.0,wet=1.0,sunAngle=0.3),'zenith':dict(sunAngle=0.25),'nadir':dict(sunAngle=0.75),'hor':dict(sunAngle=0.0)}
for n,sk in st.items():
    for lvl in (2,5):
        s=S2.Session(eng,root,{'EIQ_LEVEL':lvl},0,'st')
        c=dict(cam)
        if n=='zenith': c['pitch']=1.5
        if n=='nadir': c['pitch']=-1.5
        sk={'sunAngle':0.19,**sk}
        for k in range(4): img=s.frame(c,c,sk,k)
        rep=s.nan_report(); s.release(); a=np.asarray(img,float)/255
        print(n,lvl,rep,round(a.mean(),3),flush=True)
