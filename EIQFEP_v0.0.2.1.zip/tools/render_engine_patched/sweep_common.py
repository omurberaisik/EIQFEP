import sys, os, re, time, json
sys.path.insert(0,'/home/claude/work/eng')
import numpy as np
import world as Wd, engine as E, session2 as S2
W,H=320,180
def make():
    B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); A = Wd.make_atlas()
    eng = E.Engine(W,H,A); eng.upload_mesh(Wd.mesh(B,Sk,BL)); return eng,h
def scene(h,name):
    cy=float(h[86,6])+14.0; P=(86.0,cy,6.0)
    S={'noon':(dict(pos=P,yaw=0.35,pitch=-0.12,fov=70),dict(sunAngle=0.19)),
       'night':(dict(pos=P,yaw=0.35,pitch=-0.12,fov=70),dict(sunAngle=0.80,fog=(0.02,0.03,0.07))),
       'dusk':(dict(pos=P,yaw=-1.15,pitch=0.04,fov=70),dict(sunAngle=0.487)),
       'rain':(dict(pos=P,yaw=0.35,pitch=-0.12,fov=70),dict(sunAngle=0.19,rain=1.0,wet=1.0,fog=(0.55,0.6,0.65)))}
    return S[name]
def run(eng,h,root,opts,scn,dim=0,frames=5,level=5):
    cam,sky=scene(h,scn)
    s=S2.Session(eng,root,{'EIQ_LEVEL':level,**opts},dim,'sw')
    for k in range(frames): img=s.frame(cam,cam,sky,k)
    rep=s.nan_report(); s.release()
    a=np.asarray(img,float)/255
    return dict(nan=rep,mean=float(a.mean()),std=float(a.std()),maxv=float(a.max()))
