import sys, json, numpy as np
sys.path.insert(0,'/home/claude/work/eng')
import world as Wd, engine as E, session2 as S2
B,h,SEA = Wd.build_world(); Sk,BL = Wd.propagate(B); A = Wd.make_atlas()
eng = E.Engine(640,360,A); eng.upload_mesh(Wd.mesh(B,Sk,BL))
cy=float(h[86,6])+14.0
sky=dict(sunAngle=0.19)
def cam(i): return dict(pos=(86.0+0.05*i,cy,6.0),yaw=0.35+0.004*i,pitch=-0.12,fov=70)
def run(opts,tag,frames=12):
    s=S2.Session(eng,'/home/claude/work/pack/',{'EIQ_LEVEL':3,**opts},0,tag)
    prev=cam(0)
    for k in range(frames):
        c=cam(k); img=s.frame(c,prev,sky,k); prev=c
    s.release(); return np.asarray(img,float)
def lapvar(a):
    g=a.mean(2); l=g[1:-1,1:-1]*4-g[:-2,1:-1]-g[2:,1:-1]-g[1:-1,:-2]-g[1:-1,2:]; return l.var()
# reference: static at final pose, many frames
s=S2.Session(eng,'/home/claude/work/pack/',{'EIQ_LEVEL':3},0,'ref'); c=cam(11)
for k in range(14): ref=np.asarray(s.frame(c,c,sky,k),float)
s.release()
print('ref sharp',round(lapvar(ref),1))
for name,o in (('old',{'TAA_CATMULL':0,'TAA_VAR_GAMMA':100.0}),('catmull only',{'TAA_VAR_GAMMA':100.0}),('new',{})):
    a=run(o,name); print(f'{name:13s} err={np.abs(a-ref).mean():.3f} sharp={lapvar(a):.1f}')
