import sys, os, time, math, numpy as np, moderngl
from PIL import Image, ImageDraw, ImageFont
import world as Wd, engine as E
from engine import SAMPLERS, LAYOUT, ATTRS

FPS = 24


class PackSession:
    """Persistent pipeline state across frames (TAA history, exposure) with a moving camera."""
    def __init__(self, eng, opts, dim=0):
        self.eng = eng; self.opts = dict(opts); self.dim = dim
        ctx = eng.ctx; w, h = eng.w, eng.h
        level = opts.get('EIQ_LEVEL', 3)
        self.sres = {1: 1024, 2: 1536, 3: 2048, 4: 3072, 5: 4096}[level]
        self.sdist = float(opts.get('SHADOW_DISTANCE', 128))
        self.main = [eng.tex((w, h), 'f2', mip=(i == 4)) for i in range(6)]
        self.alt = [eng.tex((w, h), 'f2', mip=(i == 4)) for i in range(6)]
        self.depth = eng.depth_tex((w, h)); self.dc0 = eng.depth_tex((w, h)); self.dc1 = eng.depth_tex((w, h))
        self.out_tex = ctx.texture((w, h), 4); self.out_fbo = ctx.framebuffer([self.out_tex])
        sr = self.sres
        self.sh0 = eng.depth_tex((sr, sr)); self.sh1 = eng.depth_tex((sr, sr))
        self.shc = ctx.texture((sr, sr), 4); self.shc.filter = (moderngl.LINEAR, moderngl.LINEAR)
        self.sfbo = ctx.framebuffer([self.shc], depth_attachment=self.sh0)
        self.bound = {s: eng.dummy for s in SAMPLERS}; self.bound['gtexture'] = eng.gtex
        self.vaos = {}
        # persistent framebuffers
        self.gfbo = None
        self.tm = None; self._last = 0.0

    def P(self, n): return self.eng.program(n, self.dim, self.opts)

    def tick(self, name):
        if self.tm is None: return
        self.eng.ctx.finish(); now = time.perf_counter()
        self.tm[name] = self.tm.get(name, 0.0) + (now - self._last); self._last = now

    def vao(self, prog, key):
        k = (id(prog), key)
        if k not in self.vaos:
            vb, ib, n = self.eng.mesh[key]
            self.vaos[k] = (self.eng.ctx.vertex_array(prog, [(vb, LAYOUT, *ATTRS)], index_buffer=ib, skip_errors=True), n)
        return self.vaos[k]

    def fs_pass(self, name, U, last=False):
        eng = self.eng; ctx = eng.ctx
        prog, targets = self.P(name)
        for i in range(6): self.bound[f'colortex{i}'] = self.main[i]
        eng.set_uniforms(prog, U)
        eng.set_uniforms(prog, {'iris_MV': np.eye(4), 'iris_NM': np.eye(3), 'iris_TM': np.stack([np.eye(4), np.eye(4)]),
                                'iris_P': np.array([[2, 0, 0, -1], [0, 2, 0, -1], [0, 0, 1, 0], [0, 0, 0, 1.0]])})
        eng.bind_samplers(prog, self.bound)
        fbo = self.out_fbo if last else ctx.framebuffer([self.alt[t] for t in targets])
        fbo.use(); ctx.disable(moderngl.DEPTH_TEST); ctx.disable(moderngl.BLEND)
        eng.fs_vao(prog).render(moderngl.TRIANGLE_STRIP)
        if not last:
            fbo.release()
            for t in targets: self.main[t], self.alt[t] = self.alt[t], self.main[t]

    def frame(self, cam, prev, sky, fnum):
        eng = self.eng; ctx = eng.ctx; w, h = eng.w, eng.h
        U, sd = eng.make_uniforms(cam, sky, fnum, shadow={'dist': self.sdist}, prev=prev)
        U['frameTime'] = 1.0 / FPS; U['frameTimeCounter'] = 1000.0 + fnum / FPS
        bound = self.bound
        if self.tm is not None: self.eng.ctx.finish(); self._last = time.perf_counter()
        # shadow map (re-centred on the player every frame, like Iris)
        sprog, _ = self.P('shadow')
        Us = dict(U); Us['iris_MV'] = U['_shadow_MV']; Us['iris_P'] = U['_shadow_P']
        self.sfbo.use(); ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'; ctx.disable(moderngl.BLEND)
        ctx.clear(1, 1, 1, 0, depth=1.0)
        eng.set_uniforms(sprog, Us); eng.bind_samplers(sprog, bound)
        v, n = self.vao(sprog, 'opaque'); v.render(moderngl.TRIANGLES, vertices=n)
        eng.copy_depth(self.sh0, self.sh1)
        self.sfbo.use(); ctx.enable(moderngl.DEPTH_TEST)
        v, n = self.vao(sprog, 'trans'); v.render(moderngl.TRIANGLES, vertices=n)
        bound['shadowtex0'] = self.sh0; bound['shadowtex1'] = self.sh1; bound['shadowcolor0'] = self.shc
        self.tick('1 golge haritasi')
        # gbuffers
        fog = sky.get('fog', (0.75, 0.85, 1.0))
        for i, c in ((0, (fog[0], fog[1], fog[2], 1)), (1, (0, 0, 0, 0)), (2, (0, 0, 0, 0))):
            f = ctx.framebuffer([self.main[i]]); f.clear(*c); f.release()
        gfbo = ctx.framebuffer([self.main[0], self.main[1], self.main[2]], depth_attachment=self.depth)
        dfb = ctx.framebuffer(depth_attachment=self.depth); dfb.clear(depth=1.0); dfb.release()
        gfbo.use()
        ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'; ctx.disable(moderngl.BLEND)
        gp, _ = self.P('gbuffers_terrain')
        eng.set_uniforms(gp, U); eng.bind_samplers(gp, bound)
        v, n = self.vao(gp, 'opaque'); v.render(moderngl.TRIANGLES, vertices=n)
        eng.copy_depth(self.depth, self.dc1); eng.copy_depth(self.depth, self.dc0)
        bound['depthtex0'] = self.dc0; bound['depthtex1'] = self.dc1
        self.tick('2 gbuffers (arazi)')
        self.fs_pass('deferred', U); self.tick('3 deferred (isik/AO/gokyuzu/bulut)')
        # translucents: A (colour, blended) then B (normals/material, no blend)
        wp, _ = self.P('gbuffers_water')
        eng.set_uniforms(wp, U); eng.bind_samplers(wp, bound)
        wfbo = ctx.framebuffer([self.main[0], self.main[1], self.main[2]], depth_attachment=self.depth)
        wfbo.use(); ctx.enable(moderngl.DEPTH_TEST); ctx.depth_func = '<'
        wfbo.color_mask = ((True,) * 4, (False,) * 4, (False,) * 4)
        ctx.enable(moderngl.BLEND); ctx.blend_func = moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA
        v, n = self.vao(wp, 'trans'); v.render(moderngl.TRIANGLES, vertices=n)
        ctx.disable(moderngl.BLEND)
        wfbo.color_mask = ((False,) * 4, (True,) * 4, (True,) * 4); wfbo.depth_mask = False; ctx.depth_func = '<='
        v.render(moderngl.TRIANGLES, vertices=n)
        wfbo.depth_mask = True; wfbo.color_mask = ((True,) * 4,) * 3; ctx.depth_func = '<'
        eng.copy_depth(self.depth, self.dc0); bound['depthtex0'] = self.dc0
        self.tick('4 su/cam (translucent)')
        labels = {'composite': '5 yansima (SSR)', 'composite1': '6 sis + hacimsel isik', 'composite2': '7 TAA / FXAA', 'composite3': '8 bloom'}
        for nme in ('composite', 'composite1', 'composite2', 'composite3'):
            self.fs_pass(nme, U)
            if nme == 'composite3': self.main[4].build_mipmaps()
            self.tick(labels[nme])
        self.fs_pass('composite4', U); self.tick('9 pozlama')
        self.fs_pass('final', U, last=True); self.tick('10 final (ton esleme)')
        for f in (gfbo, wfbo): f.release()
        return Image.frombytes('RGBA', (w, h), self.out_fbo.read(components=4)).transpose(Image.FLIP_TOP_BOTTOM).convert('RGB')

    def exposure(self):
        return float(np.frombuffer(self.main[5].read(), 'f2')[0])


def build_path(h, B, seconds=None, speed=4.3):
    wps = [(106, 3), (106, 16), (105, 26), (102, 32), (100.5, 38), (100, 46), (97.5, 52), (96, 58)]
    pts = [np.array(p, float) for p in wps]
    for _ in range(3):                     # Chaikin smoothing
        new = [pts[0]]
        for a, b in zip(pts[:-1], pts[1:]):
            new += [0.75 * a + 0.25 * b, 0.25 * a + 0.75 * b]
        new.append(pts[-1]); pts = new
    pts = np.array(pts)
    seg = np.hypot(*np.diff(pts, axis=0).T); cum = np.concatenate([[0], np.cumsum(seg)])
    total = cum[-1]
    step = speed / FPS
    s = np.arange(0, total, step)
    x = np.interp(s, cum, pts[:, 0]); z = np.interp(s, cum, pts[:, 1])
    return x, z, total


def camera_track(x, z, h, B):
    n = len(x)
    cams = []; feet = None
    for i in range(n):
        j = min(i + 6, n - 1); k = max(i - 6, 0)
        dx, dz = x[j] - x[k], z[j] - z[k]
        yaw_path = math.atan2(dx, dz)
        t = i / FPS
        yaw = yaw_path + 0.16 * math.sin(0.55 * t) + 0.05 * math.sin(1.9 * t)
        pitch = -0.05 + 0.06 * math.sin(0.8 * t + 0.6)
        gh = h[int(x[i]), int(z[i])] + 1.0
        feet = gh if feet is None else feet + 0.22 * (gh - feet)       # step smoothing
        bob = 0.04 * abs(math.sin(math.pi * 2.0 * t)) - 0.02
        cams.append(dict(pos=(float(x[i]), float(feet + 1.62 + bob), float(z[i])), yaw=yaw, pitch=pitch, fov=70))
    return cams


def check_collisions(cams, B):
    bad = []
    for i, c in enumerate(cams):
        x, y, z = c['pos']
        for dy in (-1.4, -0.4):
            b = B[int(x), int(y + dy), int(z)]
            if b in (Wd.LOG, Wd.LEAVES, Wd.WATER, Wd.PLANKS, Wd.GLASS, Wd.GLOW, Wd.LAVA, Wd.STONE):
                bad.append((i, round(x, 1), round(z, 1), int(b), dy)); break
    return bad


if __name__ == '__main__':
    W_, H_ = int(sys.argv[1]), int(sys.argv[2]); level = int(sys.argv[3]); outdir = sys.argv[4]
    nmax = int(sys.argv[5]) if len(sys.argv) > 5 else 10 ** 9
    fixroot = sys.argv[6] if len(sys.argv) > 6 else None
    os.makedirs(outdir, exist_ok=True)
    B, h, SEA = Wd.build_world(); S, BL = Wd.propagate(B); M = Wd.mesh(B, S, BL); A = Wd.make_atlas()
    x, z, total = build_path(h, B)
    cams = camera_track(x, z, h, B)[:nmax]
    bad = check_collisions(cams, B)
    print(f'path {total:.0f} blocks, {len(cams)} frames ({len(cams)/FPS:.1f}s), blocked frames: {len(bad)}', bad[:6], flush=True)
    N = len(cams)
    eng = E.Engine(W_, H_, A); eng.upload_mesh(M)
    if fixroot: E.ROOT = fixroot
    sess = PackSession(eng, {'EIQ_LEVEL': level})
    sa0, sa1 = 0.09, 0.43
    def sky_at(i):
        a = sa0 + (sa1 - sa0) * i / max(N - 1, 1)
        fr = np.clip((a - 0.32) / 0.14, 0, 1)
        return dict(sunAngle=a, fog=tuple(np.array((0.75, 0.85, 1.0)) * (1 - fr) + np.array((0.9, 0.6, 0.4)) * fr))
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', max(14, H_ // 26))
    for k in range(14):                                     # warm-up: exposure + TAA history
        sess.frame(cams[0], cams[0], sky_at(0), k)
    t0 = time.time()
    for i in range(N):
        prev = cams[i - 1] if i > 0 else cams[0]
        sky = sky_at(i)
        pk = sess.frame(cams[i], prev, sky, 14 + i)
        va = eng.render_vanilla(cams[i], sky)
        sheet = Image.new('RGB', (W_ * 2 + 4, H_), (255, 255, 255))
        sheet.paste(va, (0, 0)); sheet.paste(pk, (W_ + 4, 0))
        d = ImageDraw.Draw(sheet)
        for tx, lab in ((8, 'VANILLA (basit)'), (W_ + 12, f'EIQFEP v0.0.0.1  -  seviye {level}')):
            tw = d.textlength(lab, font=font)
            d.rectangle((tx - 4, 6, tx + tw + 6, 6 + font.size + 8), fill=(0, 0, 0)); d.text((tx, 9), lab, fill=(255, 255, 255), font=font)
        sheet.save(f'{outdir}/f{i:05d}.jpg', quality=93)
        if i % 10 == 0:
            el = time.time() - t0
            print(f'frame {i+1}/{N}  {el/(i+1):.2f}s/frame  eta {(N-i-1)*el/(i+1):.0f}s  exposure {sess.exposure():.2f}', flush=True)
    print('done', flush=True)
