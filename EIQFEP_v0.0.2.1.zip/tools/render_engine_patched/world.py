"""Procedural voxel world + texture atlas + mesher (vectorised numpy)."""
import numpy as np

(AIR, GRASS, DIRT, STONE, SAND, LOG, LEAVES, PLANKS, GLASS, WATER, GLOW, LAVA,
 TALL, FLOWER, NETHER) = range(15)

OPAQUE = np.zeros(32, bool)
for b in (GRASS, DIRT, STONE, SAND, LOG, PLANKS, GLOW, LAVA, NETHER):
    OPAQUE[b] = True
ATTEN = np.zeros(32, np.uint8)       # extra light attenuation
ATTEN[LEAVES] = 1; ATTEN[WATER] = 1
EMIT = np.zeros(32, np.uint8)
EMIT[GLOW] = 15; EMIT[LAVA] = 15
PACK_ID = {WATER: 8, LEAVES: 10, TALL: 11, FLOWER: 11, GLASS: 20, GLOW: 50, LAVA: 40}

NT = 8   # atlas = NT x NT tiles of 16px
(T_GTOP, T_GSIDE, T_DIRT, T_STONE, T_SAND, T_LOGS, T_LOGT, T_LEAF, T_PLANK, T_GLASS,
 T_GLOW, T_LAVA, T_WATER, T_TALL, T_FLOWER, T_NETH) = range(16)

GT = (0.569, 0.741, 0.349)   # grass tint
LT = (0.47, 0.72, 0.27)      # leaf tint
WT = (0.247, 0.463, 0.894)   # water tint


def make_atlas(seed=1):
    rng = np.random.RandomState(seed)
    A = np.zeros((NT * 16, NT * 16, 4), np.uint8)

    def put(t, img):
        ty, tx = divmod(t, NT)
        A[ty*16:(ty+1)*16, tx*16:(tx+1)*16] = np.clip(img, 0, 255).astype(np.uint8)

    def noisy(rgb, amp, a=255):
        n = rng.randn(16, 16, 1) * amp
        base = np.array(list(rgb) + [a], float)[None, None, :] * np.ones((16, 16, 1))
        base[..., :3] += n
        return base

    put(T_GTOP, noisy((170, 170, 170), 14))
    s = noisy((134, 96, 67), 9)
    for r in range(3):
        s[r, :, :3] = np.array([100, 150, 60]) + rng.randn(16, 1) * 10
    s[3, ::2, :3] = [100, 150, 60]
    put(T_GSIDE, s)
    put(T_DIRT, noisy((134, 96, 67), 10))
    st = noisy((126, 126, 126), 12)
    for _ in range(14):
        y, x = rng.randint(0, 15, 2); st[y:y+2, x:x+2, :3] -= 22
    put(T_STONE, st)
    put(T_SAND, noisy((219, 207, 160), 7))
    ls = noisy((104, 82, 50), 8)
    ls[:, ::4, :3] -= 22; ls[:, 2::5, :3] += 10
    put(T_LOGS, ls)
    lt = noisy((176, 144, 92), 6)
    yy, xx = np.mgrid[0:16, 0:16]; rr = np.hypot(yy - 7.5, xx - 7.5)
    lt[(rr.astype(int) % 3) == 0, :3] -= 28; lt[rr > 7.2, :3] = [104, 82, 50]
    put(T_LOGT, lt)
    lf = noisy((140, 140, 140), 30)
    lf[rng.rand(16, 16) < 0.16, 3] = 0
    put(T_LEAF, lf)
    pl = noisy((164, 130, 80), 6)
    pl[3::4, :, :3] -= 40; pl[:, 7, :3] -= 18
    put(T_PLANK, pl)
    g = np.zeros((16, 16, 4)); g[..., :3] = (205, 232, 240); g[..., 3] = 26
    g[0, :, 3] = g[-1, :, 3] = g[:, 0, 3] = g[:, -1, 3] = 230
    g[5:7, 5:9, 3] = 120
    put(T_GLASS, g)
    gl = noisy((255, 196, 96), 30)
    gl[rng.rand(16, 16) < 0.18, :3] = [190, 110, 40]
    gl[rng.rand(16, 16) < 0.12, :3] = [255, 240, 170]
    put(T_GLOW, gl)
    lv = noisy((232, 96, 20), 16)
    lv[rng.rand(16, 16) < 0.22, :3] = [255, 190, 50]
    put(T_LAVA, lv)
    put(T_WATER, noisy((255, 255, 255), 3))
    tg = np.zeros((16, 16, 4)); tg[..., 3] = 0
    for x in (2, 5, 8, 11, 13):
        h = rng.randint(7, 15)
        tg[16-h:, x, :] = [150 + rng.randint(0, 30)] * 3 + [255]
        tg[16-h-1:, x+1 if x < 15 else x, :] = [130] * 3 + [255]
    put(T_TALL, tg)
    fl = np.zeros((16, 16, 4))
    fl[7:, 7:9, :] = [60, 130, 40, 255]
    fl[3:7, 6:10, :] = [220, 40, 50, 255]; fl[4:6, 7:9, :] = [250, 220, 60, 255]
    put(T_FLOWER, fl)
    put(T_NETH, noisy((112, 46, 46), 14))
    return A


def tile_of(block, d):
    """d: 0:+x 1:-x 2:+y 3:-y 4:+z 5:-z"""
    if block == GRASS: return T_GTOP if d == 2 else (T_DIRT if d == 3 else T_GSIDE)
    if block == LOG: return T_LOGT if d in (2, 3) else T_LOGS
    return {DIRT: T_DIRT, STONE: T_STONE, SAND: T_SAND, LEAVES: T_LEAF, PLANKS: T_PLANK,
            GLASS: T_GLASS, WATER: T_WATER, GLOW: T_GLOW, LAVA: T_LAVA, NETHER: T_NETH,
            TALL: T_TALL, FLOWER: T_FLOWER}[block]


def tint_of(block, d):
    if block == GRASS and d == 2: return GT
    if block == LEAVES or block == TALL: return LT if block == LEAVES else GT
    if block == WATER: return WT
    return (1.0, 1.0, 1.0)


# ----------------------------------------------------------------- terrain
def vnoise(shape, scale, rng):
    g = rng.rand(shape[0] // scale + 3, shape[1] // scale + 3)
    xs = np.arange(shape[0]) / scale; zs = np.arange(shape[1]) / scale
    x0 = xs.astype(int); z0 = zs.astype(int); fx = xs - x0; fz = zs - z0
    sx = (fx * fx * (3 - 2 * fx))[:, None]; sz = (fz * fz * (3 - 2 * fz))[None, :]
    a = g[x0][:, z0]; b = g[x0 + 1][:, z0]; c = g[x0][:, z0 + 1]; d = g[x0 + 1][:, z0 + 1]
    return a * (1 - sx) * (1 - sz) + b * sx * (1 - sz) + c * (1 - sx) * sz + d * sx * sz


def build_world(seed=7):
    rng = np.random.RandomState(seed)
    X = Z = 192; Y = 112; SEA = 62
    n = (0.5 * vnoise((X, Z), 48, rng) + 0.3 * vnoise((X, Z), 24, rng) +
         0.15 * vnoise((X, Z), 12, rng) + 0.05 * vnoise((X, Z), 6, rng))
    xx, zz = np.meshgrid(np.arange(X), np.arange(Z), indexing='ij')
    h = 63 + (n - 0.5) * 30
    h -= 13 * np.exp(-(((xx - 104) / 30.0) ** 2 + ((zz - 78) / 20.0) ** 2))      # lake
    h += 46 * np.exp(-(((xx - 55) / 32.0) ** 2 + ((zz - 168) / 36.0) ** 2))      # mountains
    h += 40 * np.exp(-(((xx - 150) / 28.0) ** 2 + ((zz - 176) / 32.0) ** 2))
    # cabin pad
    pad = 66
    cx0, cx1, cz0, cz1 = 80, 90, 40, 47
    d = np.hypot(np.maximum(np.maximum(cx0 - xx, xx - cx1), 0), np.maximum(np.maximum(cz0 - zz, zz - cz1), 0))
    w = np.clip(1 - d / 9.0, 0, 1); w = w * w * (3 - 2 * w)
    h = h * (1 - w) + pad * w
    h = np.clip(np.rint(h), 30, Y - 14).astype(int)

    B = np.zeros((X, Y, Z), np.uint8)
    for x in range(X):
        for z in range(Z):
            t = h[x, z]
            B[x, :max(t - 3, 0), z] = STONE
            top = SAND if t <= SEA + 1 else (STONE if t > 92 else GRASS)
            sub = SAND if t <= SEA + 1 else (STONE if t > 92 else DIRT)
            B[x, max(t - 3, 0):t, z] = sub
            B[x, t, z] = top
            if t < SEA: B[x, t + 1:SEA + 1, z] = WATER

    def put(x, y, z, b):
        if 0 <= x < X and 0 <= y < Y and 0 <= z < Z: B[x, y, z] = b

    # cabin
    for x in range(cx0, cx1 + 1):
        for z in range(cz0, cz1 + 1):
            put(x, pad, z, PLANKS)
            for y in range(pad + 1, pad + 5): put(x, y, z, AIR)
            put(x, pad + 5, z, PLANKS)
            put(x, pad + 6, z, PLANKS if cx0 + 1 <= x <= cx1 - 1 and cz0 + 1 <= z <= cz1 - 1 else AIR)
    for x in range(cx0, cx1 + 1):
        for z in range(cz0, cz1 + 1):
            edge = x in (cx0, cx1) or z in (cz0, cz1)
            if edge:
                for y in range(pad + 1, pad + 5): put(x, y, z, PLANKS)
    for y in (pad + 2, pad + 3):                       # windows
        for x in (cx0 + 2, cx0 + 3, cx1 - 3, cx1 - 2):
            put(x, y, cz0, GLASS); put(x, y, cz1, GLASS)
        for z in (cz0 + 2, cz0 + 4):
            put(cx0, y, z, GLASS); put(cx1, y, z, GLASS)
    xm = (cx0 + cx1) // 2
    for y in (pad + 1, pad + 2): put(xm, y, cz0, AIR)  # door
    put(xm, pad + 4, (cz0 + cz1) // 2, GLOW)           # ceiling lamp
    for lx in (cx0 - 2, cx1 + 2):                      # lamp posts
        for y in range(pad + 1, pad + 4): put(lx, y, cz0 - 2, LOG)
        put(lx, pad + 4, cz0 - 2, GLOW)
    for x in range(cx1 + 5, cx1 + 8):                  # lava pool
        for z in range(cz0 + 1, cz0 + 4):
            t_ = h[x, z]; put(x, t_, z, LAVA); put(x, t_ - 1, z, STONE)
    cabin_box = (cx0 - 6, cx1 + 10, cz0 - 6, cz1 + 6)

    # trees
    trees = []
    for _ in range(900):
        x = rng.randint(6, X - 6); z = rng.randint(6, Z - 6); t = h[x, z]
        if B[x, t, z] != GRASS or not (65 < t < 86): continue
        if cabin_box[0] < x < cabin_box[1] and cabin_box[2] < z < cabin_box[3]: continue
        if any((x - a) ** 2 + (z - b) ** 2 < 30 for a, b in trees): continue
        trees.append((x, z))
        th = rng.randint(4, 7)
        for y in range(t + 1, t + th + 1): B[x, y, z] = LOG
        for dy in range(-2, 2):
            r = 2 if dy < 0 else 1
            for dx in range(-r, r + 1):
                for dz in range(-r, r + 1):
                    if abs(dx) == r and abs(dz) == r and rng.rand() < 0.45: continue
                    yy_ = t + th + dy
                    if B[x + dx, yy_, z + dz] == AIR: B[x + dx, yy_, z + dz] = LEAVES
        if B[x, t + th + 2, z] == AIR: B[x, t + th + 2, z] = LEAVES
    # grass / flowers
    for x in range(2, X - 2):
        for z in range(2, Z - 2):
            t = h[x, z]
            if B[x, t, z] == GRASS and B[x, t + 1, z] == AIR:
                r = rng.rand()
                if r < 0.16: B[x, t + 1, z] = TALL
                elif r < 0.185: B[x, t + 1, z] = FLOWER
    return B, h, SEA


# -------------------------------------------------------------------- lighting
def propagate(B):
    X, Y, Z = B.shape
    opq = OPAQUE[B]
    lk = opq | (B == LEAVES) | (B == WATER)
    # sky: column open above topmost light-blocking cell
    rev = np.cumsum(lk[:, ::-1, :], axis=1)[:, ::-1, :]
    S = np.where(rev == 0, 15, 0).astype(np.int16)
    BL = np.where(EMIT[B] > 0, EMIT[B], 0).astype(np.int16)
    att = ATTEN[B].astype(np.int16)
    free = ~opq

    def spread(L):
        for _ in range(15):
            m = L.copy()
            for ax in range(3):
                for sh in (1, -1):
                    r = np.roll(L, sh, axis=ax)
                    if ax == 0:
                        if sh == 1: r[0] = 0
                        else: r[-1] = 0
                    elif ax == 1:
                        if sh == 1: r[:, 0] = 0
                        else: r[:, -1] = 0
                    else:
                        if sh == 1: r[:, :, 0] = 0
                        else: r[:, :, -1] = 0
                    m = np.maximum(m, np.where(free, r - 1 - att, 0))
            if (m == L).all(): break
            L = m
        return L
    return spread(S).astype(np.uint8), spread(BL).astype(np.uint8)


# ---------------------------------------------------------------------- meshing
DIRS = [
    ((1, 0, 0), [(1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1)], [(0, 1), (0, 0), (1, 0), (1, 1)], (0, 0, 1), (0, 1, 0), (1, 2)),
    ((-1, 0, 0), [(0, 0, 1), (0, 1, 1), (0, 1, 0), (0, 0, 0)], [(0, 1), (0, 0), (1, 0), (1, 1)], (0, 0, -1), (0, 1, 0), (1, 2)),
    ((0, 1, 0), [(0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)], [(0, 0), (0, 1), (1, 1), (1, 0)], (1, 0, 0), (0, 0, -1), (0, 2)),
    ((0, -1, 0), [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)], [(0, 0), (1, 0), (1, 1), (0, 1)], (1, 0, 0), (0, 0, -1), (0, 2)),
    ((0, 0, 1), [(1, 0, 1), (1, 1, 1), (0, 1, 1), (0, 0, 1)], [(0, 1), (0, 0), (1, 0), (1, 1)], (-1, 0, 0), (0, 1, 0), (0, 1)),
    ((0, 0, -1), [(0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)], [(0, 1), (0, 0), (1, 0), (1, 1)], (1, 0, 0), (0, 1, 0), (0, 1)),
]
AO_TAB = np.array([1.0, 0.82, 0.64, 0.46], np.float32)
NF = 33   # floats per vertex
IRIS_MIDBLOCK = True   # Iris ExtendedDataHelper.computeMidBlock: (blockCenter - vertex) * 64  (False = old guess: vertex - center)


def pack(pos, col, nrm, uv, lm, ent, mid, tan, mb):
    n = len(pos)
    out = np.zeros((n, NF), np.float32)
    out[:, 0:3] = pos; out[:, 3] = 1
    out[:, 4:8] = col
    out[:, 8:11] = nrm
    out[:, 11:13] = uv; out[:, 14] = 1
    out[:, 15] = lm[:, 0] * 240 + 8; out[:, 16] = lm[:, 1] * 240 + 8; out[:, 18] = 1
    out[:, 19] = ent
    out[:, 23:25] = mid
    out[:, 25:29] = tan
    out[:, 29:33] = mb
    return out


def mesh(B, S, BL):
    opq = OPAQUE[B]
    Bp = np.pad(B, 1); Op = np.pad(opq, 1)
    Sp = np.pad(S, 1, constant_values=15); BLp = np.pad(BL, 1)
    solid_types = [GRASS, DIRT, STONE, SAND, LOG, LEAVES, PLANKS, GLASS, WATER, GLOW, LAVA, NETHER]
    result = {'opaque': [], 'trans': []}
    for d, (nrm, corners, uvs, T, Bup, axes) in enumerate(DIRS):
        nv = np.array(nrm)
        nb = np.roll(B, tuple(-v for v in nrm), axis=(0, 1, 2))
        # pad edges: treat out-of-world as air
        if nrm[0] == 1: nb[-1] = 0
        if nrm[0] == -1: nb[0] = 0
        if nrm[1] == 1: nb[:, -1] = 0
        if nrm[1] == -1: nb[:, 0] = 0
        if nrm[2] == 1: nb[:, :, -1] = 0
        if nrm[2] == -1: nb[:, :, 0] = 0
        nbo = OPAQUE[nb]
        for b in solid_types:
            if b == WATER:
                m = (B == b) & ~nbo & (nb != WATER) & (nb != GLASS) & (d != 3)
            elif b in (LEAVES, GLASS):
                m = (B == b) & ~nbo & (nb != b)
            else:
                m = (B == b) & ~nbo
            P = np.argwhere(m)
            if len(P) == 0: continue
            N = len(P)
            tile = tile_of(b, d); ty, tx = divmod(tile, NT)
            tint = tint_of(b, d)
            ent = PACK_ID.get(b, -1)
            tan4 = np.zeros((N, 4), np.float32)
            tvec = np.array(T, float); bvec = np.array(Bup, float)
            wv = np.sign(np.dot(np.cross(tvec, nv), bvec)) or 1.0
            tan4[:, :3] = tvec; tan4[:, 3] = wv
            verts = []
            q = P + nv
            ea = np.zeros(3, int); ea[axes[0]] = 1
            eb = np.zeros(3, int); eb[axes[1]] = 1

            def at(arr, pos): return arr[pos[:, 0] + 1, pos[:, 1] + 1, pos[:, 2] + 1]
            for k in range(4):
                c = np.array(corners[k], float)
                sa = 1 if corners[k][axes[0]] == 1 else -1
                sb = 1 if corners[k][axes[1]] == 1 else -1
                p1 = q + sa * ea; p2 = q + sb * eb; p3 = q + sa * ea + sb * eb
                s1 = at(Op, p1); s2 = at(Op, p2); s3 = at(Op, p3)
                occ = np.where(s1 & s2, 3, s1.astype(int) + s2 + s3)
                ao = AO_TAB[occ]
                lms = []
                for L in (BLp, Sp):
                    lq = at(L, q).astype(np.float32)
                    l1 = np.where(s1, lq, at(L, p1)); l2 = np.where(s2, lq, at(L, p2)); l3 = np.where(s3, lq, at(L, p3))
                    lms.append((lq + l1 + l2 + l3) / 4.0)
                lm = np.stack(lms, 1) / 15.0
                pos = P + c
                if b == WATER: pos[:, 1] = P[:, 1] + np.where(c[1] > 0.5, 0.875, 0.0)
                col = np.zeros((N, 4), np.float32); col[:, :3] = tint; col[:, 3] = ao
                uv = np.stack([(tx + uvs[k][0]) / NT * np.ones(N), (ty + uvs[k][1]) / NT * np.ones(N)], 1)
                mid = np.tile([(tx + 0.5) / NT, (ty + 0.5) / NT], (N, 1))
                mb = np.zeros((N, 4)); mb[:, :3] = ((P + 0.5) - pos) * 64 if IRIS_MIDBLOCK else (pos - (P + 0.5)) * 64
                verts.append(pack(pos, col, np.tile(nv, (N, 1)), uv, lm, ent, mid, tan4, mb))
            result['trans' if b in (GLASS, WATER) else 'opaque'].append(np.stack(verts, 1).reshape(-1, NF))
    # cross plants
    for b in (TALL, FLOWER):
        P = np.argwhere(B == b)
        if len(P) == 0: continue
        N = len(P)
        tile = tile_of(b, 2); ty, tx = divmod(tile, NT)
        tint = tint_of(b, 2)
        quads = [([(0, 0, 0), (0, 1, 0), (1, 1, 1), (1, 0, 1)], (0.7071, 0, -0.7071)),
                 ([(1, 0, 0), (1, 1, 0), (0, 1, 1), (0, 0, 1)], (0.7071, 0, 0.7071))]
        uvs = [(0, 1), (0, 0), (1, 0), (1, 1)]
        lq = [Lq[P[:, 0] + 1, P[:, 1] + 1, P[:, 2] + 1].astype(np.float32) / 15 for Lq in (BLp, Sp)]
        lm = np.stack(lq, 1)
        for corners, nrm0 in quads:
          for flip in (False, True):                      # vanilla cross models have a quad for each side (own normal)
            nrm = tuple(-x for x in nrm0) if flip else nrm0
            verts = []
            tvec = np.array(corners[3], float) - np.array(corners[0], float)
            tan4 = np.zeros((N, 4), np.float32); tan4[:, :3] = tvec / np.linalg.norm(tvec); tan4[:, 3] = -1 if flip else 1
            for k in range(4):
                pos = P + np.array(corners[k], float)
                col = np.zeros((N, 4), np.float32); col[:, :3] = tint; col[:, 3] = 1
                uv = np.stack([(tx + uvs[k][0]) / NT * np.ones(N), (ty + uvs[k][1]) / NT * np.ones(N)], 1)
                mid = np.tile([(tx + 0.5) / NT, (ty + 0.5) / NT], (N, 1))
                mb = np.zeros((N, 4)); mb[:, :3] = ((P + 0.5) - pos) * 64 if IRIS_MIDBLOCK else (pos - (P + 0.5)) * 64
                verts.append(pack(pos, col, np.tile(nrm, (N, 1)), uv, lm, PACK_ID.get(b, -1), mid, tan4, mb))
            result['opaque'].append(np.stack(verts, 1).reshape(-1, NF))
    out = {}
    for k, v in result.items():
        if not v: out[k] = (np.zeros((0, NF), np.float32), np.zeros(0, np.uint32)); continue
        V = np.concatenate(v).astype(np.float32)
        nq = len(V) // 4
        base = (np.arange(nq, dtype=np.uint32) * 4)[:, None]
        idx = (base + np.array([0, 1, 2, 0, 2, 3], np.uint32)[None, :]).reshape(-1)
        out[k] = (V, idx)
    return out


if __name__ == '__main__':
    import time
    t = time.time(); B, h, SEA = build_world(); print('world', B.shape, round(time.time() - t, 1), 's')
    t = time.time(); S, BL = propagate(B); print('light', round(time.time() - t, 1), 's')
    t = time.time(); M = mesh(B, S, BL); print('mesh', round(time.time() - t, 1), 's')
    for k, (V, I) in M.items(): print(k, V.shape, I.shape, V.nbytes // 1e6, 'MB')
    print('height range', h.min(), h.max(), 'center h', h[96, 8], 'cabin', h[85, 43])
    print('sky>0 frac', (S > 0).mean().round(3), 'block>0', (BL > 0).mean().round(4))


BLOCK_NAMES = {GRASS: 'grass_block', DIRT: 'dirt', STONE: 'stone', SAND: 'sand', LOG: 'oak_log', LEAVES: 'oak_leaves', PLANKS: 'oak_planks',
               GLASS: 'glass', WATER: 'water', GLOW: 'glowstone', LAVA: 'lava', TALL: 'short_grass', FLOWER: 'poppy', NETHER: 'netherrack'}

def set_pack_ids(name_to_id):
    """Use a pack's own block.properties ids (mc_Entity.x) instead of the EIQFEP ones."""
    PACK_ID.clear()
    for b, nm in BLOCK_NAMES.items():
        if nm in name_to_id: PACK_ID[b] = name_to_id[nm]
