import os as _os
OUTD=_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),'..','out'); _os.makedirs(OUTD,exist_ok=True)
import os,sys; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from rtharness import *
from PIL import Image
dim=int(sys.argv[1]) if len(sys.argv)>1 else 0
mode=sys.argv[2] if len(sys.argv)>2 else 'night'
DBG=(mode=='dbg'); mode='night' if DBG else mode   # night: torch only, day: key light + gi
def scene(X,Y,Z):
    rgb=np.ones(X.shape+(3,),np.float32)*0.62; a=np.zeros(X.shape,np.float32)
    floor=(Y<=-3)&(Y>-8); a[floor]=1; rgb[floor]=(0.55,0.5,0.42)
    inroom=(np.abs(X)<=6)&(np.abs(Z)<=6)
    shell=(np.abs(X)<=7)&(np.abs(Z)<=7)&(Y>=-2)&(Y<=5)&~((np.abs(X)<=6)&(np.abs(Z)<=6)&(Y>=-2)&(Y<=4))
    a[shell]=1; rgb[shell]=(0.75,0.72,0.66)
    door=(Z==-7)&(np.abs(X-2)<=1)&(Y>=-2)&(Y<=0); a[door]=0; 
    win=(X==7)&(np.abs(Z)<=1)&(Y>=0)&(Y<=2); a[win]=0.05; rgb[win]=(1.0,0.15,0.15)
    pil=(X==-1)&(Z==-1)&(Y>=-2)&(Y<=4); a[pil]=1; rgb[pil]=(0.4,0.45,0.8)
    box=(np.abs(X+4)<=1)&(np.abs(Z-4)<=1)&(Y>=-2)&(Y<=-1); a[box]=1; rgb[box]=(0.8,0.3,0.25)
    return rgb,a,[]
geo,idx,_=build_scene(scene); br=bricks(geo)
def sto(rel): return tuple(int(v) for v in ((np.array(rel)+BASE)%np.array(DIMS)))
emit=[(sto((-3,-2,-2)),(1.0,0.62,0.30),14)] if mode=='night' else [(sto((-3,-2,-2)),(1.0,0.62,0.30),14),(sto((4,3,-5)),(0.3,0.5,1.0),12)]
geo2=geo.copy()
for p,c,l in emit: geo2[p]=(255,255,255,255)
lpv=flood(geo2,idx,emit)
h=H(); ctx=h.ctx
g3=h.tex3(geo2,4,'f1'); b3=h.tex3(bricks(geo2),4,'f1'); l3=h.tex3(lpv,4,'f4')
dummy=ctx.texture((1,1),4,np.array([1,1,1,1],'f4').tobytes(),dtype='f4')
BODY='''#define EIQ_DIM %d
#define FSH
#define EIQ_DEFERRED
#include "/lib/lighting.glsl"
#include "/lib/color.glsl"
uniform vec3 camF; uniform vec3 camR; uniform vec3 camU; uniform float expo; uniform vec2 res; uniform int mode;
in vec2 uv; out vec4 o;
void main(){
  vec2 p=(gl_FragCoord.xy/res*2.0-1.0)*vec2(res.x/res.y,1.0)*0.8;
  vec3 rd=normalize(camF+camR*p.x+camU*p.y);
  RtHit h=rtTrace(vec3(0.0),rd,0.0,120.0,300);
  vec3 col;
  float day=(mode==1)?1.0:0.0;
  g_LightDir=normalize(vec3(0.5,0.8,0.3)); g_LightColor=vec3(1.0,0.9,0.8)*3.0*day;
  g_AmbUp=vec3(0.5,0.6,0.9)*0.5*day+vec3(0.01); g_AmbHor=g_AmbUp*0.8; g_AmbGround=g_AmbUp*0.3;
  if(!h.hit){ col=mix(vec3(0.3,0.4,0.6),vec3(0.1,0.15,0.3),clamp(rd.y,0.,1.))*day; }
  else {
    vec4 bn=blueNoise4(gl_FragCoord.xy);
    vec3 N=h.N; vec3 pr=h.posRel;
    float lmSky=day;
    vec3 sh=vec3(1.0);
    if(day>0.5){ RtHit sx=rtTrace(pr+N*0.05,g_LightDir,0.0,60.0,120); sh=sx.hit?vec3(0.0):sx.trans; }
    rtGI(pr,N,lmSky,bn);
    if(mode==5){ vec3 Lr,Lc; float Ll; bool f=rtPickLight(pr,N,bn.wzyx,Lr,Lc,Ll); vec3 vis=vec3(0.0);
      if(f){ vec3 tg=Lr+(bn.xyz-0.5)*0.7; vis=rtShadowRay(pr+N*0.06,tg,36);} vec4 lv=texelFetch(lpvTexA, lpvWrap(ivec3(floor(cameraPosition))+ivec3(floor(pr+(cameraPosition-floor(cameraPosition))+N*0.55))),0); float I=rtMax3(lv.rgb); o=vec4((I>0.1)?(f?1.0:-1.0):0.0,vis.r,f?Ll:0.0,1.0); return; }
    col=shadeSurface(h.albedo,N,-rd,pr,vec2(0.0,lmSky),1.0,0.05,0.04,0.0,0.0,sh,0.0,vec3(1.0));
    if(rtMax3(h.emit)>0.0) col=h.emit*4.0;
  }
  col=tonemapEIQ(col*expo);
  o=vec4(col,1.0);
}''' % dim
def run(label,drop=()):
    src=frag(BODY,5)
    for d in drop: src=src.replace('#define %s\n'%d,'//%s\n'%d)
    prog=ctx.program(vertex_shader=VS,fragment_shader=src)
    for n in ('shadowtex0','shadowtex1','shadowcolor0','noisetex','depthtex0','depthtex1'):
        if n in prog: prog[n]=3
    dummy.use(3); g3.use(0);b3.use(1);l3.use(2)
    for n,u in (('rtGeoTex',0),('rtBrickTex',1),('lpvTexA',2)):
        if n in prog: prog[n]=u
    W,Hh=640,400
    fbo=ctx.framebuffer(ctx.texture((W,Hh),4,dtype='f4')); fbo.use()
    cp=np.array(BASE)+np.array([0.5,0.5,0.5]); cam=np.array([-5.5,1.0,-5.5])
    prog['cameraPosition']=tuple(BASE+cam); prog['res']=(W,Hh); prog['mode']=5 if DBG else (0 if mode=='night' else 1)
    prog['expo']=2.2 if mode=='night' else 0.8; pass
    F=np.array([1.0,-0.10,0.85]);F/=np.linalg.norm(F);R=np.cross(F,[0,1,0]);R/=np.linalg.norm(R);U=np.cross(R,F)
    prog['camF']=tuple(F);prog['camR']=tuple(R);prog['camU']=tuple(U)
    vao=ctx.simple_vertex_array(prog,h.vbo,'p'); acc=np.zeros((Hh,W,4),np.float32); N=24
    for f in range(N):
        if 'frameCounter' in prog: prog['frameCounter']=f
        fbo.clear(); vao.render(moderngl.TRIANGLE_STRIP)
        acc+=np.frombuffer(fbo.read(components=4,dtype='f4'),'f4').reshape(Hh,W,4)
    if DBG:
        a=acc/N; print('lit pixels: found %.4f  failed %.4f'%((a[...,0]>0.5).mean(),(a[...,0]<-0.5).mean()))
        Image.fromarray((np.clip(a[...,:3],0,1)*255).astype(np.uint8)[::-1]).save(OUTD+'/room_dbg.png'); return
    img=(np.clip(acc[...,:3]/N,0,1)**(1/2.2)*255).astype(np.uint8)[::-1]
    Image.fromarray(img).save(f'{OUTD}/room_{mode}_{label}.png'); print(label,'ok')
run('rt')
if not DBG: run('norm',drop=('RT_LIGHTS','RT_GI'))
