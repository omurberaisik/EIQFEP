import os,sys; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from rtharness import *
def scene(X,Y,Z):
    rgb=np.ones(X.shape+(3,),np.float32)*0.6; a=np.zeros(X.shape,np.float32)
    ground=Y<-2; a[ground]=1; rgb[ground]=(0.3,0.5,0.2)
    wall=(X>=8)&(X<=9)&(Z>=-6)&(Z<=6)&(Y>=-2)&(Y<=5); a[wall]=1; rgb[wall]=(0.7,0.65,0.6)
    win=(X>=8)&(X<=9)&(Z>=0)&(Z<=1)&(Y>=0)&(Y<=1); a[win]=0.05; rgb[win]=(1,0.2,0.2)
    pil=(X==3)&(Z==2)&(Y>=-2)&(Y<=3); a[pil]=1
    rng=np.random.default_rng(1); sc=(rng.random(X.shape)<0.01)&(Y>=-2)&(Y<=10)&(np.abs(X)<40)&(np.abs(Z)<40); a[sc]=1  # scattered blocks
    leaf=(np.abs(X-20)<3)&(np.abs(Z+10)<3)&(Y>=2)&(Y<=5); a[leaf]=0.32; rgb[leaf]=(0.8,0.95,0.75)
    return rgb,a,[]
geo,idx,_=build_scene(scene); br=bricks(geo)
h=H(); ctx=h.ctx
g3=h.tex3(geo,4,'f1'); b3=h.tex3(br,4,'f1'); l3=h.tex3(np.zeros(DIMS+(4,),np.float32),4,'f4')
BODY='''
uniform ivec2 res;
in vec2 uv; out vec4 o;
float hh(uint n){ return float(pcgHash(n))*(1.0/4294967295.0);} 
void main(){
  uint id=uint(gl_FragCoord.y)*uint(res.x)+uint(gl_FragCoord.x);
  vec3 ro=vec3(hh(id*7u+1u)*50.0-25.0, hh(id*7u+2u)*14.0-4.0, hh(id*7u+3u)*50.0-25.0);
  float z=hh(id*7u+4u)*2.0-1.0, ph=hh(id*7u+5u)*6.2831853; float r=sqrt(1.0-z*z);
  vec3 rd=vec3(r*cos(ph),z,r*sin(ph));
  RtHit a=rtTrace(ro,rd,0.0,60.0,400,true);
  RtHit b=rtTrace(ro,rd,0.0,60.0,400,false);
  o=vec4(a.hit?a.t:-1.0, b.hit?b.t:-1.0, float(a.steps), float(b.steps));
}'''
prog=ctx.program(vertex_shader=VS,fragment_shader=frag('#include "/lib/rt.glsl"\n'+BODY.replace('in vec2 uv;','in vec2 uv;')))
W=Hh=512
fbo=ctx.framebuffer(ctx.texture((W,Hh),4,dtype='f4'))
g3.use(0);b3.use(1);l3.use(2)
print(list(prog)); 
for n,u in (('rtGeoTex',0),('rtBrickTex',1),('lpvTexA',2)):
    if n in prog: prog[n]=u
prog['res']=(W,Hh); prog['cameraPosition']=tuple(BASE+np.array([0.37,0.61,0.82]))
vao=ctx.simple_vertex_array(prog,h.vbo,'p'); fbo.use(); vao.render(moderngl.TRIANGLE_STRIP)
d=np.frombuffer(fbo.read(components=4,dtype='f4'),'f4').reshape(Hh,W,4)
ta,tb,sa,sb=d[...,0],d[...,1],d[...,2],d[...,3]
agree=((ta>0)==(tb>0))&(np.abs(ta-tb)<2e-3*0+0.01)|((ta<0)&(tb<0))
print('rays',ta.size,'hit frac %.3f'%(ta>0).mean())
print('brick vs nobrick agree: %.5f'%agree.mean())
print('avg steps with bricks %.1f, without %.1f -> %.1f%% fewer'%(sa.mean(),sb.mean(),100*(1-sa.mean()/sb.mean())))
# CPU brute-force reference on subset
geoA=geo[...,3]/255.0
rng=np.random.default_rng(0)
def hh(n):
    n=np.uint32(n); 
    return None
# regenerate rays in python via reading nothing: instead replicate pcg
def pcg(v):
    v=np.uint64(v)&np.uint64(0xffffffff)
    st=(v*np.uint64(747796405)+np.uint64(2891336453))&np.uint64(0xffffffff)
    sh=(st>>np.uint64(28))+np.uint64(4)
    word=(((st>>sh)^st)*np.uint64(277803737))&np.uint64(0xffffffff)
    return ((word>>np.uint64(22))^word)&np.uint64(0xffffffff)
def hf(n): return float(pcg(n))/4294967295.0
cam=np.array([0.37,0.61,0.82]); bad=0;tot=0
for k in range(0,W*Hh,W*Hh//3000):
    iid=k; y,x=divmod(k,W)
    ro=np.array([hf(iid*7+1)*50-25,hf(iid*7+2)*14-4,hf(iid*7+3)*50-25]); z=hf(iid*7+4)*2-1; ph=hf(iid*7+5)*6.2831853; r=np.sqrt(1-z*z)
    rd=np.array([r*np.cos(ph),z,r*np.sin(ph)])
    hit=-1
    c0=np.floor(ro+cam).astype(int)
    for t in np.arange(0,60,0.01):
        p=ro+rd*t; c=np.floor(p+cam).astype(int)-0  # cell relative to cam base
        if np.any(np.abs(c)>np.array([61,29,61])): break
        if np.all(c==c0): continue
        w=(c+BASE)%np.array(DIMS)
        if geoA[tuple(w)]>0.97: hit=t;break
    tot+=1
    got=ta[y,x]
    if (hit<0)!=(got<0) or (hit>=0 and abs(hit-got)>0.06): bad+=1
print('CPU reference mismatches: %d / %d'%(bad,tot))
