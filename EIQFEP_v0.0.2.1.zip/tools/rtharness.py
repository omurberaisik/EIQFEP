import os,re,sys,numpy as np,moderngl
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','shaders')
def inline(src):
    out=[]
    for ln in src.split('\n'):
        m=re.match(r'\s*#include\s+"(/[^"]+)"',ln)
        out.append(inline(open(ROOT+m.group(1)).read()) if m else ln)
    return '\n'.join(out)
def frag(body,level=5,defs=()):
    src=inline('#include "/lib/rt.glsl"\n'+body) if '#include' not in body else inline(body)
    src=re.sub(r'#define EIQ_LEVEL \d','#define EIQ_LEVEL %d'%level,src,count=1)
    pre='#version 430\n#define R11F_G11F_B10F 0\n#define RGBA16 0\n#define RGBA8 0\n#define RGBA16F 0\n#define IS_IRIS\n#define MC_GL_VERSION 460\n'+''.join('#define %s\n'%d for d in defs)
    return pre+src
VS='''#version 430
in vec2 p; out vec2 uv; void main(){ uv=p*0.5+0.5; gl_Position=vec4(p,0,1);} '''
DIMS=(128,64,128)
BASE=np.array([1000,40,-2000])
def build_scene(fn):
    """fn(x,y,z rel arrays)-> (rgb[...,3] float0-1, a) ; returns storage arrays"""
    X,Y,Z=np.meshgrid(np.arange(-64,64),np.arange(-32,32),np.arange(-64,64),indexing='ij')
    rgb,a,emit=fn(X,Y,Z)
    geo=np.zeros(DIMS+(4,),np.uint8)
    wx=(X+BASE[0])%DIMS[0]; wy=(Y+BASE[1])%DIMS[1]; wz=(Z+BASE[2])%DIMS[2]
    g=np.concatenate([rgb,a[...,None]],-1)
    geo[wx,wy,wz]=np.round(g*255).astype(np.uint8)
    return geo,(X,Y,Z,wx,wy,wz),emit
def flood(geo,idx,emit):
    X,Y,Z,wx,wy,wz=idx
    a=geo[...,3]/255.0
    solid=a>0.97
    L=np.zeros(DIMS+(4,),np.float32)
    # BFS: linear 1/15 decay, emitters list of (storage xyz, rgb, level)
    from collections import deque
    val=np.zeros(DIMS,np.float32); col=np.zeros(DIMS+(3,),np.float32)
    q=deque()
    for (p,c,lv) in emit:
        val[p]=lv/15.0; col[p]=np.array(c)*lv/15.0; q.append(p)
    while q:
        p=q.popleft(); v=val[p]
        if v<=1/15: continue
        for d in ((1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)):
            n=((p[0]+d[0])%DIMS[0],(p[1]+d[1])%DIMS[1],(p[2]+d[2])%DIMS[2])
            if solid[n]: continue
            nv=v-1/15
            if nv>val[n]+1e-6:
                val[n]=nv; col[n]=col[p]/max(v,1e-6)*nv; q.append(n)
    L[...,:3]=col
    L[solid,3]=1.0
    for (p,c,lv) in emit: L[p][3]=2.0; L[p][:3]=np.array(c)*lv/15.0
    return L
def bricks(geo):
    a=geo[...,3]/255.0
    occ=(a>=0.045).reshape(32,4,16,4,32,4).any(axis=(1,3,5))
    b=np.zeros((32,16,32,4),np.uint8); b[...,0]=occ*255; b[...,3]=255
    return b
class H:
    def __init__(s):
        s.ctx=moderngl.create_standalone_context(backend='egl')
        s.vbo=s.ctx.buffer(np.array([-1,-1,1,-1,-1,1,1,1],'f4').tobytes())
    def tex3(s,arr,comp,dt):
        t=s.ctx.texture3d(arr.shape[:3][::-1] if False else (arr.shape[0],arr.shape[1],arr.shape[2]),comp,np.ascontiguousarray(arr.transpose(2,1,0,3)).tobytes() if comp>1 else arr.tobytes(),dtype=dt)
        t.filter=(moderngl.NEAREST,moderngl.NEAREST); t.repeat_x=t.repeat_y=t.repeat_z=False
        return t
