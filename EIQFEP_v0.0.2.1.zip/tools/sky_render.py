import os as _os
OUTD=_os.path.join(_os.path.dirname(_os.path.abspath(__file__)),'..','out'); _os.makedirs(OUTD,exist_ok=True)
import os,sys; sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from rtharness import *
from PIL import Image
level=int(sys.argv[1]) if len(sys.argv)>1 else 5
BODY='''#define EIQ_DIM 1
#include "/lib/sky.glsl"
#include "/lib/color.glsl"
uniform float FOVS; uniform vec3 camF; uniform vec3 camR; uniform vec3 camU; uniform float expo; uniform vec2 res;
in vec2 uv; out vec4 o;
void main(){
  vec2 p=(gl_FragCoord.xy/res*2.0-1.0)*vec2(res.x/res.y,1.0)*FOVS;
  vec3 rd=normalize(camF+camR*p.x+camU*p.y);
  vec3 c=endSkyFull(rd,0.5);
  c=tonemapEIQ(c*expo);
  o=vec4(pow(c,vec3(1.0/2.2)),1.0);
}'''
h=H(); ctx=h.ctx
prog=ctx.program(vertex_shader=VS,fragment_shader=frag(BODY,level))
W,Hh=960,540
fbo=ctx.framebuffer(ctx.texture((W,Hh),4,dtype='f1')); fbo.use()
E=np.array([0.60,0.66,-0.45]); E/=np.linalg.norm(E)
prog['gbufferModelViewInverse']=tuple(np.eye(4).T.flatten()); prog['shadowLightPosition']=tuple(E*100)
prog['frameTimeCounter']=30.0
if 'gbufferProjection' in prog: prog['gbufferProjection']=(1.3,0,0,0, 0,1.3,0,0, 0,0,-1,-1, 0,0,-0.2,0)
if 'viewHeight' in prog: prog['viewHeight']=float(540)
prog['res']=(W,Hh); prog['expo']=float(sys.argv[2]) if len(sys.argv)>2 else 1.8
prog['FOVS']=float(sys.argv[3]) if len(sys.argv)>3 else 0.75
vao=ctx.simple_vertex_array(prog,h.vbo,'p')
def cam(F):
    F=np.array(F,float);F/=np.linalg.norm(F); R=np.cross(F,[0,1,0]);R/=np.linalg.norm(R); U=np.cross(R,F)
    prog['camF']=tuple(F);prog['camR']=tuple(R);prog['camU']=tuple(U)
views={'eye':E*1.0+np.array([0,-0.12,0]),'away':-E*np.array([1,0,1])+np.array([0,0.15,0]),'down':[0.1,-1,0.2]}
for n,F in views.items():
    cam(F); fbo.clear(); vao.render(moderngl.TRIANGLE_STRIP)
    Image.frombytes('RGBA',(W,Hh),fbo.read(components=4)).transpose(Image.FLIP_TOP_BOTTOM).convert('RGB').save(f'{OUTD}/end_{n}_L{level}_{prog['FOVS'].value:.2f}.png')
print('done')
