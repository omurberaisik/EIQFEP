import os
import re,subprocess,tempfile,os,sys
sys.argv=['x',os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','shaders'),'5']
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'verify.py')).read().split("fails=0;n=0")[0])
toggles=['RAYTRACING','RT_REFLECTIONS','RT_GI','RT_LIGHTS','GODRAYS','END_EYE','END_NEBULA','END_AURORA','END_MOTES','END_STONE_GLINT','NETHER_EMBERS','LPV_ENABLED','SHOOTING_STARS','AURORA','MOTION_BLUR','DOF']
bad=0;n=0
for lv in (3,5):
  for tg in toggles:
    for w,fs in (('world0',['deferred.fsh','composite1.fsh','composite2.fsh','gbuffers_terrain.fsh','shadow.vsh','shadowcomp.csh']),('world1',['deferred.fsh','composite.fsh','composite1.fsh','composite2.fsh','gbuffers_terrain.fsh','shadow.vsh','shadowcomp.csh','final.fsh']),('world-1',['composite2.fsh'])):
      for f in fs:
        code=build(f'{ROOT}/{w}/{f}',lv,[])
        code=re.sub(r'#define EIQ_LEVEL \d','#define EIQ_LEVEL %d'%lv,code,count=1)
        code=re.sub(r'(?m)^#define %s\b.*$'%tg,'',code)
        st={'vsh':'vert','fsh':'frag','csh':'comp'}[f.split('.')[-1]]
        p=tempfile.NamedTemporaryFile('w',suffix='.'+f.split('.')[-1],delete=False);p.write(code);p.close()
        r=subprocess.run(['glslangValidator','-S',st,p.name],capture_output=True,text=True);os.unlink(p.name);n+=1
        if r.returncode: bad+=1;print('FAIL',lv,tg,w,f,r.stdout.split('\n')[1:4])
print('variants',n,'fails',bad)
