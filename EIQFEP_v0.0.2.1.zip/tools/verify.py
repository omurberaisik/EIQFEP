import os,re,subprocess,sys,tempfile
ROOT=sys.argv[1] if len(sys.argv)>1 else os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','shaders')
levels=[int(x) for x in sys.argv[2].split(',')] if len(sys.argv)>2 else [1,3,5]
def inline(path,seen=None):
    out=[]
    for ln in open(path).read().split('\n'):
        m=re.match(r'\s*#include\s+"(/[^"]+)"',ln)
        if m: out.append(inline(ROOT+m.group(1)))
        else: out.append(ln)
    return '\n'.join(out)
def build(path,level,defs):
    src=inline(path).split('\n')
    # version line first, then defines
    i=next(k for k,l in enumerate(src) if l.startswith('#version'))
    ext=[l for l in src[:12] if l.startswith('#extension')]
    pre=['#define R11F_G11F_B10F 0','#define RGBA16 0','#define RGBA8 0','#define RGBA16F 0','#define IS_IRIS','#define MC_GL_VERSION 460','#define EIQ_LEVEL_OVERRIDE %d'%level]+defs
    body=[l for k,l in enumerate(src) if k!=i]
    return '\n'.join([src[i]]+pre+body)
fails=0;n=0
for w in ['world0','world-1','world1']:
    for f in sorted(os.listdir(f'{ROOT}/{w}')):
        ext=f.split('.')[-1]
        if ext not in('vsh','fsh','csh'): continue
        for lv in levels:
            code=build(f'{ROOT}/{w}/{f}',lv,[])
            # level override: replace the #define EIQ_LEVEL line
            code=re.sub(r'#define EIQ_LEVEL \d','#define EIQ_LEVEL %d'%lv,code,count=1)
            for extra in ([[]] if lv!=3 else [[],['MOTION_BLUR','DOF','RAIN_DROPS']]):
                c=code
                for e in extra: c=c.replace('//#define '+e,'#define '+e)
                st={'vsh':'vert','fsh':'frag','csh':'comp'}[ext]
                p=tempfile.NamedTemporaryFile('w',suffix='.'+ext,delete=False);p.write(c);p.close()
                r=subprocess.run(['glslangValidator','-S',st,p.name],capture_output=True,text=True)
                n+=1
                if r.returncode!=0:
                    fails+=1;print('FAIL',w,f,'L%d'%lv,extra);print('\n'.join(r.stdout.split('\n')[:8]))
                os.unlink(p.name)
print('compiled',n,'fails',fails)
